import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:countasty/features/notification/domain/models/notification_body_model.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_constants.dart';

/// Keeps a live, glanceable view of an in-flight order outside the app.
///
/// On iOS that is a Live Activity — the Lock Screen card and Dynamic Island
/// presentation. On Android, which has no equivalent OS surface, it is an
/// ongoing progress notification that cannot be swiped away while the order is
/// still moving. Both are driven from the same call so `OrderController` has a
/// single place to keep in sync.
///
/// The iOS side is a hand-rolled MethodChannel rather than a package: the same
/// channel has to surface the ActivityKit push token later, and owning both
/// sides keeps that a one-line addition instead of a dependency upgrade.
///
/// Every call is a no-op on unsupported platforms, and the native side is a
/// no-op below iOS 16.1, so callers never need to guard.
class LiveActivityHelper {
  LiveActivityHelper._();

  static const MethodChannel _channel = MethodChannel('countasty/live_activity');

  /// Fixed id so every update replaces the same Android notification rather
  /// than stacking a new one on each status change.
  static const int _androidNotificationId = 7788;
  static const String _androidChannelId = 'countasty_order_tracking';

  /// Id of the iOS activity currently on screen, so updates and the final end
  /// call address the right one. Null when nothing is running.
  static String? _activityId;

  /// Whether something is currently being displayed on either platform.
  static bool _showing = false;

  /// The status the running card was last told about. Guards against hammering
  /// the OS from the 10-second tracking poll, which otherwise pushes an
  /// identical update on every tick.
  static String? _lastStatus;

  static bool get _isIOS => !kIsWeb && Platform.isIOS;
  static bool get _isAndroid => !kIsWeb && Platform.isAndroid;
  static bool get _supported => _isIOS || _isAndroid;

  /// Ordered delivery stages the card renders as a progress track. Anything
  /// not listed (canceled, failed, refunded) ends the activity instead.
  static const List<String> _stages = <String>[
    'pending',
    AppConstants.confirmed,
    AppConstants.processing,
    AppConstants.handover,
    AppConstants.pickedUp,
  ];

  static int _stageIndex(String status) {
    final int i = _stages.indexOf(status);
    // accepted is the API's alias for confirmed on some flows.
    if (i < 0 && status == AppConstants.accepted) return 1;
    return i < 0 ? 0 : i;
  }

  /// True once the order has reached a state where nothing more will happen on
  /// the Lock Screen and the card should be dismissed.
  static bool isTerminal(String? status) =>
      status == 'delivered' || status == 'canceled' || status == 'failed' || status == 'refunded';

  /// Starts the card, or updates it when one is already running for this order.
  ///
  /// Safe to call on every tracking poll — it exits early when the status
  /// hasn't moved.
  static Future<void> startOrUpdate({
    required String orderId,
    required String restaurantName,
    required String status,
    String? etaText,
    String? restaurantImageUrl,
  }) async {
    if (!_supported) return;

    if (isTerminal(status)) {
      await end(status: status);
      return;
    }

    if (_showing && _lastStatus == status) return;

    if (_isIOS) {
      await _startOrUpdateIOS(
        orderId: orderId,
        restaurantName: restaurantName,
        status: status,
        etaText: etaText ?? '',
        imageUrl: restaurantImageUrl ?? '',
      );
    } else {
      await _showAndroidOngoing(
        orderId: orderId,
        restaurantName: restaurantName,
        status: status,
        etaText: etaText ?? '',
      );
    }
  }

  /// Dismisses the card. Called on delivery, cancellation, or logout.
  static Future<void> end({String? status}) async {
    if (!_supported || !_showing) return;

    try {
      if (_isIOS) {
        if (_activityId == null) return;
        await _channel.invokeMethod<void>('end', {
          'activityId': _activityId,
          'status': status ?? 'delivered',
        });
      } else {
        await FlutterLocalNotificationsPlugin().cancel(_androidNotificationId);
      }
    } on PlatformException catch (e) {
      debugPrint('LiveActivity end failed: ${e.code} ${e.message}');
    } finally {
      _activityId = null;
      _lastStatus = null;
      _showing = false;
    }
  }

  /// Starts listening for taps on the iOS Live Activity, and drains any tap
  /// that cold-launched the app before Dart was listening.
  ///
  /// Call once from `main()` after DI is up, so `RouteHelper` is usable.
  static Future<void> listenForCardTaps() async {
    if (!_isIOS) return;

    _channel.setMethodCallHandler((MethodCall call) async {
      if (call.method == 'openOrder') {
        _openOrder(call.arguments?.toString());
      }
      return null;
    });

    try {
      _openOrder(await _channel.invokeMethod<String>('consumePendingOpen'));
    } on PlatformException catch (e) {
      debugPrint('LiveActivity pending open failed: ${e.code} ${e.message}');
    }
  }

  static void _openOrder(String? rawOrderId) {
    final int? orderId = int.tryParse(rawOrderId ?? '');
    if (orderId == null) return;
    Get.toNamed(RouteHelper.getOrderDetailsRoute(orderId, fromNotification: true));
  }

  // ---------------------------------------------------------------------------
  // iOS
  // ---------------------------------------------------------------------------

  static Future<void> _startOrUpdateIOS({
    required String orderId,
    required String restaurantName,
    required String status,
    required String etaText,
    required String imageUrl,
  }) async {
    final Map<String, dynamic> args = <String, dynamic>{
      'orderId': orderId,
      'restaurantName': restaurantName,
      'status': status,
      'stageIndex': _stageIndex(status),
      'stageCount': _stages.length,
      'etaText': etaText,
      'imageUrl': imageUrl,
    };

    try {
      if (_activityId == null) {
        _activityId = await _channel.invokeMethod<String>('start', args);
        // Null means the user has Live Activities switched off, or the device
        // predates 16.1. Leave `_showing` false so we don't later try to end
        // something that was never shown.
        _showing = _activityId != null;
      } else {
        await _channel.invokeMethod<void>('update', {...args, 'activityId': _activityId});
      }
      if (_showing) _lastStatus = status;
    } on PlatformException catch (e) {
      // An unavailable or user-disabled Live Activity must never break order
      // tracking — the in-app UI is the source of truth regardless.
      debugPrint('LiveActivity start/update failed: ${e.code} ${e.message}');
    }
  }

  // ---------------------------------------------------------------------------
  // Android
  // ---------------------------------------------------------------------------

  /// Ongoing progress notification, Android's closest equivalent to a Live
  /// Activity. Low importance and `onlyAlertOnce` so advancing a stage updates
  /// the shelf silently instead of buzzing the phone on every step.
  static Future<void> _showAndroidOngoing({
    required String orderId,
    required String restaurantName,
    required String status,
    required String etaText,
  }) async {
    final int stage = _stageIndex(status);

    final AndroidNotificationDetails android = AndroidNotificationDetails(
      _androidChannelId,
      'Order tracking',
      channelDescription: 'Live progress of your current order',
      importance: Importance.low,
      priority: Priority.low,
      ongoing: true,
      autoCancel: false,
      onlyAlertOnce: true,
      playSound: false,
      showProgress: true,
      maxProgress: _stages.length,
      progress: stage + 1,
      category: AndroidNotificationCategory.progress,
      visibility: NotificationVisibility.public,
    );

    // Shaped so the existing tap handler in NotificationHelper routes it to the
    // order details screen, the same place the iOS card's deep link lands.
    final String payload = jsonEncode(NotificationBodyModel(
      notificationType: NotificationType.order,
      orderId: int.tryParse(orderId),
    ).toJson());

    final String body = etaText.isEmpty
        ? restaurantName
        : (restaurantName.isEmpty ? etaText : '$restaurantName  •  $etaText');

    try {
      await FlutterLocalNotificationsPlugin().show(
        _androidNotificationId,
        status.tr,
        body,
        NotificationDetails(android: android),
        payload: payload,
      );
      _showing = true;
      _lastStatus = status;
    } catch (e) {
      debugPrint('Order tracking notification failed: $e');
    }
  }
}
