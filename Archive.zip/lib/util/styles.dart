import 'package:countasty/util/app_constants.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:flutter/material.dart';

// Body text — Instrument Sans (matches countasty.com --body).
// Names kept as roboto* for backward compatibility across the app.
final robotoRegular = TextStyle(
  fontFamily: AppConstants.fontFamily,
  fontWeight: FontWeight.w400,
  fontSize: Dimensions.fontSizeDefault,
);

final robotoMedium = TextStyle(
  fontFamily: AppConstants.fontFamily,
  fontWeight: FontWeight.w500,
  fontSize: Dimensions.fontSizeDefault,
);

final robotoBold = TextStyle(
  fontFamily: AppConstants.fontFamily,
  fontWeight: FontWeight.w600,
  fontSize: Dimensions.fontSizeDefault,
);

final robotoBlack = TextStyle(
  fontFamily: AppConstants.displayFontFamily,
  fontWeight: FontWeight.w800,
  fontSize: Dimensions.fontSizeDefault,
);

// Display type — Bricolage Grotesque (matches countasty.com --display).
// Use for screen titles, section headings, hero numbers.
final displayRegular = TextStyle(
  fontFamily: AppConstants.displayFontFamily,
  fontWeight: FontWeight.w400,
  fontSize: Dimensions.fontSizeLarge,
);

final displaySemiBold = TextStyle(
  fontFamily: AppConstants.displayFontFamily,
  fontWeight: FontWeight.w600,
  fontSize: Dimensions.fontSizeLarge,
  height: 1.15,
  letterSpacing: -0.3,
);

final displayExtraBold = TextStyle(
  fontFamily: AppConstants.displayFontFamily,
  fontWeight: FontWeight.w800,
  fontSize: Dimensions.fontSizeExtraLarge,
  height: 1.1,
  letterSpacing: -0.5,
);

// Mono type — IBM Plex Mono. Use for prices, nutrition values, counters.
final monoMedium = TextStyle(
  fontFamily: AppConstants.monoFontFamily,
  fontWeight: FontWeight.w500,
  fontSize: Dimensions.fontSizeDefault,
);

final monoSemiBold = TextStyle(
  fontFamily: AppConstants.monoFontFamily,
  fontWeight: FontWeight.w600,
  fontSize: Dimensions.fontSizeDefault,
);
