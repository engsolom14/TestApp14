import 'package:flutter/material.dart';
import 'package:countasty/util/dimensions.dart';

/// Countasty elevation system.
///
/// One shadow language for the whole app. Every surface that lifts off the
/// cream background uses a step from this scale instead of a hand-rolled
/// BoxShadow, so cards, sheets and buttons read as one system.
///
/// The scale is tuned for the warm background: shadows are cast in the ink
/// brown (#1A0F08) rather than pure black, which keeps them soft on cream
/// instead of muddy/grey, and they are wide + low-opacity with a negative
/// spread so the edge stays diffuse.
class AppShadows {
  AppShadows._();

  /// Shadow colour — the brand ink, never pure black.
  static const Color _ink = Color(0xFF1A0F08);

  /// Resting surface: list rows, chips, search field. Barely lifted.
  static List<BoxShadow> get low => [
        BoxShadow(
          color: _ink.withValues(alpha: 0.04),
          blurRadius: 12,
          spreadRadius: -4,
          offset: const Offset(0, 4),
        ),
      ];

  /// Default card elevation: food cards, favourite rows, category tiles.
  static List<BoxShadow> get card => [
        BoxShadow(
          color: _ink.withValues(alpha: 0.06),
          blurRadius: 24,
          spreadRadius: -8,
          offset: const Offset(0, 8),
        ),
        BoxShadow(
          color: _ink.withValues(alpha: 0.04),
          blurRadius: 6,
          spreadRadius: -2,
          offset: const Offset(0, 2),
        ),
      ];

  /// Raised: hero imagery, selected states, floating tiles.
  static List<BoxShadow> get raised => [
        BoxShadow(
          color: _ink.withValues(alpha: 0.10),
          blurRadius: 40,
          spreadRadius: -12,
          offset: const Offset(0, 16),
        ),
        BoxShadow(
          color: _ink.withValues(alpha: 0.05),
          blurRadius: 10,
          spreadRadius: -4,
          offset: const Offset(0, 4),
        ),
      ];

  /// Overlays that sit above content: bottom sheets, toasts, dialogs.
  static List<BoxShadow> get overlay => [
        BoxShadow(
          color: _ink.withValues(alpha: 0.16),
          blurRadius: 48,
          spreadRadius: -12,
          offset: const Offset(0, 20),
        ),
      ];

  /// Bars anchored to the bottom edge — shadow is cast upward.
  static List<BoxShadow> get bottomBar => [
        BoxShadow(
          color: _ink.withValues(alpha: 0.08),
          blurRadius: 28,
          spreadRadius: -6,
          offset: const Offset(0, -8),
        ),
      ];

  /// Coloured glow under a filled brand button / active pill.
  /// Reads as light spilling off the accent, not as a drop shadow.
  static List<BoxShadow> glow(Color color, {double opacity = 0.40}) => [
        BoxShadow(
          color: color.withValues(alpha: opacity),
          blurRadius: 24,
          spreadRadius: -10,
          offset: const Offset(0, 10),
        ),
      ];
}

/// Ready-made surface decorations, so a white rounded card is written the
/// same way everywhere instead of being re-derived per screen.
class AppSurface {
  AppSurface._();

  /// Hairline edge for a card. On cream it is a whisper of ink; on the dark
  /// #14100C page an ink border is invisible, so the edge flips to light and
  /// keeps the #1E1811 card from dissolving into the background.
  ///
  /// The dark tint is taken from the active theme's own `onSurface` rather than
  /// a literal, because there are two dark styles: the warm one uses #F3EEE7
  /// and the classic cool one #F5F7FA. A cool white at low alpha over the warm
  /// brown ground reads grey and makes the surface look muddy, so the edge has
  /// to follow whichever style is live.
  static Color hairline(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark
          ? Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.08)
          : const Color(0xFF1A0F08).withValues(alpha: 0.06);

  /// The standard card. On a white background a white card needs a hairline
  /// edge as well as a shadow, otherwise it dissolves into the page on
  /// low-contrast displays.
  static BoxDecoration card(
    BuildContext context, {
    double? radius,
    Color? color,
    List<BoxShadow>? shadow,
    bool bordered = true,
  }) =>
      BoxDecoration(
        color: color ?? Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(radius ?? Dimensions.radiusLarge),
        border: bordered
            ? Border.all(color: hairline(context), width: 1)
            : null,
        boxShadow: shadow ?? AppShadows.card,
      );

  /// A circular surface — category icons, icon buttons, avatars.
  static BoxDecoration circle(
    BuildContext context, {
    Color? color,
    List<BoxShadow>? shadow,
  }) =>
      BoxDecoration(
        color: color ?? Theme.of(context).cardColor,
        shape: BoxShape.circle,
        boxShadow: shadow ?? AppShadows.low,
      );

  /// Pill container — filter chips, size selectors, badges.
  static BoxDecoration pill(
    BuildContext context, {
    Color? color,
    List<BoxShadow>? shadow,
    Color? border,
  }) =>
      BoxDecoration(
        color: color ?? Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
        border: border != null ? Border.all(color: border) : null,
        boxShadow: shadow ?? AppShadows.low,
      );
}
