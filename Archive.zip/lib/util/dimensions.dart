import 'package:get/get.dart';

class Dimensions {
  static double fontSizeExtraSmall = Get.context!.width >= 1300 ? 12 : 10;
  static double fontSizeSmall = Get.context!.width >= 1300 ? 14 : 12;
  static double fontSizeDefault = Get.context!.width >= 1300 ? 16 : 14;
  static double fontSizeLarge = Get.context!.width >= 1300 ? 18 : 16;
  static double fontSizeExtraLarge = Get.context!.width >= 1300 ? 20 : 18;
  static double fontSizeOverLarge = Get.context!.width >= 1300 ? 26 : 24;

  static const double paddingSizeExtraSmall = 5.0;
  static const double paddingSizeSmall = 10.0;
  static const double paddingSizeDefault = 15.0;
  static const double paddingSizeLarge = 20.0;
  static const double paddingSizeExtraLarge = 25.0;
  static const double paddingSizeOverLarge = 30.0;
  static const double paddingSizeExtraOverLarge = 35.0;

  // Radius scale aligned with countasty.com (--radius: 22px, pill buttons).
  // Tuned up so every surface in the app carries the same generous rounding
  // as the home cards — the whole app reads from these tokens, so raising the
  // scale here rounds chips, fields, sheets and cards together.
  static const double radiusSmall = 12.0;
  static const double radiusDefault = 20.0;
  static const double radiusLarge = 24.0;
  static const double radiusExtraLarge = 30.0;
  static const double radiusPill = 999.0;

  static const double webMaxWidth = 1170;
  static const int messageInputLength = 250;
}
