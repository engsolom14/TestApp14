import 'package:flutter/material.dart';
import 'package:countasty/util/app_constants.dart';

// Countasty design system (countasty.com)
// cream #FFF6EC · ink #1A0F08 · orange #E2762D · orange-hot #FF9A3D
// rust #B5481A · olive #7C8A4D · peach #F7DDC2 · peach-soft #FBEAD6
ThemeData light = ThemeData(
  fontFamily: AppConstants.fontFamily,
  primaryColor: const Color(0xFFE2762D),
  secondaryHeaderColor: const Color(0xFFFBEAD6),
  disabledColor: const Color(0xFFA89B8F),
  brightness: Brightness.light,
  // #80705F clears 4.76:1 on white — placeholder/secondary text must hit 4.5:1.
  hintColor: const Color(0xFF80705F),
  cardColor: Colors.white,
  // Neutral light-grey page background. Deliberately darker than the white
  // cardColor so cards read as raised surfaces instead of dissolving into it.
  scaffoldBackgroundColor: const Color(0xFFF2F2F4),
  shadowColor: const Color(0xFF1A0F08).withValues(alpha: 0.05),
  textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: const Color(0xFFE2762D))),
  colorScheme: const ColorScheme.light(
          primary: Color(0xFFE2762D),
          tertiary: Color(0xFF7C8A4D),
          tertiaryContainer: Color(0xFFA9B778),
          secondary: Color(0xFFFF9A3D))
      .copyWith(surface: const Color(0xFFF2F2F4))
      .copyWith(
        error: const Color(0xFFB5481A),
      ),
  popupMenuTheme: const PopupMenuThemeData(
      color: Colors.white, surfaceTintColor: Colors.white),
  dialogTheme: const DialogThemeData(surfaceTintColor: Colors.white),
  floatingActionButtonTheme: FloatingActionButtonThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(500))),
  bottomAppBarTheme: const BottomAppBarThemeData(
    surfaceTintColor: Colors.white,
    height: 60,
    padding: EdgeInsets.symmetric(vertical: 5),
  ),
  // Icons default to the same quiet grey as the tab bar glyphs. Anything that
  // needs to shout (active states, brand accents) sets its colour explicitly.
  iconTheme: const IconThemeData(color: Color(0xFF80705F), size: 22),
  dividerTheme: DividerThemeData(
      color: const Color(0xFF1A0F08).withValues(alpha: 0.14), thickness: 0.5),
  tabBarTheme: const TabBarThemeData(dividerColor: Colors.transparent),
);
