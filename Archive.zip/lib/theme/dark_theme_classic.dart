import 'package:flutter/material.dart';
import 'package:countasty/util/app_constants.dart';

// Countasty design system — dark, classic (cool charcoal).
//
// The original dark stack, kept as a selectable style alongside the warm one in
// dark_theme.dart. Cool neutral ink instead of pure black, so surfaces stack
// readably: page #171A21 · card #1E222B · elevated #272C37
// orange #FF6B35 · green #22C55E · text #F5F7FA · muted #A7AFBD
//
// Note this variant keeps its original bright green as `tertiary`, which is
// what it always shipped with. The warm variant uses olive to match the light
// theme instead — so the nutrition ring's protein arc is green here and olive
// there. That difference is intentional: this file preserves the old look.
const Color _darkBg = Color(0xFF171A21);
const Color _darkCard = Color(0xFF1E222B);
const Color _darkElevated = Color(0xFF272C37);
const Color _darkOrange = Color(0xFFFF6B35);
const Color _darkGreen = Color(0xFF22C55E);
const Color _darkText = Color(0xFFF5F7FA);
const Color _darkMuted = Color(0xFFA7AFBD);

ThemeData darkClassic = ThemeData(
  fontFamily: AppConstants.fontFamily,
  primaryColor: _darkOrange,
  secondaryHeaderColor: _darkElevated,
  disabledColor: _darkMuted,
  brightness: Brightness.dark,
  hintColor: _darkMuted,
  cardColor: _darkCard,
  scaffoldBackgroundColor: _darkBg,
  shadowColor: Colors.black.withValues(alpha: 0.45),
  textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: _darkOrange)),
  colorScheme: const ColorScheme.dark(
          primary: _darkOrange,
          tertiary: _darkGreen,
          tertiaryContainer: Color(0xFF166534),
          secondary: _darkOrange)
      .copyWith(
        surface: _darkBg,
        surfaceContainerHighest: _darkElevated,
        onSurface: _darkText,
        onPrimary: _darkText,
        error: const Color(0xFFE06A3E),
      ),
  // Body/label colours default to the text token; anything that needs to be
  // quiet reaches for hintColor/disabledColor instead.
  textTheme: const TextTheme().apply(
    bodyColor: _darkText,
    displayColor: _darkText,
  ),
  iconTheme: const IconThemeData(color: _darkMuted, size: 22),
  canvasColor: _darkCard,
  popupMenuTheme: const PopupMenuThemeData(
      color: _darkElevated, surfaceTintColor: _darkElevated),
  dialogTheme: const DialogThemeData(
      backgroundColor: _darkElevated, surfaceTintColor: _darkElevated),
  bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: _darkElevated, surfaceTintColor: _darkElevated),
  floatingActionButtonTheme: FloatingActionButtonThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(500))),
  bottomAppBarTheme: const BottomAppBarThemeData(
    color: _darkCard,
    surfaceTintColor: _darkCard,
    height: 60,
    padding: EdgeInsets.symmetric(vertical: 5),
  ),
  dividerTheme: DividerThemeData(
      color: _darkText.withValues(alpha: 0.10), thickness: 0.5),
  tabBarTheme: const TabBarThemeData(dividerColor: Colors.transparent),
);
