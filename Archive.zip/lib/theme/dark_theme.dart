import 'package:flutter/material.dart';
import 'package:countasty/util/app_constants.dart';

// Countasty design system — dark.
//
// Warm, not charcoal. The light theme is built on toasted orange over cream
// (#E2762D on #FBEAD6); the previous dark stack answered that with cool
// blue-grey (#171A21) and a hot #FF6B35, so the two themes read as different
// products. This stack keeps the same hue family in the dark: near-black with
// a brown cast, surfaces stepping up in warmth rather than in grey.
//
//   page #14100C · card #1E1811 · elevated #241D16 · chip #2A2219
//   amber #F0913F · olive #9DB06A · tan #C08E5C
//   text #F3EEE7 · muted #9C8C7A · hairline #332A21
//
// Amber is lifted from the light theme's #E2762D: the darker ground needs a
// lighter, less saturated brand tone to hold contrast (8:1 on page) without
// glowing. Olive matches the light theme's tertiary (#7C8A4D) instead of the
// old bright green, so "tertiary" finally means the same thing in both themes —
// and the nutrition ring reads identically light and dark.
const Color _darkBg = Color(0xFF14100C);
const Color _darkCard = Color(0xFF1E1811);
const Color _darkElevated = Color(0xFF241D16);
const Color _darkChip = Color(0xFF2A2219);
const Color _darkAmber = Color(0xFFF0913F);
const Color _darkOlive = Color(0xFF9DB06A);
const Color _darkOliveDeep = Color(0xFF55632F);
const Color _darkText = Color(0xFFF3EEE7);
const Color _darkMuted = Color(0xFF9C8C7A);
const Color _darkHairline = Color(0xFF332A21);

ThemeData dark = ThemeData(
  fontFamily: AppConstants.fontFamily,
  primaryColor: _darkAmber,
  secondaryHeaderColor: _darkElevated,
  disabledColor: _darkMuted,
  brightness: Brightness.dark,
  hintColor: _darkMuted,
  cardColor: _darkCard,
  scaffoldBackgroundColor: _darkBg,
  shadowColor: Colors.black.withValues(alpha: 0.55),
  textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: _darkAmber)),
  colorScheme: const ColorScheme.dark(
          primary: _darkAmber,
          tertiary: _darkOlive,
          tertiaryContainer: _darkOliveDeep,
          secondary: _darkAmber)
      .copyWith(
        surface: _darkBg,
        surfaceContainerHighest: _darkElevated,
        surfaceContainerHigh: _darkChip,
        onSurface: _darkText,
        onPrimary: const Color(0xFF1A0F08),
        error: const Color(0xFFE5765C),
      ),
  // Body/label colours default to the text token; anything that needs to be
  // quiet reaches for hintColor/disabledColor instead.
  textTheme: const TextTheme().apply(
    bodyColor: _darkText,
    displayColor: _darkText,
  ),
  iconTheme: const IconThemeData(color: _darkMuted, size: 22),
  canvasColor: _darkCard,
  popupMenuTheme: const PopupMenuThemeData(
      color: _darkElevated, surfaceTintColor: _darkElevated),
  dialogTheme: const DialogThemeData(
      backgroundColor: _darkElevated, surfaceTintColor: _darkElevated),
  bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: _darkElevated, surfaceTintColor: _darkElevated),
  floatingActionButtonTheme: FloatingActionButtonThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(500))),
  bottomAppBarTheme: const BottomAppBarThemeData(
    color: _darkCard,
    surfaceTintColor: _darkCard,
    height: 60,
    padding: EdgeInsets.symmetric(vertical: 5),
  ),
  // An explicit warm hairline rather than white-at-10%, which turns grey on a
  // brown ground and is the fastest way to make a warm theme look muddy.
  dividerTheme: const DividerThemeData(color: _darkHairline, thickness: 0.5),
  tabBarTheme: const TabBarThemeData(dividerColor: Colors.transparent),
);
