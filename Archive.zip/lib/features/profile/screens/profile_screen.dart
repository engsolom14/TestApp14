import 'package:countasty/common/widgets/custom_app_bar_widget.dart';
import 'package:countasty/common/widgets/custom_button_widget.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/order/controllers/order_controller.dart';
import 'package:countasty/features/profile/controllers/profile_controller.dart';
import 'package:countasty/features/profile/widgets/account_deletion_bottom_sheet.dart';
import 'package:countasty/features/profile/widgets/notification_status_change_bottom_sheet.dart';
import 'package:countasty/features/profile/widgets/profile_button_widget.dart';
import 'package:countasty/features/profile/widgets/update_profile_form_widget.dart';
import 'package:countasty/features/profile/widgets/web_profile_widget.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/features/auth/widgets/auth_dialog_widget.dart';
import 'package:countasty/helper/date_converter.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_constants.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/images.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_image_widget.dart';
import 'package:countasty/common/widgets/footer_view_widget.dart';
import 'package:countasty/common/widgets/menu_drawer_widget.dart';
import 'package:countasty/common/widgets/logo_mask_widget.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final ScrollController scrollController = ScrollController();

  @override
  void initState() {
    super.initState();

    _initCall();
  }

  void _initCall() {
    if(Get.find<AuthController>().isLoggedIn() && Get.find<ProfileController>().userInfoModel == null) {
      Get.find<ProfileController>().getUserInfo();
    }
    if(Get.find<AuthController>().isLoggedIn() && Get.find<OrderController>().runningOrderList == null){
      Get.find<OrderController>().getRunningOrders(1, notify: false, limit: 5);
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isDesktop = ResponsiveHelper.isDesktop(context);
    bool isLoggedIn = Get.find<AuthController>().isLoggedIn();
    final bool showWalletCard = Get.find<SplashController>().configModel!.customerWalletStatus == 1
        || Get.find<SplashController>().configModel!.loyaltyPointStatus == 1;

    return Scaffold(
      appBar: CustomAppBarWidget(title: 'profile'.tr),
      endDrawer: isDesktop ? const MenuDrawerWidget() : null,
      endDrawerEnableOpenDragGesture: false,
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: GetBuilder<OrderController>(builder: (orderController) {
        return GetBuilder<ProfileController>(builder: (profileController) {
          if (isLoggedIn && profileController.userInfoModel == null && (orderController.runningOrderList == null)) {
            return const Center(child: CircularProgressIndicator());
          }

          // The footer only renders on desktop; on mobile its 65% min-height
          // constraint would leave a large blank block above the content.
          Widget content = (isLoggedIn && isDesktop) ? WebProfileWidget(profileController: profileController, orderController: orderController) : isLoggedIn ? Container(
                  color: Theme.of(context).colorScheme.surface,
                  width: Dimensions.webMaxWidth,
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: Column(children: [

                      /// Hero card — large masked portrait, name set big beside it.
                      Container(
                        margin: const EdgeInsets.fromLTRB(
                          Dimensions.paddingSizeDefault, Dimensions.paddingSizeDefault,
                          Dimensions.paddingSizeDefault, Dimensions.paddingSizeSmall,
                        ),
                        padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(Dimensions.radiusExtraLarge),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft, end: Alignment.bottomRight,
                            colors: [
                              Theme.of(context).primaryColor.withValues(alpha: 0.16),
                              Theme.of(context).primaryColor.withValues(alpha: 0.05),
                            ],
                          ),
                          border: Border.all(color: AppSurface.hairline(context), width: 1),
                          boxShadow: AppShadows.card,
                        ),
                        child: Stack(children: [

                          Row(crossAxisAlignment: CrossAxisAlignment.center, children: [

                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [

                                isLoggedIn && profileController.userInfoModel?.createdAt != null ? Container(
                                  padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).cardColor.withValues(alpha: 0.85),
                                    borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                                  ),
                                  child: Text(
                                    '${'joined'.tr} ${DateConverter.containTAndZToUTCFormat(profileController.userInfoModel!.createdAt!)}',
                                    style: robotoMedium.copyWith(
                                      fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).primaryColor,
                                    ),
                                  ),
                                ) : const SizedBox(),
                                const SizedBox(height: Dimensions.paddingSizeSmall),

                                Text(
                                  isLoggedIn ? '${profileController.userInfoModel?.fName ?? ''} ${profileController.userInfoModel?.lName ?? ''}'.trim() : 'guest_user'.tr,
                                  style: displaySemiBold.copyWith(fontSize: 28, height: 1.05),
                                  maxLines: 2, overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                                isLoggedIn ? Text(
                                  profileController.userInfoModel?.email ?? '',
                                  style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).hintColor),
                                  maxLines: 1, overflow: TextOverflow.ellipsis,
                                ) : InkWell(
                                  onTap: () async {
                                    if(!isDesktop) {
                                      await Get.toNamed(RouteHelper.getSignInRoute(Get.currentRoute));
                                    }else{
                                      Get.dialog(const Center(child: AuthDialogWidget(exitFromApp: false, backFromThis: false))).then((value) {
                                        _initCall();
                                        setState(() {});
                                      });
                                    }
                                  },
                                  child: Text(
                                    'login_to_view_all_feature'.tr,
                                    style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).primaryColor),
                                  ),
                                ),
                              ]),
                            ),
                            const SizedBox(width: Dimensions.paddingSizeSmall),

                            LogoMaskWidget(size: 128, child: CustomImageWidget(
                              placeholder: isLoggedIn ? Images.profilePlaceholder : Images.guestIcon,
                              image: '${(profileController.userInfoModel != null && isLoggedIn) ? profileController.userInfoModel!.imageFullUrl : ''}',
                              height: 128, width: 128, fit: BoxFit.cover, imageColor: isLoggedIn ? Theme.of(context).hintColor : null,
                            )),
                          ]),

                          isLoggedIn ? const SizedBox() : Positioned(
                            top: 0, right: 0,
                            child: InkWell(
                              onTap: () async {
                                if(!isDesktop) {
                                  await Get.toNamed(RouteHelper.getSignInRoute(Get.currentRoute));
                                }else{
                                  Get.dialog(const Center(child: AuthDialogWidget(exitFromApp: false, backFromThis: false))).then((value) {
                                    _initCall();
                                    setState(() {});
                                  });
                                }
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                                  color: Theme.of(context).primaryColor,
                                ),
                                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: Dimensions.paddingSizeDefault),
                                child: Text('login'.tr, style: robotoMedium.copyWith(color: Colors.white, fontSize: Dimensions.fontSizeSmall)),
                              ),
                            ),
                          ),
                        ]),
                      ),

                      Container(
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(Dimensions.radiusExtraLarge)),
                          color: Theme.of(context).cardColor,
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeLarge, vertical: Dimensions.paddingSizeLarge),
                        child: Column(children: [

                            /// Edit-profile fields live directly on this screen —
                            /// no separate route, no edit toggle.
                            isLoggedIn ? const UpdateProfileFormWidget(embedded: true) : const SizedBox(),
                            SizedBox(height: isLoggedIn ? Dimensions.paddingSizeExtraOverLarge : 0),


                            isLoggedIn ? GetBuilder<AuthController>(builder: (authController) {
                              return ProfileButtonWidget(
                                icon: Symbols.notifications, title: 'notification'.tr,
                                isButtonActive: authController.notification, onTap: () {
                                Get.bottomSheet(const NotificationStatusChangeBottomSheet());
                                // authController.setNotificationActive(!authController.notification);
                              },
                              );
                            }) : const SizedBox(),
                            SizedBox(height: isLoggedIn ? Dimensions.paddingSizeSmall : 0),

                            isLoggedIn ? ProfileButtonWidget(icon: Symbols.lock, title: 'change_password'.tr, onTap: () {
                              Get.toNamed(RouteHelper.getResetPasswordRoute('', '', 'password-change'));
                            }) : const SizedBox(),
                            SizedBox(height: isLoggedIn ? Dimensions.paddingSizeSmall : 0),

                            isLoggedIn ? ProfileButtonWidget(
                              icon: Symbols.delete,
                              iconImage: Images.profileDelete,
                              title: 'delete_account'.tr,
                              onTap: () {
                                showModalBottomSheet(
                                  isScrollControlled: true, useRootNavigator: true, context: Get.context!,
                                  backgroundColor: Colors.white,
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(topLeft: Radius.circular(Dimensions.radiusExtraLarge), topRight: Radius.circular(Dimensions.radiusExtraLarge)),
                                  ),
                                  builder: (context) {
                                    return ConstrainedBox(
                                      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.8),
                                      child: AccountDeletionBottomSheet(
                                        profileController: profileController,
                                        isRunningOrderAvailable: orderController.runningOrderList != null && orderController.runningOrderList!.isNotEmpty,
                                      ),
                                    );
                                  },
                                );
                              },
                            ) : const SizedBox(),
                            SizedBox(height: isLoggedIn ? Dimensions.paddingSizeLarge : 0),

                            const SizedBox(height: Dimensions.paddingSizeLarge),
                            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Text('${'version'.tr}:', style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeExtraSmall)),
                              const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                              Text(AppConstants.appVersion.toString(), style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeExtraSmall)),
                            ]),
                        ]),
                      ),

                    ]),
                  ),
                ) : SizedBox(
                  width: Dimensions.webMaxWidth, height: context.height - 87,
                  child: Column(children: [

                    /// Same hero treatment as the signed-in header, so guests
                    /// land on a recognisably identical screen.
                    Container(
                      margin: const EdgeInsets.fromLTRB(
                        Dimensions.paddingSizeDefault, Dimensions.paddingSizeDefault,
                        Dimensions.paddingSizeDefault, Dimensions.paddingSizeSmall,
                      ),
                      padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(Dimensions.radiusExtraLarge),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft, end: Alignment.bottomRight,
                          colors: [
                            Theme.of(context).primaryColor.withValues(alpha: 0.16),
                            Theme.of(context).primaryColor.withValues(alpha: 0.05),
                          ],
                        ),
                        border: Border.all(color: AppSurface.hairline(context), width: 1),
                        boxShadow: AppShadows.card,
                      ),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [

                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [

                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall, vertical: 4),
                              decoration: BoxDecoration(
                                color: Theme.of(context).cardColor.withValues(alpha: 0.85),
                                borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                              ),
                              child: Text(
                                'guest'.tr,
                                style: robotoMedium.copyWith(
                                  fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).primaryColor,
                                ),
                              ),
                            ),
                            const SizedBox(height: Dimensions.paddingSizeSmall),

                            Text(
                              'guest_user'.tr,
                              style: displaySemiBold.copyWith(fontSize: 28, height: 1.05),
                              maxLines: 2, overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                            Text(
                              'login_to_view_all_feature'.tr,
                              style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).hintColor),
                              maxLines: 2, overflow: TextOverflow.ellipsis,
                            ),
                          ]),
                        ),
                        const SizedBox(width: Dimensions.paddingSizeSmall),

                        LogoMaskWidget(size: 128, child: CustomImageWidget(
                          placeholder: Images.guestIcon,
                          image: '',
                          height: 128, width: 128, fit: BoxFit.cover,
                        )),
                      ]),
                    ),

                    Expanded(
                      child: Center(
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [

                          SizedBox(
                            width: context.width * 0.7,
                            child: Text(
                              'currently_you_are_in_guest_mode_please_login_to_view_all_the_features'.tr,
                              style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).hintColor),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          const SizedBox(height: Dimensions.paddingSizeLarge),

                          CustomButtonWidget(
                            buttonText: 'login'.tr,
                            width: 180,
                            onPressed: () async {
                              if(!isDesktop) {
                                await Get.toNamed(RouteHelper.getSignInRoute(Get.currentRoute))?.then((value) {
                                  _initCall();
                                  setState(() {});
                                });
                              }else{
                                Get.dialog(const Center(child: AuthDialogWidget(exitFromApp: false, backFromThis: false))).then((value) {
                                  _initCall();
                                  setState(() {});
                                });
                              }
                            },
                          ),
                          const SizedBox(height: 50),
                        ]),
                      ),
                    ),
                  ]),
                );

          return SingleChildScrollView(
            controller: scrollController,
            child: isDesktop
                ? FooterViewWidget(
                    minHeight: isLoggedIn ? 0.4 : 0.35,
                    child: content,
                  )
                : Center(child: content),
          );
        });
      }),
    );
  }
}
