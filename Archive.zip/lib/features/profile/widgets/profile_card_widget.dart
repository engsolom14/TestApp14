import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:flutter/material.dart';

class ProfileCardWidget extends StatelessWidget {
  final String image;
  final String title;
  final String data;

  /// Optional destination — the stat cards are entry points on the menu.
  final VoidCallback? onTap;
  const ProfileCardWidget({super.key, required this.data, required this.title, required this.image, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
      child: Container(
      height: 112,
      // Same surface treatment as the cards on home.
      decoration: AppSurface.card(context),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Image.asset(image, height: 30, width: 30),
        const SizedBox(height: Dimensions.paddingSizeExtraSmall),
        Text(data, style: robotoBold.copyWith(
          fontSize: Dimensions.fontSizeLarge, color: Theme.of(context).textTheme.bodyLarge!.color
        )),
        const SizedBox(height: Dimensions.paddingSizeExtraSmall),
        Text(title, style: robotoRegular.copyWith(
          fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).disabledColor,
        )),
      ]),
      ),
    );
  }
}