import 'dart:io';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:countasty/common/widgets/custom_loader_widget.dart';
import 'package:countasty/common/widgets/validate_check.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/language/controllers/localization_controller.dart';
import 'package:countasty/features/profile/controllers/profile_controller.dart';
import 'package:countasty/features/profile/domain/models/update_user_model.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/helper/custom_validator.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/images.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_button_widget.dart';
import 'package:countasty/common/widgets/custom_image_widget.dart';
import 'package:countasty/common/widgets/custom_snackbar_widget.dart';
import 'package:countasty/common/widgets/custom_text_field_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:material_symbols_icons/symbols.dart';

/// The edit-profile form, extracted so it can render inline inside
/// ProfileScreen as well as on the standalone UpdateProfileScreen route.
class UpdateProfileFormWidget extends StatefulWidget {
  /// Called after a successful update triggered by the main button, so the
  /// host screen can react (e.g. leave an edit mode).
  final VoidCallback? onUpdated;

  /// When embedded the form sizes to its content and skips the standalone
  /// screen's card chrome, so it can sit inside another screen's scroll view.
  final bool embedded;
  const UpdateProfileFormWidget({super.key, this.onUpdated, this.embedded = false});

  @override
  State<UpdateProfileFormWidget> createState() => _UpdateProfileFormWidgetState();
}

class _UpdateProfileFormWidgetState extends State<UpdateProfileFormWidget> {
  final FocusNode _nameFocus = FocusNode();
  final FocusNode _emailFocus = FocusNode();
  final FocusNode _phoneFocus = FocusNode();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  String? _countryDialCode;
  bool _isPhoneLoading = true;

  @override
  void initState() {
    super.initState();
    _initCall();
  }

  void _initCall() {
    AuthController authController = Get.find<AuthController>();
    _countryDialCode = authController.getUserCountryCode().isNotEmpty
        ? authController.getUserCountryCode()
        : CountryCode.fromCountryCode(Get.find<SplashController>().configModel!.country!).dialCode;

    Get.find<ProfileController>().getUserInfo();
    Get.find<ProfileController>().initData();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _nameFocus.dispose();
    _emailFocus.dispose();
    _phoneFocus.dispose();
    super.dispose();
  }

  void _splitPhoneNumber(String number) async {
    _isPhoneLoading = true;
    try {
      PhoneValid phoneNumber = await CustomValidator.isPhoneValid(number);
      _phoneController.text = phoneNumber.phone.replaceFirst('+${phoneNumber.countryCode}', '');
      _countryDialCode = '+${phoneNumber.countryCode}';
    } catch (_) {}
    if (mounted) {
      setState(() {
        _isPhoneLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isLoggedIn = Get.find<AuthController>().isLoggedIn();

    return GetBuilder<ProfileController>(builder: (profileController) {
      if (profileController.userInfoModel != null && _phoneController.text.isEmpty && _isPhoneLoading) {
        _splitPhoneNumber(profileController.userInfoModel!.phone ?? '');
        _nameController.text = '${profileController.userInfoModel!.fName} ${profileController.userInfoModel!.lName}';
        _emailController.text = profileController.userInfoModel!.email ?? '';
      }

      if (profileController.userInfoModel == null) {
        return const Center(child: CircularProgressIndicator());
      }

      // Embedded: an expandable card on the profile screen. Only the photo and
      // name are editable here — phone and email stay on the full screen since
      // they carry verification flows.
      if (widget.embedded) {
        return _EditProfileCard(
          nameController: _nameController,
          nameFocus: _nameFocus,
          avatar: _avatar(context, profileController, isLoggedIn, size: 72),
          onSave: () => _updateNameAndPhoto(profileController),
        );
      }

      return Column(children: [
        const SizedBox(height: 70),

        Expanded(
          child: Stack(clipBehavior: Clip.none, children: [

            Container(
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(Dimensions.radiusExtraLarge),
                  topRight: Radius.circular(Dimensions.radiusExtraLarge),
                ),
                border: Border.all(color: AppSurface.hairline(context), width: 1),
                boxShadow: AppShadows.card,
              ),
              child: Column(children: [

                Expanded(child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                  child: Center(child: SizedBox(width: Dimensions.webMaxWidth, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const SizedBox(height: 70),
                    ..._fields(context, profileController),
                  ]))),
                )),

                SafeArea(
                  child: CustomButtonWidget(
                    isLoading: profileController.isLoading,
                    onPressed: () => _updateProfile(profileController: profileController, fromButton: true, fromPhone: false),
                    margin: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                    buttonText: 'update'.tr,
                  ),
                ),

              ]),
            ),

            Positioned(
              top: -50, left: 0, right: 0,
              child: Center(child: _avatar(context, profileController, isLoggedIn, size: 100)),
            ),

          ]),
        ),
      ]);
    });
  }

  /// Tappable avatar that opens the gallery picker and previews the pending
  /// selection before it is saved.
  Widget _avatar(BuildContext context, ProfileController profileController, bool isLoggedIn, {required double size}) {
    return Stack(children: [
      ClipOval(child: profileController.pickedFile != null ? GetPlatform.isWeb ? Image.network(
        profileController.pickedFile!.path, width: size, height: size, fit: BoxFit.cover) : Image.file(
        File(profileController.pickedFile!.path), width: size, height: size, fit: BoxFit.cover) : CustomImageWidget(
        image: '${profileController.userInfoModel!.imageFullUrl}',
        height: size, width: size, fit: BoxFit.cover,
        placeholder: isLoggedIn ? Images.profilePlaceholder : Images.guestIcon,
        imageColor: isLoggedIn ? Theme.of(context).hintColor : null,
      )),

      Positioned(
        bottom: 0, right: 0, top: 0, left: 0,
        child: InkWell(
          onTap: () => profileController.pickImage(),
          customBorder: const CircleBorder(),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.3), shape: BoxShape.circle,
              border: Border.all(width: 1, color: Theme.of(context).primaryColor),
            ),
            child: Container(
              margin: EdgeInsets.all(size * 0.25),
              decoration: const BoxDecoration(
                border: Border.fromBorderSide(BorderSide(width: 2, color: Colors.white)),
                shape: BoxShape.circle,
              ),
              child: Icon(Symbols.camera_alt, color: Colors.white, size: size * 0.22),
            ),
          ),
        ),
      ),
    ]);
  }

  /// Saves just the name and photo. Phone and email are passed through
  /// unchanged so the API receives a complete payload.
  Future<void> _updateNameAndPhoto(ProfileController profileController) async {
    String name = _nameController.text.trim();
    if (name.isEmpty) {
      showCustomSnackBar('enter_your_name'.tr);
      return;
    }

    UpdateUserModel updatedUser = UpdateUserModel(
      name: name,
      email: profileController.userInfoModel!.email ?? '',
      phone: profileController.userInfoModel!.phone ?? '',
      buttonType: '',
    );
    await profileController.updateUserInfo(updatedUser, Get.find<AuthController>().getUserToken(), fromButton: true);
    widget.onUpdated?.call();
  }

  /// Name / phone / email inputs, shared by the embedded and standalone
  /// layouts so the fields and their verification affordances stay identical.
  List<Widget> _fields(BuildContext context, ProfileController profileController) {
    return [
      CustomTextFieldWidget(
        titleText: 'enter_name'.tr,
        controller: _nameController,
        capitalization: TextCapitalization.words,
        inputType: TextInputType.name,
        focusNode: _nameFocus,
        nextFocus: _emailFocus,
        prefixIcon: CupertinoIcons.person_alt_circle_fill,
        labelText: 'name'.tr,
        required: true,
        validator: (value) => ValidateCheck.validateEmptyText(value, "please_enter_first_name".tr),
      ),
      const SizedBox(height: Dimensions.paddingSizeExtraOverLarge),

      !_isPhoneLoading ? Stack(
        children: [
          CustomTextFieldWidget(
            titleText: 'write_phone_number'.tr,
            controller: _phoneController,
            focusNode: _phoneFocus,
            inputType: TextInputType.phone,
            prefixIcon: CupertinoIcons.lock_fill,
            isEnabled: !profileController.userInfoModel!.isPhoneVerified! || profileController.userInfoModel!.phone == null,
            fromUpdateProfile: true,
            labelText: 'phone'.tr,
            required: true,
            isPhone: true,
            onCountryChanged: (CountryCode countryCode) => _countryDialCode = countryCode.dialCode,
            countryDialCode: _countryDialCode ?? Get.find<LocalizationController>().locale.countryCode,
            suffixImage: profileController.userInfoModel!.isPhoneVerified! ? Images.verifiedIcon : null,
          ),

          Positioned(
            right: 15, top: 15,
            child: !profileController.userInfoModel!.isPhoneVerified! && Get.find<SplashController>().configModel!.centralizeLoginSetup!.phoneVerificationStatus! ? InkWell(
              onTap: () async {
                if (!profileController.userInfoModel!.isPhoneVerified! && Get.find<SplashController>().configModel!.centralizeLoginSetup!.phoneVerificationStatus!) {
                  Get.dialog(const CustomLoaderWidget());
                  await _updateProfile(profileController: profileController, fromButton: false, fromPhone: true);
                }
              },
              child: Image.asset(Images.unVerifiedIcon, height: 20, width: 20, fit: BoxFit.cover),
            ) : const SizedBox(),
          )
        ],
      ) : const Center(child: CircularProgressIndicator()),
      const SizedBox(height: Dimensions.paddingSizeExtraOverLarge),

      CustomTextFieldWidget(
        titleText: 'enter_email'.tr,
        controller: _emailController,
        focusNode: _emailFocus,
        inputType: TextInputType.emailAddress,
        prefixIcon: CupertinoIcons.mail_solid,
        labelText: 'email'.tr,
        required: true,
        validator: (value) => ValidateCheck.validateEmail(value),
        suffixImage: profileController.userInfoModel!.isEmailVerified! && profileController.userInfoModel!.email == _emailController.text
            ? Images.verifiedIcon
            : Get.find<SplashController>().configModel!.centralizeLoginSetup!.emailVerificationStatus!
            ? Images.unVerifiedIcon : null,
        suffixOnPressed: () async {
          if (!profileController.userInfoModel!.isEmailVerified! || profileController.userInfoModel!.email != _emailController.text) {
            Get.dialog(const CustomLoaderWidget());
            await _updateProfile(profileController: profileController, fromButton: false, fromPhone: false);
          }
        },
      ),
    ];
  }

  Future<void> _updateProfile({required ProfileController profileController, required bool fromButton, required bool fromPhone}) async {
    String name = _nameController.text.trim();
    String email = _emailController.text.trim();
    String phoneNumber = _phoneController.text.trim();
    String numberWithCountryCode = _countryDialCode! + phoneNumber;
    PhoneValid phoneValid = await CustomValidator.isPhoneValid(numberWithCountryCode);
    numberWithCountryCode = phoneValid.phone;

    if (name.isEmpty) {
      showCustomSnackBar('enter_your_name'.tr);
    } else if (!phoneValid.isValid) {
      showCustomSnackBar('invalid_phone_number'.tr);
    } else if (email.isEmpty) {
      showCustomSnackBar('enter_email_address'.tr);
    } else if (!GetUtils.isEmail(email)) {
      showCustomSnackBar('enter_a_valid_email_address'.tr);
    } else if (phoneNumber.isEmpty) {
      showCustomSnackBar('enter_phone_number'.tr);
    } else if (phoneNumber.length < 6) {
      showCustomSnackBar('enter_a_valid_phone_number'.tr);
    } else {
      UpdateUserModel updatedUser = UpdateUserModel(
        name: name, email: email, phone: numberWithCountryCode,
        buttonType: fromButton ? '' : fromPhone ? 'phone' : 'email',
      );
      await profileController.updateUserInfo(updatedUser, Get.find<AuthController>().getUserToken(), fromButton: fromButton);
      if (fromButton) {
        widget.onUpdated?.call();
      }
    }
  }
}

/// A single row on the profile screen; opens a bottom sheet carrying the
/// photo picker and name field.
class _EditProfileCard extends StatefulWidget {
  final TextEditingController nameController;
  final FocusNode nameFocus;
  final Widget avatar;
  final VoidCallback onSave;

  const _EditProfileCard({
    required this.nameController,
    required this.nameFocus,
    required this.avatar,
    required this.onSave,
  });

  @override
  State<_EditProfileCard> createState() => _EditProfileCardState();
}

class _EditProfileCardState extends State<_EditProfileCard> {
  void _openSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useRootNavigator: true,
      backgroundColor: Theme.of(context).cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(Dimensions.radiusExtraLarge)),
      ),
      builder: (sheetContext) {
        // Rebuilt by the controller so the picked photo previews immediately.
        return GetBuilder<ProfileController>(builder: (profileController) {
          return Padding(
            // Lifts the sheet clear of the keyboard while the name is focused.
            padding: EdgeInsets.only(bottom: MediaQuery.of(sheetContext).viewInsets.bottom),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
                child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [

                  Center(
                    child: Container(
                      height: 4, width: 40,
                      decoration: BoxDecoration(
                        color: Theme.of(context).disabledColor.withValues(alpha: 0.35),
                        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                      ),
                    ),
                  ),
                  const SizedBox(height: Dimensions.paddingSizeLarge),

                  Text('edit_profile'.tr, style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeLarge)),
                  const SizedBox(height: Dimensions.paddingSizeLarge),

                  Center(child: widget.avatar),
                  const SizedBox(height: Dimensions.paddingSizeLarge),

                  CustomTextFieldWidget(
                    titleText: 'enter_name'.tr,
                    controller: widget.nameController,
                    capitalization: TextCapitalization.words,
                    inputType: TextInputType.name,
                    focusNode: widget.nameFocus,
                    prefixIcon: CupertinoIcons.person_alt_circle_fill,
                    labelText: 'name'.tr,
                    required: true,
                    validator: (value) => ValidateCheck.validateEmptyText(value, "please_enter_first_name".tr),
                  ),
                  const SizedBox(height: Dimensions.paddingSizeLarge),

                  CustomButtonWidget(
                    isLoading: profileController.isLoading,
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      widget.onSave();
                    },
                    buttonText: 'update'.tr,
                  ),
                ]),
              ),
            ),
          );
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: AppSurface.card(context, radius: Dimensions.radiusDefault),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: _openSheet,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: Dimensions.paddingSizeDefault, vertical: Dimensions.paddingSizeDefault,
          ),
          child: Row(children: [
            Icon(Symbols.person, size: 20, color: Theme.of(context).primaryColor),
            const SizedBox(width: Dimensions.paddingSizeSmall),

            Expanded(
              child: Text('edit_profile'.tr, style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeDefault)),
            ),

            Icon(Symbols.chevron_right, color: Theme.of(context).hintColor),
          ]),
        ),
      ),
    );
  }
}
