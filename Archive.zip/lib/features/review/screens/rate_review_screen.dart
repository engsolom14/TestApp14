import 'package:countasty/features/review/controllers/review_controller.dart';
import 'package:countasty/features/review/domain/models/rate_review_model.dart';
import 'package:countasty/features/review/widgets/deliver_man_review_widget.dart';
import 'package:countasty/features/review/widgets/product_review_widget.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_app_bar_widget.dart';
import 'package:countasty/common/widgets/menu_drawer_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class RateReviewScreen extends StatefulWidget {
  final RateReviewModel rateReviewModel;
  const RateReviewScreen({super.key, required this.rateReviewModel});

  @override
  RateReviewScreenState createState() => RateReviewScreenState();
}

class RateReviewScreenState extends State<RateReviewScreen> with TickerProviderStateMixin {
  TabController? _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: widget.rateReviewModel.deliveryMan == null ? 1 : 2, initialIndex: 0, vsync: this);
    Get.find<ReviewController>().initRatingData(widget.rateReviewModel.orderDetailsList!);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: CustomAppBarWidget(title: 'rate_review'.tr),
      endDrawer: const MenuDrawerWidget(), endDrawerEnableOpenDragGesture: false,
      body: Column(children: [
        Center(
          child: SizedBox(
            width: Dimensions.webMaxWidth,
            // Align the pill's outer edge with the review list's page margin
            // (paddingSizeSmall here). The indicator is itself inset by 4, so
            // the container carries the remainder.
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: Dimensions.paddingSizeSmall - 4,
              ),
              child: TabBar(
              controller: _tabController,
              // Pill indicator, matching the bottom bar's active tab.
              indicator: BoxDecoration(
                color: Theme.of(context).primaryColor,
                borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                boxShadow: AppShadows.glow(Theme.of(context).primaryColor, opacity: 0.30),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              indicatorPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
              dividerColor: Colors.transparent,
              splashBorderRadius: BorderRadius.circular(Dimensions.radiusPill),
              labelColor: Colors.white,
              unselectedLabelColor: Theme.of(context).hintColor,
              unselectedLabelStyle: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall),
              labelStyle: robotoBold.copyWith(fontSize: Dimensions.fontSizeSmall),
              tabs: widget.rateReviewModel.deliveryMan != null ? [
                Tab(text: widget.rateReviewModel.orderDetailsList!.length > 1 ? 'items'.tr : 'item'.tr),
                Tab(text: 'delivery_man'.tr),
              ] : [
                Tab(text: widget.rateReviewModel.orderDetailsList!.length > 1 ? 'items'.tr : 'item'.tr),
              ],
              ),
            ),
          ),
        ),

        Expanded(child: TabBarView(
          controller: _tabController,
          children: widget.rateReviewModel.deliveryMan != null ? [
            ProductReviewWidget(orderDetailsList: widget.rateReviewModel.orderDetailsList!),
            DeliveryManReviewWidget(deliveryMan: widget.rateReviewModel.deliveryMan, orderID: widget.rateReviewModel.orderDetailsList![0].orderId.toString()),
          ] : [
            ProductReviewWidget(orderDetailsList: widget.rateReviewModel.orderDetailsList!),
          ],
        )),

      ]),
    );
  }
}
