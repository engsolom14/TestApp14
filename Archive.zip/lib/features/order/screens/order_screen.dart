import 'package:countasty/features/order/controllers/order_controller.dart';
import 'package:countasty/features/order/widgets/guest_track_order_input_view_widget.dart';
import 'package:countasty/features/order/widgets/order_view_widget.dart';
import 'package:countasty/helper/auth_helper.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_app_bar_widget.dart';
import 'package:countasty/common/widgets/menu_drawer_widget.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OrderScreen extends StatefulWidget {
  const OrderScreen({super.key});

  @override
  OrderScreenState createState() => OrderScreenState();
}

class OrderScreenState extends State<OrderScreen> with TickerProviderStateMixin {
  TabController? _tabController;

  @override
  void initState() {
    super.initState();

    _tabController = TabController(length: 3, initialIndex: 0, vsync: this);
    initCall();
  }

  void initCall(){
    if(AuthHelper.isLoggedIn()) {
      Get.find<OrderController>().getRunningOrders(1, limit: 10, notify: false);
      Get.find<OrderController>().getRunningSubscriptionOrders(1, notify: false);
      Get.find<OrderController>().getHistoryOrders(1, notify: false);
      // Get.find<OrderController>().getSubscriptions(1, notify: false);
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isLoggedIn = AuthHelper.isLoggedIn();
    return Scaffold(
      appBar: CustomAppBarWidget(title: 'my_orders'.tr, isBackButtonExist: ResponsiveHelper.isDesktop(context)),
      endDrawer: const MenuDrawerWidget(), endDrawerEnableOpenDragGesture: false,
      body: isLoggedIn ? GetBuilder<OrderController>(
        builder: (orderController) {
          return Column(children: [

            Container(
              color: ResponsiveHelper.isDesktop(context) ? Theme.of(context).primaryColor.withValues(alpha: 0.1) : Colors.transparent,
              child: Column(children: [

                ResponsiveHelper.isDesktop(context) ? Center(child: Padding(
                  padding: const EdgeInsets.only(top: Dimensions.paddingSizeSmall),
                  child: Text('my_orders'.tr, style: robotoMedium),
                )) : const SizedBox(),

                Center(
                  child: SizedBox(
                    width: Dimensions.webMaxWidth,
                    child: Align(
                      alignment: ResponsiveHelper.isDesktop(context) ? Alignment.centerLeft : Alignment.center,
                      child: SizedBox(
                        width: ResponsiveHelper.isDesktop(context) ? 350 : Dimensions.webMaxWidth,
                        // Align the pill's outer edge with the page margin the
                        // order list uses (paddingSizeSmall here, not the
                        // Default the favourites list uses). The indicator is
                        // itself inset by 4, so the container carries the
                        // remainder.
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: Dimensions.paddingSizeSmall - 4,
                          ),
                          child: TabBar(
                          controller: _tabController,
                          // Pill indicator, matching the bottom bar's active tab.
                          indicator: BoxDecoration(
                            color: Theme.of(context).primaryColor,
                            borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                            boxShadow: AppShadows.glow(Theme.of(context).primaryColor, opacity: 0.30),
                          ),
                          indicatorSize: TabBarIndicatorSize.tab,
                          // Horizontal inset so the three pills don't touch,
                          // matching the favourites switcher.
                          indicatorPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                          dividerColor: Colors.transparent,
                          splashBorderRadius: BorderRadius.circular(Dimensions.radiusPill),
                          labelColor: Colors.white,
                          unselectedLabelColor: Theme.of(context).hintColor,
                          unselectedLabelStyle: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall),
                          labelStyle: robotoBold.copyWith(fontSize: Dimensions.fontSizeSmall),
                          tabs: [
                            Tab(text: 'running'.tr),
                            Tab(text: 'subscription'.tr),
                            Tab(text: 'history'.tr),
                          ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
              ),
            ),

            Expanded(child: TabBarView(
              controller: _tabController,
              children: const [
                OrderViewWidget(isRunning: true),
                OrderViewWidget(isRunning: false, isSubscription: true),
                OrderViewWidget(isRunning: false),
              ],
            )),

          ]);
        },
      ) : const GuestTrackOrderInputViewWidget(),
    );
  }
}
