import 'package:countasty/features/splash/controllers/theme_controller.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

/// Settings row for choosing between the two dark palettes.
///
/// A segmented control rather than an on/off switch: with a switch the label
/// has to describe the "on" state, which leaves the other option unnamed. Here
/// both styles are named and the selected one is filled, so the choice reads
/// without having to work out which way the switch points.
///
/// Visual language is lifted from the search screen's tab bar — pill indicator
/// in the primary colour with the same glow — so this reads as a control the
/// app already has rather than a new invention.
class DarkStyleSelectorWidget extends StatelessWidget {
  const DarkStyleSelectorWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ThemeController>(builder: (ThemeController themeController) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall),
        child: Row(children: [
          Icon(Symbols.palette, size: 20, color: Theme.of(context).textTheme.bodyMedium!.color),
          const SizedBox(width: Dimensions.paddingSizeSmall),

          Expanded(child: Text('dark_style'.tr, style: robotoRegular)),

          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(Dimensions.radiusPill),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
              _segment(
                context,
                label: 'dark_style_warm'.tr,
                selected: themeController.isWarmDark,
                onTap: () => themeController.setDarkStyle(DarkThemeStyle.warm),
              ),
              _segment(
                context,
                label: 'dark_style_classic'.tr,
                selected: !themeController.isWarmDark,
                onTap: () => themeController.setDarkStyle(DarkThemeStyle.classic),
              ),
            ]),
          ),
        ]),
      );
    });
  }

  Widget _segment(
    BuildContext context, {
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.paddingSizeDefault,
          vertical: Dimensions.paddingSizeExtraSmall + 1,
        ),
        decoration: BoxDecoration(
          color: selected ? Theme.of(context).primaryColor : Colors.transparent,
          borderRadius: BorderRadius.circular(Dimensions.radiusPill),
          boxShadow: selected
              ? AppShadows.glow(Theme.of(context).primaryColor, opacity: 0.30)
              : null,
        ),
        child: Text(
          label,
          style: selected
              ? robotoBold.copyWith(fontSize: Dimensions.fontSizeSmall, color: Colors.white)
              : robotoMedium.copyWith(
                  fontSize: Dimensions.fontSizeSmall,
                  color: Theme.of(context).hintColor,
                ),
        ),
      ),
    );
  }
}
