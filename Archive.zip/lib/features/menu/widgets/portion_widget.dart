
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PortionWidget extends StatelessWidget {
  /// Asset path for the row glyph. Leave null when supplying [iconData].
  final String? icon;

  /// Material Symbol alternative to [icon], for rows with no bespoke artwork.
  final IconData? iconData;
  final String title;
  final bool hideDivider;
  final String route;
  final String? suffix;

  /// Quiet trailing content before the row ends — a version string, a stack of
  /// platform icons. Distinct from [suffix], which is the red count badge.
  final Widget? trailing;

  final Function()? onTap;
  final bool tintIcon;
  const PortionWidget({
    super.key,
    this.icon,
    this.iconData,
    required this.title,
    required this.route,
    this.hideDivider = false,
    this.suffix,
    this.trailing,
    this.onTap,
    this.tintIcon = true,
  });

  /// Lets a parent suppress the divider on the last visible row of a section
  /// without every call site having to know its own position.
  PortionWidget copyWithHiddenDivider() => PortionWidget(
    key: key,
    icon: icon,
    iconData: iconData,
    title: title,
    route: route,
    hideDivider: true,
    suffix: suffix,
    trailing: trailing,
    onTap: onTap,
    tintIcon: tintIcon,
  );

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap ?? () => Get.toNamed(route),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall),
        child: Column(children: [
          Row(children: [
            // Tinted to the same quiet grey as the tab bar glyphs so list
            // icons read as flat wayfinding, not heavy black marks.
            iconData != null
                ? Icon(iconData, size: 20, color: Theme.of(context).hintColor)
                : Image.asset(
                    icon!,
                    height: 20,
                    width: 20,
                    color: tintIcon ? Theme.of(context).hintColor : null,
                  ),
            const SizedBox(width: Dimensions.paddingSizeDefault),

            Expanded(child: Text(title, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeDefault))),

            trailing != null ? Padding(
              padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
              child: trailing!,
            ) : const SizedBox(),

            suffix != null ? Container(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.error,
                borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
              ),
              padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeExtraSmall, horizontal: Dimensions.paddingSizeSmall),
              child: Text(suffix!, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Colors.white)),
            ) : const SizedBox(),
          ]),
          hideDivider ? const SizedBox() : const Divider()
        ]),
      ),
    );
  }
}
