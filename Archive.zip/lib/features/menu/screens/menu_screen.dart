import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/cart/controllers/cart_controller.dart';
import 'package:countasty/features/language/controllers/localization_controller.dart';
import 'package:countasty/features/language/widgets/language_bottom_sheet_widget.dart';
import 'package:countasty/features/menu/widgets/portion_widget.dart';
import 'package:countasty/features/profile/controllers/profile_controller.dart';
import 'package:countasty/features/profile/widgets/profile_button_widget.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/features/splash/controllers/theme_controller.dart';
import 'package:countasty/features/menu/widgets/dark_style_selector_widget.dart';
import 'package:countasty/features/auth/screens/sign_in_screen.dart';
import 'package:countasty/features/favourite/controllers/favourite_controller.dart';
import 'package:countasty/helper/auth_helper.dart';
import 'package:countasty/helper/date_converter.dart';
import 'package:countasty/helper/price_converter.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/images.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/confirmation_dialog_widget.dart';
import 'package:countasty/common/widgets/custom_image_widget.dart';
import 'package:countasty/common/widgets/logo_mask_widget.dart';
import 'package:countasty/features/profile/widgets/profile_card_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shimmer_animation/shimmer_animation.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:countasty/features/splash/domain/models/config_model.dart';
import 'package:countasty/util/app_constants.dart';
import 'package:countasty/features/social/widgets/social_chip_widget.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: GetBuilder<ProfileController>(
        builder: (profileController) {
          final bool isLoggedIn = Get.find<AuthController>().isLoggedIn();

          return Column(children: [

            /// Hero card — same treatment as the profile screen so the two
            /// read as one identity, instead of a flat orange banner.
            /// The whole card is the way into Profile — a bigger, more obvious
            /// target than the "Profile" row further down the list.
            InkWell(
              onTap: () {
                if (isLoggedIn) {
                  Get.toNamed(RouteHelper.getProfileRoute());
                } else if (!ResponsiveHelper.isDesktop(context)) {
                  Get.toNamed(RouteHelper.getSignInRoute(Get.currentRoute))?.then((value) {
                    if (AuthHelper.isLoggedIn()) {
                      profileController.getUserInfo();
                    }
                  });
                } else {
                  Get.dialog(const SignInScreen(exitFromApp: true, backFromThis: true)).then((value) {
                    if (AuthHelper.isLoggedIn()) {
                      profileController.getUserInfo();
                    }
                  });
                }
              },
              borderRadius: BorderRadius.circular(Dimensions.radiusExtraLarge),
              child: Container(
              margin: const EdgeInsets.fromLTRB(
                Dimensions.paddingSizeDefault, 60,
                Dimensions.paddingSizeDefault, Dimensions.paddingSizeSmall,
              ),
              padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(Dimensions.radiusExtraLarge),
                gradient: LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  // A neutral surface with only a whisper of brand warmth. A
                  // heavier orange wash on a dark ground turns to mud brown no
                  // matter what sits underneath, so the orange is carried by
                  // the badge and text instead of the panel itself.
                  colors: [
                    Color.alphaBlend(
                      Theme.of(context).primaryColor.withValues(alpha: 0.05),
                      Theme.of(context).cardColor,
                    ),
                    Theme.of(context).cardColor,
                  ],
                ),
                border: Border.all(color: AppSurface.hairline(context), width: 1),
                boxShadow: AppShadows.card,
              ),
              child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [

                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [

                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall, vertical: 4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor.withValues(alpha: 0.85),
                        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                      ),
                      child: Text(
                        isLoggedIn && profileController.userInfoModel?.createdAt != null
                            ? '${'joined'.tr} ${DateConverter.containTAndZToUTCFormat(profileController.userInfoModel!.createdAt!)}'
                            : 'guest'.tr,
                        style: robotoMedium.copyWith(
                          fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).primaryColor,
                        ),
                      ),
                    ),
                    const SizedBox(height: Dimensions.paddingSizeSmall),

                    isLoggedIn && profileController.userInfoModel == null ? Shimmer(
                      duration: const Duration(seconds: 2),
                      enabled: true,
                      child: Container(
                        height: 22, width: 170,
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor.withValues(alpha: 0.7),
                          borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
                        ),
                      ),
                    ) : Text(
                      isLoggedIn ? '${profileController.userInfoModel?.fName ?? ''} ${profileController.userInfoModel?.lName ?? ''}'.trim() : 'guest_user'.tr,
                      style: displaySemiBold.copyWith(fontSize: 26, height: 1.05),
                      maxLines: 2, overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                    isLoggedIn ? Text(
                      profileController.userInfoModel?.email ?? '',
                      style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).hintColor),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ) : InkWell(
                      onTap: () {
                        if(!ResponsiveHelper.isDesktop(context)) {
                          Get.toNamed(RouteHelper.getSignInRoute(Get.currentRoute))?.then((value) {
                            if(AuthHelper.isLoggedIn()) {
                              profileController.getUserInfo();
                            }
                          });
                        }else{
                          Get.dialog(const SignInScreen(exitFromApp: true, backFromThis: true)).then((value) {
                            if(AuthHelper.isLoggedIn()) {
                              profileController.getUserInfo();
                            }
                          });
                        }
                      },
                      child: Text(
                        'login_to_view_all_feature'.tr,
                        style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).primaryColor),
                      ),
                    ),
                  ]),
                ),
                const SizedBox(width: Dimensions.paddingSizeSmall),

                LogoMaskWidget(size: 118, child: CustomImageWidget(
                  placeholder: isLoggedIn ? Images.profilePlaceholder : Images.guestIcon,
                  image: '${(profileController.userInfoModel != null && isLoggedIn) ? profileController.userInfoModel!.imageFullUrl : ''}',
                  height: 118, width: 118, fit: BoxFit.cover, imageColor: isLoggedIn ? Theme.of(context).hintColor : null,
                )),
              ]),
            ),
            ),

            Expanded(child: SingleChildScrollView(
              child: Ink(
                color: Theme.of(context).colorScheme.surface,
                padding: const EdgeInsets.only(top: Dimensions.paddingSizeSmall),
                child: Column(children: [

                  /// Account stats, lifted out of the Profile screen so they
                  /// are visible — and reachable — from the menu itself.
                  isLoggedIn ? Padding(
                    padding: const EdgeInsets.fromLTRB(
                      Dimensions.paddingSizeDefault, 0,
                      Dimensions.paddingSizeDefault, Dimensions.paddingSizeDefault,
                    ),
                    child: Row(children: [

                      Get.find<SplashController>().configModel!.loyaltyPointStatus == 1 ? Expanded(child: ProfileCardWidget(
                        image: Images.loyaltyIcon,
                        data: profileController.userInfoModel?.loyaltyPoint != null ? profileController.userInfoModel!.loyaltyPoint.toString() : '0',
                        title: 'loyalty_points'.tr,
                        onTap: () => Get.toNamed(RouteHelper.getLoyaltyRoute()),
                      )) : const SizedBox(),
                      SizedBox(width: Get.find<SplashController>().configModel!.loyaltyPointStatus == 1 ? Dimensions.paddingSizeSmall : 0),

                      Expanded(child: ProfileCardWidget(
                        image: Images.shoppingBagIcon,
                        data: profileController.userInfoModel?.orderCount != null ? profileController.userInfoModel!.orderCount.toString() : '0',
                        title: 'total_order'.tr,
                      )),
                      SizedBox(width: Get.find<SplashController>().configModel!.customerWalletStatus == 1 ? Dimensions.paddingSizeSmall : 0),

                      Get.find<SplashController>().configModel!.customerWalletStatus == 1 ? Expanded(child: ProfileCardWidget(
                        image: Images.walletProfile,
                        data: PriceConverter.convertPrice(profileController.userInfoModel?.walletBalance != null ? profileController.userInfoModel!.walletBalance : 0),
                        title: 'wallet_balance'.tr,
                        onTap: () => Get.toNamed(RouteHelper.getWalletRoute(fromMenuPage: true)),
                      )) : const SizedBox(),
                    ]),
                  ) : const SizedBox(),


                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                      child: Text(
                        'general'.tr,
                        style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeDefault, color: Theme.of(context).hintColor),
                      ),
                    ),

                    Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                        border: Border.all(color: AppSurface.hairline(context), width: 1),
                        boxShadow: AppShadows.card,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeLarge, vertical: Dimensions.paddingSizeDefault),
                      margin: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                      child: Column(children: _section([
                        PortionWidget(icon: Images.loyaltyIcon, title: 'my_goal'.tr, route: RouteHelper.getNutritionRoute()),
                        PortionWidget(icon: Images.addressIcon, title: 'my_address'.tr, route: RouteHelper.getAddressRoute()),
                        PortionWidget(
                          icon: Images.egypt,
                          tintIcon: false,
                          title: 'language'.tr,
                          onTap: () => _manageLanguageFunctionality(),
                          route: '',
                        ),

                        ProfileButtonWidget(icon: Symbols.tonality, title: 'dark_mode'.tr, isButtonActive: Get.isDarkMode, isThemeSwitchButton: true,
                          onTap: () {
                            Get.find<ThemeController>().toggleTheme();
                          },
                        ),

                        // Only offered while dark is actually on — picking a dark
                        // palette from a light screen shows you nothing.
                        if (Get.find<ThemeController>().darkTheme)
                          const DarkStyleSelectorWidget(),
                      ])),
                    ),

                  ]),

                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                      child: Text(
                        'promotional_activity'.tr,
                        style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeDefault, color: Theme.of(context).hintColor),
                      ),
                    ),

                    Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                        border: Border.all(color: AppSurface.hairline(context), width: 1),
                        boxShadow: AppShadows.card,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeLarge, vertical: Dimensions.paddingSizeDefault),
                      margin: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                      child: Column(children: _section([

                        PortionWidget(icon: Images.couponIcon, title: 'coupon'.tr, route: RouteHelper.getCouponRoute(fromCheckout: false)),

                        (Get.find<SplashController>().configModel!.refEarningStatus == 1 ) ? PortionWidget(
                          icon: Images.referIcon, title: 'refer_and_earn'.tr, route: RouteHelper.getReferAndEarnRoute(),
                        ) : const SizedBox(),

                        (Get.find<SplashController>().configModel!.toggleDmRegistration! && !ResponsiveHelper.isDesktop(context)) ? PortionWidget(
                          icon: Images.dmIcon, title: 'join_as_a_delivery_man'.tr, route: RouteHelper.getDeliverymanRegistrationRoute(),
                        ) : const SizedBox(),

                        (Get.find<SplashController>().configModel!.toggleRestaurantRegistration! && !ResponsiveHelper.isDesktop(context)) ? PortionWidget(
                          icon: Images.storeIcon, title: 'open_store'.tr, route: RouteHelper.getRestaurantRegistrationRoute(),
                        ) : const SizedBox(),
                      ])),
                    )
                  ]),

                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                      child: Text(
                        'help_and_support'.tr,
                        style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeDefault, color: Theme.of(context).hintColor),
                      ),
                    ),

                    Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                        border: Border.all(color: AppSurface.hairline(context), width: 1),
                        boxShadow: AppShadows.card,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeLarge, vertical: Dimensions.paddingSizeDefault),
                      margin: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                      child: Column(children: _section([
                        PortionWidget(icon: Images.chatIcon, title: 'live_chat'.tr, route: RouteHelper.getConversationRoute()),
                        PortionWidget(icon: Images.helpIcon, title: 'help_and_support'.tr, route: RouteHelper.getSupportRoute()),
                        PortionWidget(
                          iconData: Symbols.public, title: 'follow_us'.tr, route: RouteHelper.getFollowUsRoute(),
                          trailing: _SocialIconStack(
                            channels: Get.find<SplashController>().configModel?.socialMedia,
                          ),
                        ),

                        PortionWidget(
                          icon: Images.aboutIcon, title: 'about_us'.tr, route: RouteHelper.getHtmlRoute('about-us'),
                          trailing: Text(
                            'v${AppConstants.appVersion}',
                            style: robotoRegular.copyWith(
                              fontSize: Dimensions.fontSizeSmall,
                              color: Theme.of(context).hintColor,
                            ),
                          ),
                        ),
                        PortionWidget(icon: Images.termsIcon, title: 'terms_conditions'.tr, route: RouteHelper.getHtmlRoute('terms-and-condition')),
                        PortionWidget(icon: Images.privacyIcon, title: 'privacy_policy'.tr, route: RouteHelper.getHtmlRoute('privacy-policy')),

                        (Get.find<SplashController>().configModel!.refundPolicyStatus == 1 ) ? PortionWidget(
                          icon: Images.refundIcon, title: 'refund_policy'.tr, route: RouteHelper.getHtmlRoute('refund-policy'),
                        ) : const SizedBox(),

                        (Get.find<SplashController>().configModel!.cancellationPolicyStatus == 1 ) ? PortionWidget(
                          icon: Images.cancelationIcon, title: 'cancellation_policy'.tr, route: RouteHelper.getHtmlRoute('cancellation-policy'),
                        ) : const SizedBox(),

                        (Get.find<SplashController>().configModel!.shippingPolicyStatus == 1 ) ? PortionWidget(
                          icon: Images.shippingIcon, title: 'shipping_policy'.tr, route: RouteHelper.getHtmlRoute('shipping-policy'),
                        ) : const SizedBox(),

                      ])),
                    )
                  ]),

                  InkWell(
                    onTap: () async {
                      if(Get.find<AuthController>().isLoggedIn()) {
                        Get.dialog(ConfirmationDialogWidget(icon: Images.support, description: 'are_you_sure_to_logout'.tr, isLogOut: true, onYesPressed: () async {
                          Get.find<ProfileController>().setForceFullyUserEmpty();
                          Get.find<AuthController>().socialLogout();
                          Get.find<CartController>().clearCartList();
                          Get.find<FavouriteController>().removeFavourites();
                          await Get.find<AuthController>().clearSharedData();
                          Get.offAllNamed(RouteHelper.getInitialRoute());
                        }), useSafeArea: false);
                      }else {
                        Get.find<FavouriteController>().removeFavourites();
                        await Get.toNamed(RouteHelper.getSignInRoute(Get.currentRoute));
                        if(AuthHelper.isLoggedIn()) {
                          await Get.find<FavouriteController>().getFavouriteList();
                          profileController.getUserInfo();
                        }
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Container(
                          padding: const EdgeInsets.all(2),
                          decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.red),
                          child: Icon(Symbols.power_settings_new_sharp, size: 14, color: Theme.of(context).cardColor),
                        ),
                        const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                        Text(Get.find<AuthController>().isLoggedIn() ? 'logout'.tr : 'sign_in'.tr, style: robotoMedium)
                      ]),
                    ),
                  ),

                  // Clear the floating tab bar (62) + its padding + the home
                  // indicator, so Logout is reachable rather than sitting under it.
                  SizedBox(height: 96 + MediaQuery.of(context).padding.bottom)

                ]),
              ),
            )),
          ]);
        }
      ),
    );
  }

  /// Drops empty entries (config-disabled rows collapse to SizedBox) and hides
  /// the divider on whatever ends up last, so a section never trails a rule.
  List<Widget> _section(List<Widget> children) {
    final List<Widget> visible = children.where((child) => child is! SizedBox).toList();
    if (visible.isEmpty) return visible;

    final Widget last = visible.removeLast();
    visible.add(last is PortionWidget ? last.copyWithHiddenDivider() : last);
    return visible;
  }

  _manageLanguageFunctionality() {
    Get.find<LocalizationController>().saveCacheLanguage(null);
    Get.find<LocalizationController>().searchSelectedLanguage();

    showModalBottomSheet(
      isScrollControlled: true, useRootNavigator: true, context: Get.context!,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(topLeft: Radius.circular(Dimensions.radiusExtraLarge), topRight: Radius.circular(Dimensions.radiusExtraLarge)),
      ),
      builder: (context) {
        return ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.8),
          child: const LanguageBottomSheetWidget(),
        );
      },
    ).then((value) => Get.find<LocalizationController>().setLanguage(Get.find<LocalizationController>().getCacheLocaleFromSharedPref()));
  }
}

/// The platform marks, overlapped, as a hint of what the row leads to —
/// the same shorthand other apps' settings screens use.
class _SocialIconStack extends StatelessWidget {
  final List<SocialMedia>? channels;
  const _SocialIconStack({this.channels});

  @override
  Widget build(BuildContext context) {
    final List<String> names = (channels ?? <SocialMedia>[])
        .where((SocialMedia s) => s.status == 1 && SocialBrand.isKnown(s.name))
        .map((SocialMedia s) => s.name!)
        .take(4)
        .toList();

    if (names.isEmpty) return const SizedBox();

    const double size = 22;
    const double overlap = 15;

    return SizedBox(
      height: size,
      width: overlap * (names.length - 1) + size,
      child: Stack(children: List<Widget>.generate(names.length, (int i) {
        return Positioned(
          left: i * overlap,
          child: SocialChipWidget(
            name: names[i], size: size, ringColor: Theme.of(context).cardColor,
          ),
        );
      })),
    );
  }
}
