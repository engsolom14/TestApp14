import 'package:get/get.dart';
import 'package:countasty/features/calculator/domain/models/calculator_form_model.dart';

class CalculatorController extends GetxController implements GetxService {
  late CalculatorFormModel formModel;

  CalculatorController() {
    formModel = CalculatorFormModel();
  }

  double calculateCalories() {
    double bmr;
    if (formModel.gender == 0) {
      bmr = (10 * formModel.weight!) + (6.25 * formModel.height!) - (5 * formModel.age!) + 5;
    } else {
      bmr = (10 * formModel.weight!) + (6.25 * formModel.height!) - (5 * formModel.age!) - 161;
    }

    double tdee = bmr * formModel.activity!;
    return tdee;
  }
}
