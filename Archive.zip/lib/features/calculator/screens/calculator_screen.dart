import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/calculator_controller.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  final _formKey = GlobalKey<FormState>();
  late CalculatorController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.put(CalculatorController());
  }

  @override
  Widget build(BuildContext context) {
    final activityLevels = [
      {"label": "BMR (no activity)", "value": 1.0},
      {"label": "Sedentary (little/no exercise)", "value": 1.2},
      {"label": "Light (1–3x/week)", "value": 1.375},
      {"label": "Moderate (3–5x/week)", "value": 1.55},
      {"label": "Active (6–7x/week)", "value": 1.725},
      {"label": "Very Active (hard exercise)", "value": 1.9},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Calorie Calculator")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Age"),
                validator: (val) {
                  if (val == null || val.isEmpty) return "Age is required";
                  final age = int.tryParse(val);
                  if (age == null || age <= 0) return "Enter a valid age";
                  return null;
                },
                onSaved: (val) => controller.formModel.age = int.tryParse(val ?? ""),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                value: controller.formModel.gender,
                items: const [
                  DropdownMenuItem(value: 0, child: Text("Male")),
                  DropdownMenuItem(value: 1, child: Text("Female")),
                ],
                validator: (val) => val == null ? "Please select gender" : null,
                onChanged: (val) => controller.formModel.gender = val,
                decoration: const InputDecoration(labelText: "Gender"),
              ),
              const SizedBox(height: 12),
              TextFormField(
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Height (cm)"),
                validator: (val) {
                  if (val == null || val.isEmpty) return "Height is required";
                  final h = double.tryParse(val);
                  if (h == null || h <= 0) return "Enter valid height";
                  return null;
                },
                onSaved: (val) => controller.formModel.height = double.tryParse(val ?? ""),
              ),
              const SizedBox(height: 12),
              TextFormField(
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Weight (kg)"),
                validator: (val) {
                  if (val == null || val.isEmpty) return "Weight is required";
                  final w = double.tryParse(val);
                  if (w == null || w <= 0) return "Enter valid weight";
                  return null;
                },
                onSaved: (val) => controller.formModel.weight = double.tryParse(val ?? ""),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<double>(
                value: controller.formModel.activity,
                items: activityLevels
                    .map((a) => DropdownMenuItem<double>(
                          value: a["value"] as double,
                          child: Text(a["label"] as String),
                        ))
                    .toList(),
                validator: (val) => val == null ? "Please select activity" : null,
                onChanged: (val) => controller.formModel.activity = val,
                decoration: const InputDecoration(labelText: "Activity Level"),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();

                    final calories = controller.calculateCalories();
                    Get.snackbar(
                      "Result",
                      "Estimated Calories: ${calories.toStringAsFixed(0)}",
                      snackPosition: SnackPosition.BOTTOM,
                    );
                  }
                },
                child: const Text("Calculate"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
