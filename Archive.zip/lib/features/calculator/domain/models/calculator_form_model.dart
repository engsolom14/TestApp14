class CalculatorFormModel {
  int? age;
  int? gender; // 0 = male, 1 = female
  double? height;
  double? weight;
  double? activity;

  CalculatorFormModel({
    this.age,
    this.gender,
    this.height,
    this.weight,
    this.activity,
  });

  factory CalculatorFormModel.fromJson(Map<String, dynamic> json) {
    return CalculatorFormModel(
      age: json['age'] ?? 0,
      gender: json['gender'] ?? 0,
      height: (json['height'] ?? 0).toDouble(),
      weight: (json['weight'] ?? 0).toDouble(),
      activity: (json['activity'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'age': age,
      'gender': gender,
      'height': height,
      'weight': weight,
      'activity': activity,
    };
  }
}
