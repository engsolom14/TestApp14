import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:countasty/common/widgets/no_internet_screen_widget.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/cart/controllers/cart_controller.dart';
import 'package:countasty/features/notification/domain/models/notification_body_model.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/features/splash/domain/models/deep_link_body.dart';
import 'package:countasty/helper/address_helper.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/images.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SplashScreen extends StatefulWidget {
  final NotificationBodyModel? notificationBody;
  final DeepLinkBody? linkBody;
  const SplashScreen({super.key, required this.notificationBody, required this.linkBody});

  @override
  SplashScreenState createState() => SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _globalKey = GlobalKey();
  StreamSubscription<List<ConnectivityResult>>? _onConnectivityChanged;

  /// Entrance: logo settles in, wordmark follows.
  late final AnimationController _intro = AnimationController(
    vsync: this, duration: const Duration(milliseconds: 1100),
  );

  /// Breathing pulse that runs while the splash waits on config, so a slow
  /// network reads as "working" rather than "frozen".
  late final AnimationController _pulse = AnimationController(
    vsync: this, duration: const Duration(milliseconds: 1800),
  );

  // Staggered off one controller so the parts stay in lockstep.
  late final Animation<double> _logoFade = CurvedAnimation(
    parent: _intro, curve: const Interval(0.00, 0.45, curve: Curves.easeOutCubic),
  );
  late final Animation<double> _logoScale = Tween<double>(begin: 0.82, end: 1.0).animate(
    CurvedAnimation(parent: _intro, curve: const Interval(0.00, 0.55, curve: Curves.easeOutQuart)),
  );
  late final Animation<double> _haloScale = Tween<double>(begin: 0.6, end: 1.0).animate(
    CurvedAnimation(parent: _intro, curve: const Interval(0.05, 0.70, curve: Curves.easeOutQuart)),
  );
  late final Animation<double> _nameFade = CurvedAnimation(
    parent: _intro, curve: const Interval(0.35, 0.80, curve: Curves.easeOutCubic),
  );
  late final Animation<double> _nameSlide = Tween<double>(begin: 14, end: 0).animate(
    CurvedAnimation(parent: _intro, curve: const Interval(0.35, 0.85, curve: Curves.easeOutQuart)),
  );

  @override
  void initState() {
    super.initState();

    bool firstTime = true;
    _onConnectivityChanged = Connectivity().onConnectivityChanged.listen((List<ConnectivityResult> result) {
      bool isConnected = result.contains(ConnectivityResult.wifi) || result.contains(ConnectivityResult.mobile);

      if(!firstTime) {
        ScaffoldMessenger.of(Get.context!).hideCurrentSnackBar();
        ScaffoldMessenger.of(Get.context!).showSnackBar(SnackBar(
          backgroundColor: isConnected ? Colors.green : Colors.red,
          duration: Duration(seconds: isConnected ? 3 : 6000),
          content: Text(isConnected ? 'connected'.tr : 'no_connection'.tr, textAlign: TextAlign.center),
        ));
        if(isConnected) {
          _route();
        }else {
          Get.to(const NoInternetScreen());
        }
      }

      firstTime = false;

    });

    Get.find<SplashController>().initSharedData();
    if(AddressHelper.getAddressFromSharedPref() != null && (AddressHelper.getAddressFromSharedPref()!.zoneIds == null
        || AddressHelper.getAddressFromSharedPref()!.zoneData == null)) {
      AddressHelper.clearAddressFromSharedPref();
    }
    if(Get.find<AuthController>().isGuestLoggedIn() || Get.find<AuthController>().isLoggedIn()) {
      Get.find<CartController>().getCartDataOnline();
    }
    _route();

  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Honour the OS "reduce motion" setting: show the final frame instead.
    if (MediaQuery.of(context).disableAnimations) {
      _intro.value = 1.0;
    } else if (!_intro.isAnimating && _intro.value == 0) {
      _intro.forward();
      _pulse.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _intro.dispose();
    _pulse.dispose();
    super.dispose();

    _onConnectivityChanged?.cancel();
  }

  /// How long the splash is held open so the entrance animation can play.
  /// On a warm start config resolves from cache almost instantly, which would
  /// otherwise route away before the first frame of the animation is seen.
  /// This is the cost of having an animated splash at all — lower it or set it
  /// to Duration.zero to go back to routing as soon as config is ready.
  static const Duration _minSplashDuration = Duration(milliseconds: 1150);

  void _route() {
    Future.delayed(_minSplashDuration, () {
      if (!mounted) return;
      Get.find<SplashController>().getConfigData(
        handleMaintenanceMode: false, notificationBody: widget.notificationBody,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _globalKey,
      body: GetBuilder<SplashController>(builder: (splashController) {
        return Center(
          child: splashController.hasConnection ? Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              /// Logo: fades and scales in, then breathes while config loads.
              AnimatedBuilder(
                animation: Listenable.merge([_intro, _pulse]),
                builder: (context, child) {
                  // Pulse only after the entrance has settled, so the two
                  // motions never fight each other.
                  final double breathe = 1 + (0.035 * _pulse.value * _intro.value);
                  return Opacity(
                    opacity: _logoFade.value,
                    child: Transform.scale(
                      scale: _logoScale.value * breathe,
                      child: child,
                    ),
                  );
                },
                child: Stack(alignment: Alignment.center, children: [

                  /// Soft brand halo — light spilling off the mark.
                  AnimatedBuilder(
                    animation: Listenable.merge([_intro, _pulse]),
                    builder: (context, _) => Container(
                      height: 190, width: 190,
                      transform: Matrix4.diagonal3Values(_haloScale.value, _haloScale.value, 1),
                      transformAlignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Theme.of(context).primaryColor
                            .withValues(alpha: 0.06 + (0.05 * _pulse.value)),
                      ),
                    ),
                  ),

                  Image.asset(Images.logo, width: 110),
                ]),
              ),
              const SizedBox(height: Dimensions.paddingSizeLarge),

              /// Wordmark: rises in just behind the logo.
              AnimatedBuilder(
                animation: _intro,
                builder: (context, child) => Opacity(
                  opacity: _nameFade.value,
                  child: Transform.translate(offset: Offset(0, _nameSlide.value), child: child),
                ),
                child: Image.asset(Images.logoName, width: 150),
              ),
            ],
          ) : NoInternetScreen(child: SplashScreen(notificationBody: widget.notificationBody, linkBody: widget.linkBody)),
        );
      }),
    );
  }
}
