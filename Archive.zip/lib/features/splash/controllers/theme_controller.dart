import 'package:countasty/features/splash/domain/services/splash_service_interface.dart';
import 'package:countasty/theme/dark_theme.dart';
import 'package:countasty/theme/dark_theme_classic.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Which dark palette is in use. Light mode is unaffected by this.
enum DarkThemeStyle {
  /// Warm brown ground with amber and olive. Matches the light theme's hue
  /// family, so switching light/dark no longer changes the app's temperature.
  warm,

  /// The original cool charcoal with hot orange and bright green.
  classic,
}

class ThemeController extends GetxController implements GetxService {
  final SplashServiceInterface splashServiceInterface;
  ThemeController({required this.splashServiceInterface}) {
    _loadCurrentTheme();
  }

  /// Stored separately from [AppConstants.theme] so the dark/light choice and
  /// the dark *style* choice don't overwrite one another.
  static const String _darkStyleKey = 'dark_theme_style';

  bool _darkTheme = false;
  bool get darkTheme => _darkTheme;

  DarkThemeStyle _darkStyle = DarkThemeStyle.warm;
  DarkThemeStyle get darkStyle => _darkStyle;

  bool get isWarmDark => _darkStyle == DarkThemeStyle.warm;

  /// The dark ThemeData for the selected style.
  ThemeData get activeDarkTheme =>
      _darkStyle == DarkThemeStyle.warm ? dark : darkClassic;

  String _lightMap = '[]';
  String get lightMap => _lightMap;

  String _darkMap = '[]';
  String get darkMap => _darkMap;

  void toggleTheme() {
    _darkTheme = !_darkTheme;
    splashServiceInterface.toggleTheme(_darkTheme);
    update();
  }

  /// Picks a dark palette. Selecting a style while in light mode is allowed —
  /// it simply takes effect the next time dark mode is on — so the setting can
  /// live anywhere in the UI without depending on the current mode.
  void setDarkStyle(DarkThemeStyle style) {
    if (_darkStyle == style) return;
    _darkStyle = style;
    _persistDarkStyle(style);
    update();
  }

  void toggleDarkStyle() => setDarkStyle(
      isWarmDark ? DarkThemeStyle.classic : DarkThemeStyle.warm);

  void _persistDarkStyle(DarkThemeStyle style) {
    try {
      Get.find<SharedPreferences>().setString(_darkStyleKey, style.name);
    } catch (_) {
      // Preferences unavailable (very early startup): the choice still applies
      // for this session, it just won't survive a restart.
    }
  }

  DarkThemeStyle _readDarkStyle() {
    try {
      final String? stored = Get.find<SharedPreferences>().getString(_darkStyleKey);
      return DarkThemeStyle.values.firstWhere(
        (DarkThemeStyle s) => s.name == stored,
        orElse: () => DarkThemeStyle.warm,
      );
    } catch (_) {
      return DarkThemeStyle.warm;
    }
  }

  void _loadCurrentTheme() async {
    _lightMap = await rootBundle.loadString('assets/map/light_map.json');
    _darkMap = await rootBundle.loadString('assets/map/dark_map.json');
    _darkTheme = await splashServiceInterface.loadCurrentTheme();
    _darkStyle = _readDarkStyle();
    update();
  }
}
