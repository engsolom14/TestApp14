import 'package:countasty/common/widgets/custom_asset_image_widget.dart';
import 'package:countasty/features/onboard/domain/models/onboarding_model.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/material.dart';

/// A single onboarding page: a tinted artwork band running to the top edge of
/// the screen, copy beneath.
///
/// The band is drawn rather than taken from the bundled `onboard_frame_*` SVGs.
/// Those are a 5%-opacity wash with no shape of their own, and the three
/// illustrations have very different aspect ratios (183x224, 360x220, 226x224),
/// so a shared band plus BoxFit.contain is what keeps the pages consistent.
class OnBoardingPageWidget extends StatelessWidget {
  final OnBoardingModel item;

  const OnBoardingPageWidget({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    // The band runs edge to edge under the status bar, so the artwork inside it
    // has to clear both the inset and the Skip control floating above it.
    final double topInset = MediaQuery.of(context).padding.top;

    return Column(children: [

      Expanded(
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            // secondaryHeaderColor is the peach-soft token in light and the
            // elevated surface in dark, so the band follows the theme.
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Theme.of(context).secondaryHeaderColor,
                Theme.of(context).cardColor,
              ],
            ),
            borderRadius: const BorderRadiusDirectional.only(
              bottomStart: Radius.circular(Dimensions.radiusExtraLarge),
              bottomEnd: Radius.circular(Dimensions.radiusExtraLarge),
            ),
          ),
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              Dimensions.paddingSizeOverLarge, topInset + 52,
              Dimensions.paddingSizeOverLarge, Dimensions.paddingSizeExtraLarge,
            ),
            child: CustomAssetImageWidget(item.imageUrl, fit: BoxFit.contain),
          ),
        ),
      ),

      // Copy sits directly under the band at its natural height, so it keeps
      // the same baseline on every page and leaves no dead gap above the CTA.
      Padding(
        padding: const EdgeInsets.fromLTRB(
          Dimensions.paddingSizeExtraLarge, Dimensions.paddingSizeExtraLarge,
          Dimensions.paddingSizeExtraLarge, 0,
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [

          Text(
            item.title,
            style: displayExtraBold.copyWith(fontSize: Dimensions.fontSizeOverLarge),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: Dimensions.paddingSizeSmall),

          Text(
            item.description,
            // hintColor, not disabledColor: the theme documents it as the
            // secondary-text token that clears 4.5:1 contrast.
            style: robotoRegular.copyWith(
              color: Theme.of(context).hintColor,
              height: 1.5,
            ),
            textAlign: TextAlign.center,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),

        ]),
      ),

    ]);
  }
}
