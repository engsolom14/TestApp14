import 'package:countasty/util/dimensions.dart';
import 'package:flutter/material.dart';

/// Page dots for the onboarding flow. The active dot stretches into a pill.
///
/// Laid out with a plain Row, so it mirrors itself under RTL and the first
/// page's dot stays on the side the reader starts from.
class OnBoardingIndicatorWidget extends StatelessWidget {
  final int length;
  final int selectedIndex;

  const OnBoardingIndicatorWidget({super.key, required this.length, required this.selectedIndex});

  @override
  Widget build(BuildContext context) {
    final bool reduceMotion = MediaQuery.of(context).disableAnimations;
    final Color active = Theme.of(context).primaryColor;

    return Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(length, (i) {
      final bool isActive = i == selectedIndex;
      return AnimatedContainer(
        duration: Duration(milliseconds: reduceMotion ? 0 : 240),
        curve: Curves.easeOutCubic,
        width: isActive ? 26 : 8,
        height: 8,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: isActive ? active : active.withValues(alpha: 0.22),
          borderRadius: BorderRadius.circular(Dimensions.radiusPill),
        ),
      );
    }));
  }
}
