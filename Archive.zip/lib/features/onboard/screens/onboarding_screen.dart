import 'package:countasty/common/widgets/custom_button_widget.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/onboard/controllers/onboard_controller.dart';
import 'package:countasty/features/onboard/widgets/onboarding_indicator_widget.dart';
import 'package:countasty/features/onboard/widgets/onboarding_page_widget.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/helper/address_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({super.key});

  @override
  State<OnBoardingScreen> createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  final PageController _pageController = PageController();

  @override
  void initState() {
    super.initState();
    // Loading in initState rather than build(): build can run many times, and
    // firing a fetch from it re-enters the controller on every rebuild.
    Get.find<OnBoardingController>().getOnBoardingList();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).cardColor,
      body: GetBuilder<OnBoardingController>(builder: (onBoardingController) {

        final list = onBoardingController.onBoardingList;
        if (list == null) {
          return const Center(child: CircularProgressIndicator());
        }

        final int lastIndex = list.length - 1;
        final bool isLast = onBoardingController.selectedIndex >= lastIndex;

        return Center(child: SizedBox(
          // Onboarding is a phone-shaped flow; on tablets and web it stays a
          // readable column instead of stretching the artwork edge to edge.
          width: 480,
          child: Stack(children: [

            Column(children: [

              // No SafeArea above this: the artwork band is meant to run under
              // the status bar to the very top of the screen. The page widget
              // pads its own artwork past the inset.
              Expanded(
                child: PageView.builder(
                  controller: _pageController,
                  itemCount: list.length,
                  onPageChanged: onBoardingController.changeSelectIndex,
                  itemBuilder: (context, index) => OnBoardingPageWidget(item: list[index]),
                ),
              ),

              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(
                    Dimensions.paddingSizeExtraLarge, Dimensions.paddingSizeLarge,
                    Dimensions.paddingSizeExtraLarge, Dimensions.paddingSizeLarge,
                  ),
                  child: Column(children: [

                    OnBoardingIndicatorWidget(
                      length: list.length,
                      selectedIndex: onBoardingController.selectedIndex,
                    ),
                    const SizedBox(height: Dimensions.paddingSizeExtraLarge),

                    // A labelled, full-width button rather than the old 36px
                    // arrow: it clears the touch-target floor, says what it
                    // does, and reuses the app's own primary button.
                    CustomButtonWidget(
                      width: double.infinity,
                      buttonText: isLast ? 'get_started'.tr : 'next'.tr,
                      onPressed: () {
                        if (isLast) {
                          _configureToRouteInitialPage();
                        } else {
                          _pageController.nextPage(
                            duration: const Duration(milliseconds: 320),
                            curve: Curves.easeOutCubic,
                          );
                        }
                      },
                    ),

                  ]),
                ),
              ),

            ]),

            // Skip floats over the band. Kept mounted on the last page and
            // faded out instead of removed, so nothing reflows mid-flow.
            SafeArea(
              child: Align(
                alignment: AlignmentDirectional.topEnd,
                child: Opacity(
                  opacity: isLast ? 0 : 1,
                  child: IgnorePointer(
                    ignoring: isLast,
                    child: TextButton(
                      onPressed: _configureToRouteInitialPage,
                      style: TextButton.styleFrom(
                        // 44x44pt / 48dp minimum touch target.
                        minimumSize: const Size(64, 48),
                        padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeLarge),
                        foregroundColor: Theme.of(context).hintColor,
                      ),
                      child: Text('skip'.tr, style: robotoBold.copyWith(color: Theme.of(context).hintColor)),
                    ),
                  ),
                ),
              ),
            ),

          ]),
        ));
      }),
    );
  }

  void _configureToRouteInitialPage() async {
    Get.find<SplashController>().disableIntro();
    await Get.find<AuthController>().guestLogin();
    if (AddressHelper.getAddressFromSharedPref() != null) {
      Get.offNamed(RouteHelper.getInitialRoute(fromSplash: true));
    } else {
      Get.find<SplashController>().navigateToLocationScreen('splash', offNamed: true);
    }
  }
}
