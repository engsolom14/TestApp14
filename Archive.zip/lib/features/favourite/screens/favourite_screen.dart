import 'package:countasty/common/widgets/web_screen_title_widget.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/favourite/controllers/favourite_controller.dart';
import 'package:countasty/features/favourite/widgets/fav_item_view_widget.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_app_bar_widget.dart';
import 'package:countasty/common/widgets/menu_drawer_widget.dart';
import 'package:countasty/common/widgets/not_logged_in_screen.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FavouriteScreen extends StatefulWidget {
  const FavouriteScreen({super.key});

  @override
  FavouriteScreenState createState() => FavouriteScreenState();
}

class FavouriteScreenState extends State<FavouriteScreen> with SingleTickerProviderStateMixin {
  TabController? _tabController;

  @override
  void initState() {
    super.initState();

    _tabController = TabController(length: 2, initialIndex: 0, vsync: this);
    _initCall();
  }

  void _initCall(){
    if(Get.find<AuthController>().isLoggedIn()) {
      Get.find<FavouriteController>().getFavouriteList(fromFavScreen: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBarWidget(title: 'favourite'.tr, isBackButtonExist: false),
      endDrawer: const MenuDrawerWidget(), endDrawerEnableOpenDragGesture: false,
      body: Get.find<AuthController>().isLoggedIn() ? SafeArea(child: Column(children: [

        WebScreenTitleWidget(title: 'favourite'.tr),

        SizedBox(
          width: Dimensions.webMaxWidth,
          // Align the pill's outer edge with the page margin the list below
          // uses. The indicator is itself inset by 4, so the container carries
          // the remainder rather than the full page padding — otherwise the
          // switcher would sit 4px further in than every card under it.
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: Dimensions.paddingSizeDefault - 4,
            ),
            child: TabBar(
            controller: _tabController,
            // Pill indicator, matching the bottom bar's active tab.
            indicator: BoxDecoration(
              color: Theme.of(context).primaryColor,
              borderRadius: BorderRadius.circular(Dimensions.radiusPill),
              boxShadow: AppShadows.glow(Theme.of(context).primaryColor, opacity: 0.30),
            ),
            indicatorSize: TabBarIndicatorSize.tab,
            indicatorPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
            dividerColor: Colors.transparent,
            splashBorderRadius: BorderRadius.circular(Dimensions.radiusPill),
            labelColor: Colors.white,
            unselectedLabelColor: Theme.of(context).hintColor,
            unselectedLabelStyle: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall),
            labelStyle: robotoBold.copyWith(fontSize: Dimensions.fontSizeSmall),
              tabs: [
                Tab(text: 'food'.tr),
                Tab(text: 'restaurants'.tr),
              ],
            ),
          ),
        ),

        Expanded(child: TabBarView(
          controller: _tabController,
          children: const [
            FavItemViewWidget(isRestaurant: false),
            FavItemViewWidget(isRestaurant: true),
          ],
        )),

      ])) : NotLoggedInScreen(callBack: (value){
        _initCall();
        setState(() {});
      }),
    );
  }
}
