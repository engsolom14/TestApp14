import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:countasty/common/widgets/footer_view_widget.dart';
import 'package:countasty/common/widgets/menu_drawer_widget.dart';
import 'package:countasty/common/widgets/web_menu_bar.dart';
import 'package:countasty/features/address/controllers/address_controller.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/category/controllers/category_controller.dart';
import 'package:countasty/features/cuisine/controllers/cuisine_controller.dart';
import 'package:countasty/features/dine_in/controllers/dine_in_controller.dart';
import 'package:countasty/features/home/controllers/advertisement_controller.dart';
import 'package:countasty/features/home/controllers/home_controller.dart';
import 'package:countasty/features/home/screens/theme1_home_screen.dart';
import 'package:countasty/features/home/screens/web_home_screen.dart';
import 'package:countasty/features/home/widgets/all_restaurant_filter_widget.dart';
import 'package:countasty/features/home/widgets/active_order_card_widget.dart';
import 'package:countasty/features/home/widgets/all_restaurants_widget.dart';
import 'package:countasty/features/home/widgets/bad_weather_widget.dart';
import 'package:countasty/features/home/widgets/banner_view_widget.dart';
import 'package:countasty/features/home/widgets/best_review_item_view_widget.dart';
import 'package:countasty/features/home/widgets/cashback_dialog_widget.dart';
import 'package:countasty/features/home/widgets/cashback_logo_widget.dart';
import 'package:countasty/features/home/widgets/cuisine_view_widget.dart';
import 'package:countasty/features/home/widgets/dine_in_widget.dart';
import 'package:countasty/features/home/widgets/enjoy_off_banner_view_widget.dart';
import 'package:countasty/features/home/widgets/highlight_widget_view.dart';
import 'package:countasty/features/home/widgets/location_banner_view_widget.dart';
import 'package:countasty/features/home/widgets/new_on_stackfood_view_widget.dart';
import 'package:countasty/features/home/widgets/order_again_view_widget.dart';
import 'package:countasty/features/home/widgets/popular_foods_nearby_view_widget.dart';
import 'package:countasty/features/home/widgets/popular_restaurants_view_widget.dart';
import 'package:countasty/features/home/widgets/refer_banner_view_widget.dart';
import 'package:countasty/features/home/widgets/refer_bottom_sheet_widget.dart';
import 'package:countasty/features/home/widgets/today_trends_view_widget.dart';
import 'package:countasty/features/home/widgets/what_on_your_mind_view_widget.dart';
import 'package:countasty/features/language/controllers/localization_controller.dart';
import 'package:countasty/features/notification/controllers/notification_controller.dart';
import 'package:countasty/features/order/controllers/order_controller.dart';
import 'package:countasty/features/product/controllers/campaign_controller.dart';
import 'package:countasty/features/product/controllers/product_controller.dart';
import 'package:countasty/features/profile/controllers/profile_controller.dart';
import 'package:countasty/features/restaurant/controllers/restaurant_controller.dart';
import 'package:countasty/features/review/controllers/review_controller.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/features/splash/domain/models/config_model.dart';
import 'package:countasty/helper/auth_helper.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/images.dart';
import 'package:countasty/util/styles.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  static Future<void> loadData(bool reload) async {
    Get.find<HomeController>().getBannerList(reload);
    Get.find<CategoryController>().getCategoryList(reload);
    Get.find<CuisineController>().getCuisineList();
    Get.find<AdvertisementController>().getAdvertisementList();
    Get.find<DineInController>().getDineInRestaurantList(1, reload);
    if (Get.find<SplashController>().configModel!.popularRestaurant == 1) {
      Get.find<RestaurantController>().getPopularRestaurantList(reload, 'all', false);
    }
    Get.find<CampaignController>().getItemCampaignList(reload);
    if (Get.find<SplashController>().configModel!.popularFood == 1) {
      Get.find<ProductController>().getPopularProductList(reload, 'all', false);
    }
    if (Get.find<SplashController>().configModel!.newRestaurant == 1) {
      Get.find<RestaurantController>().getLatestRestaurantList(reload, 'all', false);
    }
    if (Get.find<SplashController>().configModel!.mostReviewedFoods == 1) {
      Get.find<ReviewController>().getReviewedProductList(reload, 'all', false);
    }
    Get.find<RestaurantController>().getRestaurantList(1, reload);
    if (Get.find<AuthController>().isLoggedIn()) {
      await Get.find<ProfileController>().getUserInfo();
      Get.find<RestaurantController>().getRecentlyViewedRestaurantList(reload, 'all', false);
      Get.find<RestaurantController>().getOrderAgainRestaurantList(reload);
      Get.find<NotificationController>().getNotificationList(reload);
      Get.find<OrderController>().getRunningOrders(1, notify: false);
      Get.find<AddressController>().getAddressList();
      Get.find<HomeController>().getCashBackOfferList();
    }
  }

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _scrollController = ScrollController();
  final ConfigModel? _configModel = Get.find<SplashController>().configModel;
  bool _isLogin = false;

  @override
  void initState() {
    super.initState();

    _isLogin = Get.find<AuthController>().isLoggedIn();
    HomeScreen.loadData(false).then((value) {
      Get.find<SplashController>().getReferBottomSheetStatus();

      if ((Get.find<ProfileController>().userInfoModel?.isValidForDiscount ?? false) && Get.find<SplashController>().showReferBottomSheet) {
        Future.delayed(const Duration(milliseconds: 500), () => _showReferBottomSheet());
      }
    });

    _scrollController.addListener(() {
      Get.find<HomeController>().hideFavButtonWhileScrolling();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _showReferBottomSheet() {
    ResponsiveHelper.isDesktop(context)
        ? Get.dialog(
            Dialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Dimensions.radiusExtraLarge)),
              insetPadding: const EdgeInsets.all(22),
              clipBehavior: Clip.antiAliasWithSaveLayer,
              child: const ReferBottomSheetWidget(),
            ),
            useSafeArea: false,
          ).then((value) => Get.find<SplashController>().saveReferBottomSheetStatus(false))
        : showModalBottomSheet(
            isScrollControlled: true,
            useRootNavigator: true,
            context: Get.context!,
            backgroundColor: Colors.white,
            shape: const RoundedRectangleBorder(
              borderRadius:
                  BorderRadius.only(topLeft: Radius.circular(Dimensions.radiusExtraLarge), topRight: Radius.circular(Dimensions.radiusExtraLarge)),
            ),
            builder: (context) {
              return ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.8),
                child: const ReferBottomSheetWidget(),
              );
            },
          ).then((value) => Get.find<SplashController>().saveReferBottomSheetStatus(false));
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(builder: (homeController) {
      return GetBuilder<LocalizationController>(builder: (localizationController) {
        return Scaffold(
          appBar: ResponsiveHelper.isDesktop(context) ? const WebMenuBar() : null,
          endDrawer: const MenuDrawerWidget(),
          endDrawerEnableOpenDragGesture: false,
          backgroundColor: Theme.of(context).colorScheme.surface,
          body: SafeArea(
            // Let the page run to the top edge; the SliverAppBar is `primary`
            // so it still inserts the status-bar inset for its own content,
            // and the scroll passes underneath it.
            top: true,
            bottom: false,
            child: RefreshIndicator(
              onRefresh: () async {
                await Get.find<HomeController>().getBannerList(true);
                await Get.find<CategoryController>().getCategoryList(true);
                await Get.find<CuisineController>().getCuisineList();
                Get.find<AdvertisementController>().getAdvertisementList();
                await Get.find<RestaurantController>().getPopularRestaurantList(true, 'all', false);
                await Get.find<CampaignController>().getItemCampaignList(true);
                await Get.find<ProductController>().getPopularProductList(true, 'all', false);
                await Get.find<RestaurantController>().getLatestRestaurantList(true, 'all', false);
                await Get.find<ReviewController>().getReviewedProductList(true, 'all', false);
                await Get.find<RestaurantController>().getRestaurantList(1, true);
                if (Get.find<AuthController>().isLoggedIn()) {
                  await Get.find<ProfileController>().getUserInfo();
                  await Get.find<NotificationController>().getNotificationList(true);
                  await Get.find<RestaurantController>().getRecentlyViewedRestaurantList(true, 'all', false);
                  await Get.find<RestaurantController>().getOrderAgainRestaurantList(true);
                }
              },
              child: ResponsiveHelper.isDesktop(context)
                  ? WebHomeScreen(
                      scrollController: _scrollController,
                    )
                  : (Get.find<SplashController>().configModel!.theme == 2)
                      ? Theme1HomeScreen(
                          scrollController: _scrollController,
                        )
                      : CustomScrollView(
                          controller: _scrollController,
                          physics: const AlwaysScrollableScrollPhysics(),
                          slivers: [
                            /// Header — scrolls away with content
                            SliverToBoxAdapter(
                              child: Center(
                                child: Container(
                                  width: Dimensions.webMaxWidth,
                                  color: Theme.of(context).colorScheme.surface,
                                  padding: EdgeInsets.fromLTRB(
                                    Dimensions.paddingSizeDefault,
                                    MediaQuery.of(context).padding.top + 20,
                                    Dimensions.paddingSizeDefault,
                                    20,
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              'hungry'.tr,
                                              style: robotoBold.copyWith(
                                                fontSize: 36,
                                                height: 1.15,
                                                color: Theme.of(context).textTheme.bodyLarge!.color,
                                              ),
                                            ),
                                            Text(
                                              'order_now'.tr,
                                              style: robotoBold.copyWith(
                                                fontSize: 36,
                                                height: 1.15,
                                                color: Theme.of(context).primaryColor,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      GetBuilder<ProfileController>(builder: (profileController) {
                                        return InkWell(
                                          onTap: _isLogin
                                              ? () => Get.toNamed(RouteHelper.getProfileRoute())
                                              : () => Get.toNamed(RouteHelper.getNotificationRoute()),
                                          borderRadius: BorderRadius.circular(32),
                                          child: Container(
                                            width: 58,
                                            height: 58,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                color: Theme.of(context).primaryColor.withValues(alpha: 0.5),
                                                width: 2.5,
                                              ),
                                            ),
                                            child: ClipOval(
                                              child: (_isLogin && profileController.userInfoModel?.imageFullUrl != null)
                                                  ? Image.network(
                                                      profileController.userInfoModel!.imageFullUrl!,
                                                      fit: BoxFit.cover,
                                                      errorBuilder: (_, __, ___) => Image.asset(Images.user, fit: BoxFit.cover),
                                                    )
                                                  : Image.asset(Images.user, fit: BoxFit.cover),
                                            ),
                                          ),
                                        );
                                      }),
                                    ],
                                  ),
                                ),
                              ),
                            ),

                            // Search Button
                            SliverPersistentHeader(
                              pinned: true,
                              delegate: SliverDelegate(
                                height: 65,
                                child: Center(
                                  child: Container(
                                    height: 65,
                                    width: Dimensions.webMaxWidth,
                                    color: Theme.of(context).colorScheme.surface,
                                    padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: InkWell(
                                            onTap: () => Get.toNamed(RouteHelper.getSearchRoute()),
                                            child: Container(
                                              padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall),
                                              decoration: BoxDecoration(
                                                color: Theme.of(context).cardColor,
                                                borderRadius: BorderRadius.circular(25),
                                                border: Border.all(color: AppSurface.hairline(context), width: 1),
                                                boxShadow: AppShadows.card,
                                              ),
                                              child: Row(children: [
                                                Image.asset(Images.searchIcon, width: 22, height: 22),
                                                const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                                                Expanded(
                                                  child: Text(
                                                    'are_you_hungry'.tr,
                                                    style: robotoRegular.copyWith(
                                                      fontSize: Dimensions.fontSizeSmall,
                                                      color: Theme.of(context).hintColor,
                                                    ),
                                                  ),
                                                ),
                                              ]),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        Container(
                                          width: 44,
                                          height: 44,
                                          decoration: BoxDecoration(
                                            color: Theme.of(context).cardColor,
                                            borderRadius: BorderRadius.circular(12),
                                            border: Border.all(color: AppSurface.hairline(context), width: 1),
                                            boxShadow: AppShadows.card,
                                          ),
                                          child: Icon(
                                            Symbols.tune,
                                            color: Theme.of(context).textTheme.bodyLarge!.color,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            /// Active order sits directly under the search bar so
                            /// it is visible without scrolling.
                            SliverToBoxAdapter(
                              child: Center(
                                child: SizedBox(
                                  width: Dimensions.webMaxWidth,
                                  child: const ActiveOrderCardWidget(),
                                ),
                              ),
                            ),

                            SliverToBoxAdapter(
                              child: Center(
                                  child: SizedBox(
                                width: Dimensions.webMaxWidth,
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  const BannerViewWidget(),
                                  const BadWeatherWidget(),
                                  const WhatOnYourMindViewWidget(),
                                  const TodayTrendsViewWidget(),
                                  const LocationBannerViewWidget(),
                                  const HighlightWidgetView(),
                                  _isLogin ? const OrderAgainViewWidget() : const SizedBox(),
                                  _configModel!.mostReviewedFoods == 1 ? const BestReviewItemViewWidget(isPopular: false) : const SizedBox(),
                                  _configModel.dineInOrderOption! ? DineInWidget() : const SizedBox(),
                                  const CuisineViewWidget(),
                                  _configModel.popularRestaurant == 1 ? const PopularRestaurantsViewWidget() : const SizedBox(),
                                  const ReferBannerViewWidget(),
                                  _isLogin ? const PopularRestaurantsViewWidget(isRecentlyViewed: true) : const SizedBox(),
                                  _configModel.popularFood == 1 ? const PopularFoodNearbyViewWidget() : const SizedBox(),
                                  _configModel.newRestaurant == 1 ? const NewOnStackFoodViewWidget(isLatest: true) : const SizedBox(),
                                  const PromotionalBannerViewWidget(),
                                ]),
                              )),
                            ),

                            SliverPersistentHeader(
                              pinned: true,
                              delegate: SliverDelegate(
                                height: 90,
                                child: const AllRestaurantFilterWidget(),
                              ),
                            ),

                            SliverToBoxAdapter(
                                child: Center(
                                    child: FooterViewWidget(
                              child: Padding(
                                padding: ResponsiveHelper.isDesktop(context)
                                    ? EdgeInsets.zero
                                    : const EdgeInsets.only(bottom: Dimensions.paddingSizeOverLarge),
                                child: AllRestaurantsWidget(scrollController: _scrollController),
                              ),
                            ))),
                          ],
                        ),
            ),
          ),
          floatingActionButton: GetBuilder<HomeController>(
              id: 'cashback_fab',
              builder: (favController) {
                return AuthHelper.isLoggedIn() && favController.cashBackOfferList != null && favController.cashBackOfferList!.isNotEmpty
                    ? AnimatedScale(
                        scale: favController.showFavButton ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 250),
                        curve: Curves.easeOutBack,
                        child: Padding(
                          padding: EdgeInsets.only(
                              bottom: ResponsiveHelper.isDesktop(context) ? 50 : 0, right: ResponsiveHelper.isDesktop(context) ? 20 : 0),
                          child: InkWell(
                            onTap: () => Get.dialog(const CashBackDialogWidget()),
                            child: const CashBackLogoWidget(),
                          ),
                        ),
                      )
                    : const SizedBox();
              }),
        );
      });
    });
  }
}

class SliverDelegate extends SliverPersistentHeaderDelegate {
  Widget child;
  double height;

  SliverDelegate({required this.child, this.height = 50});

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return child;
  }

  @override
  double get maxExtent => height;

  @override
  double get minExtent => height;

  @override
  bool shouldRebuild(SliverDelegate oldDelegate) {
    return oldDelegate.maxExtent != height || oldDelegate.minExtent != height || child != oldDelegate.child;
  }
}
