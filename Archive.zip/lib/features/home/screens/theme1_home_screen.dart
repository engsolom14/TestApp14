import 'package:countasty/common/widgets/paginated_list_view_widget.dart';
import 'package:countasty/common/widgets/product_view_widget.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/home/screens/home_screen.dart';
import 'package:countasty/features/home/widgets/active_order_card_widget.dart';
import 'package:countasty/features/home/widgets/bad_weather_widget.dart';
import 'package:countasty/features/home/widgets/dine_in_widget.dart';
import 'package:countasty/features/home/widgets/enjoy_off_banner_view_widget.dart';
import 'package:countasty/features/home/widgets/filter_view_widget.dart';
import 'package:countasty/features/home/widgets/highlight_widget_view.dart';
import 'package:countasty/features/home/widgets/refer_banner_view_widget.dart';
import 'package:countasty/features/home/widgets/theme1/banner_view_widget1.dart';
import 'package:countasty/features/home/widgets/theme1/best_reviewed_item_widget1.dart';
import 'package:countasty/features/home/widgets/theme1/category_widget1.dart';
import 'package:countasty/features/home/widgets/theme1/cuisine_widget1.dart';
import 'package:countasty/features/home/widgets/theme1/item_campaign_widget1.dart';
import 'package:countasty/features/home/widgets/theme1/near_by_button_widget1.dart';
import 'package:countasty/features/home/widgets/theme1/popular_item_widget1.dart';
import 'package:countasty/features/home/widgets/theme1/popular_store_widget1.dart';
import 'package:countasty/features/location/controllers/location_controller.dart';
import 'package:countasty/features/notification/controllers/notification_controller.dart';
import 'package:countasty/features/nutrition/controllers/nutrition_controller.dart';
import 'package:countasty/features/nutrition/widgets/calorie_ring_widget.dart';
// Used by the commented-out calorie goal strip sliver below.
// import 'package:countasty/features/nutrition/widgets/goal_strip_widget.dart';
import 'package:countasty/features/restaurant/controllers/restaurant_controller.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/features/splash/domain/models/config_model.dart';
import 'package:countasty/helper/address_helper.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:countasty/features/profile/controllers/profile_controller.dart';

class Theme1HomeScreen extends StatelessWidget {
  final ScrollController scrollController;
  const Theme1HomeScreen({super.key, required this.scrollController});

  /// The customer's own first name, or an empty string when there is no name
  /// to show — signed out, or signed in but the profile hasn't landed yet.
  /// Callers use the empty case to drop the name chip entirely rather than
  /// render a placeholder inside it.
  String _greetingName(bool isLogin, ProfileController profileController) {
    if (!isLogin) return '';

    return (profileController.userInfoModel?.fName ?? '').trim();
  }

  @override
  Widget build(BuildContext context) {
    ConfigModel configModel = Get.find<SplashController>().configModel!;
    bool isLogin = Get.find<AuthController>().isLoggedIn();

    return CustomScrollView(
      controller: scrollController,
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        // App Bar
        /// Greeting block — avatar, time-of-day salutation and the editorial
        /// headline, in place of the old address-only bar.
        SliverAppBar(
          floating: true,
          elevation: 0,
          automaticallyImplyLeading: false,
          toolbarHeight: 50,
          backgroundColor: ResponsiveHelper.isDesktop(context) ? Colors.transparent : Theme.of(context).colorScheme.surface,
          surfaceTintColor: Theme.of(context).colorScheme.surface,
          title: Center(
              child: SizedBox(
            width: Dimensions.webMaxWidth,
            child: Row(children: [
              /// Delivery target — one line, level with the icons.
              Expanded(child: GetBuilder<LocationController>(builder: (locationController) {
                final String type = AddressHelper.getAddressFromSharedPref()!.addressType ?? '';
                final String label = type == 'home'
                    ? 'home'.tr
                    : type == 'office'
                        ? 'office'.tr
                        : 'others'.tr;

                return InkWell(
                  onTap: () => Get.toNamed(RouteHelper.getAccessLocationRoute('home')),
                  borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(
                      type == 'home'
                          ? Symbols.home_filled
                          : type == 'office'
                              ? Symbols.work
                              : Symbols.location_on,
                      size: 18,
                      color: Theme.of(context).primaryColor,
                    ),
                    const SizedBox(width: 6),
                    Text('deliver_to'.tr,
                        style: robotoRegular.copyWith(
                          fontSize: Dimensions.fontSizeSmall,
                          color: Theme.of(context).hintColor,
                        )),
                    const SizedBox(width: 5),
                    Flexible(
                        child: Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault),
                    )),
                    Icon(Symbols.arrow_drop_down, size: 20, color: Theme.of(context).textTheme.bodyLarge!.color),
                  ]),
                );
              })),
              const SizedBox(width: Dimensions.paddingSizeSmall),

              InkWell(
                onTap: () => Get.toNamed(RouteHelper.getNotificationRoute()),
                borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                child: GetBuilder<NotificationController>(builder: (notificationController) {
                  return Container(
                    height: 44,
                    width: 44,
                    decoration: AppSurface.circle(context),
                    child: Stack(alignment: Alignment.center, children: [
                      Icon(Symbols.notifications, size: 23, color: Theme.of(context).textTheme.bodyLarge!.color),
                      notificationController.hasNotification
                          ? Positioned(
                              top: 11,
                              right: 12,
                              child: Container(
                                height: 9,
                                width: 9,
                                decoration: BoxDecoration(
                                  color: Theme.of(context).primaryColor,
                                  shape: BoxShape.circle,
                                  border: Border.all(width: 1.4, color: Theme.of(context).cardColor),
                                ),
                              ),
                            )
                          : const SizedBox(),
                    ]),
                  );
                }),
              ),
              const SizedBox(width: Dimensions.paddingSizeExtraSmall),

              /// Daily goal — a live ring rather than a flat icon, so progress
              /// is readable without opening anything.
              GetBuilder<NutritionController>(builder: (nutrition) {
                return InkWell(
                  onTap: () => Get.toNamed(RouteHelper.getNutritionRoute()),
                  borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                  child: Container(
                    height: 44,
                    width: 44,
                    decoration: AppSurface.circle(context),
                    child: nutrition.hasGoal
                        ? CalorieRingWidget(
                            progress: nutrition.progress,
                            remaining: nutrition.remaining,
                            isOver: nutrition.isOverGoal,
                            size: 44,
                            stroke: 3.5,
                            child: Icon(
                              Symbols.local_fire_department,
                              size: 19,
                              color: nutrition.isOverGoal ? Theme.of(context).colorScheme.error : Theme.of(context).primaryColor,
                            ),
                          )
                        : Icon(
                            Symbols.local_fire_department,
                            size: 23,
                            color: Theme.of(context).textTheme.bodyLarge!.color,
                          ),
                  ),
                );
              }),
            ]),
          )),
          actions: const [SizedBox()],
        ),

        /// Editorial headline + the address it delivers to.
        SliverToBoxAdapter(
            child: Center(
                child: Container(
          width: Dimensions.webMaxWidth,
          color: Theme.of(context).colorScheme.surface,
          padding: const EdgeInsets.fromLTRB(
            Dimensions.paddingSizeSmall,
            Dimensions.paddingSizeExtraSmall,
            Dimensions.paddingSizeSmall,
            Dimensions.paddingSizeSmall,
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            /// "Hello <name>," once we know the name; a bare "Hello," while
            /// signed out or waiting on the profile. GetBuilder wraps the whole
            /// line so the chip appears the moment the request lands.
            GetBuilder<ProfileController>(builder: (profileController) {
              final String name = _greetingName(isLogin, profileController);
              final TextStyle headline = displayExtraBold.copyWith(
                fontSize: 30,
                color: Theme.of(context).textTheme.bodyLarge!.color,
              );

              return RichText(
                  text: TextSpan(children: [
                TextSpan(text: name.isEmpty ? 'Hello' : 'Hello ', style: headline),
                if (name.isNotEmpty)
                  WidgetSpan(
                    alignment: PlaceholderAlignment.middle,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                      decoration: BoxDecoration(
                        // Barely-there warmth over the card surface. Anything
                        // heavier turns to mud brown on the dark ground — the
                        // orange belongs in the word itself, not the chip.
                        color: Color.alphaBlend(
                          Theme.of(context).primaryColor.withValues(alpha: 0.06),
                          Theme.of(context).cardColor,
                        ),
                        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                      ),
                      child: Text(name,
                          style: displayExtraBold.copyWith(
                            fontSize: 26,
                            color: Theme.of(context).primaryColor,
                          )),
                    ),
                  ),
                TextSpan(text: ',', style: headline),
              ]));
            }),
            Text('Make today delicious',
                style: displayRegular.copyWith(
                  fontSize: 28,
                  color: Theme.of(context).textTheme.bodyLarge!.color,
                )),
          ]),
        ))),

        /// Today's calorie budget — hidden from home; the goal is still
        /// reachable via the ring in the top bar and the nutrition screen.
        // const SliverToBoxAdapter(
        //     child: Center(
        //         child: SizedBox(
        //   width: Dimensions.webMaxWidth,
        //   child: GoalStripWidget(),
        // ))),

        // Search Button
        SliverPersistentHeader(
          pinned: true,
          delegate: SliverDelegate(
              child: Center(
                  child: Container(
            height: 50,
            width: Dimensions.webMaxWidth,
            color: Theme.of(context).colorScheme.surface,
            padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall),
            child: InkWell(
              onTap: () => Get.toNamed(RouteHelper.getSearchRoute()),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(25),
                  border: Border.all(color: AppSurface.hairline(context), width: 1),
                  boxShadow: AppShadows.card,
                ),
                child: Row(children: [
                  const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                  Icon(
                    Symbols.search,
                    size: 25,
                    color: Theme.of(context).hintColor,
                  ),
                  const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                  Expanded(
                      child: Text(
                    'search_food_or_restaurant'.tr,
                    style: robotoRegular.copyWith(
                      fontSize: Dimensions.fontSizeSmall,
                      color: Theme.of(context).hintColor,
                    ),
                  )),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surface,
                      borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                    ),
                    child: Text('find'.tr,
                        style: robotoMedium.copyWith(
                          fontSize: Dimensions.fontSizeSmall,
                          color: Theme.of(context).textTheme.bodyLarge!.color,
                        )),
                  ),
                ]),
              ),
            ),
          ))),
        ),

        /// Active order sits above the feed so it is visible without scrolling.
        SliverToBoxAdapter(
          child: Center(
            child: SizedBox(
              width: Dimensions.webMaxWidth,
              child: const ActiveOrderCardWidget(),
            ),
          ),
        ),

        SliverToBoxAdapter(
          child: Center(
              child: SizedBox(
            width: Dimensions.webMaxWidth,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const BannerViewWidget1(),
              const BadWeatherWidget(),
              const CategoryWidget1(),
              const ItemCampaignWidget1(),
              const HighlightWidgetView(),
              isLogin ? const PopularStoreWidget1(isOrderAgainViewed: true, isPopular: false) : const SizedBox(),
              // isLogin ? const OrderAgainViewWidget() : const SizedBox(),
              configModel.mostReviewedFoods == 1 ? const BestReviewedItemWidget1() : const SizedBox(),
              configModel.dineInOrderOption! ? DineInWidget() : const SizedBox(),
              const ReferBannerViewWidget(fromTheme1: true),
              isLogin ? const PopularStoreWidget1(isPopular: false, isRecentlyViewed: true) : const SizedBox(),
              const CuisinesWidget1(),
              configModel.popularRestaurant == 1 ? const PopularStoreWidget1(isPopular: true) : const SizedBox(),
              const NearByButtonWidget1(),
              configModel.popularFood == 1 ? const PopularItemWidget1(isPopular: true) : const SizedBox(),
              configModel.newRestaurant == 1 ? const PopularStoreWidget1(isPopular: false) : const SizedBox(),
              const PromotionalBannerViewWidget(),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 15, 0, 5),
                child: Row(children: [
                  Expanded(
                      child: Text(
                    'all_restaurants'.tr,
                    style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeLarge),
                  )),
                  const FilterViewWidget(),
                ]),
              ),
              GetBuilder<RestaurantController>(builder: (restaurantController) {
                return PaginatedListViewWidget(
                  scrollController: scrollController,
                  totalSize: restaurantController.restaurantModel?.totalSize,
                  offset: restaurantController.restaurantModel?.offset,
                  onPaginate: (int? offset) async => await restaurantController.getRestaurantList(offset!, false),
                  productView: ProductViewWidget(
                    isRestaurant: true,
                    products: null,
                    showTheme1Restaurant: true,
                    restaurants: restaurantController.restaurantModel?.restaurants,
                    padding: EdgeInsets.symmetric(
                      horizontal: ResponsiveHelper.isDesktop(context) ? Dimensions.paddingSizeExtraSmall : Dimensions.paddingSizeSmall,
                      vertical: ResponsiveHelper.isDesktop(context) ? Dimensions.paddingSizeExtraSmall : 0,
                    ),
                  ),
                );
              }),
            ]),
          )),
        ),
      ],
    );
  }
}
