import 'package:countasty/features/cuisine/controllers/cuisine_controller.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_image_widget.dart';
import 'package:countasty/common/widgets/title_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shimmer_animation/shimmer_animation.dart';

class CuisinesWidget1 extends StatelessWidget {
  const CuisinesWidget1({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CuisineController>(
      builder: (cuisineController) {
        return (cuisineController.cuisineModel != null && cuisineController.cuisineModel!.cuisines!.isEmpty) ? const SizedBox() : Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
            child: TitleWidget(title: 'cuisines'.tr, onTap: () => Get.toNamed(RouteHelper.getCuisineRoute())),
          ),

          /// Horizontal strip of image tiles with the name on a scrim — the
          /// same card language as the restaurant cards, and it scrolls rather
          /// than locking two rows of vertical space.
          SizedBox(
            height: 128,
            child: cuisineController.cuisineModel != null ? ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
              itemCount: cuisineController.cuisineModel!.cuisines!.length,
              itemBuilder: (context, index) {
                final cuisine = cuisineController.cuisineModel!.cuisines![index];

                return Padding(
                  padding: const EdgeInsets.only(right: Dimensions.paddingSizeSmall),
                  child: InkWell(
                    onTap: () => Get.toNamed(RouteHelper.getCuisineRestaurantRoute(cuisine.id, cuisine.name)),
                    borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                    child: SizedBox(
                      width: 104,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                        child: Stack(fit: StackFit.expand, children: [

                          CustomImageWidget(image: '${cuisine.imageFullUrl}', fit: BoxFit.cover),

                          Positioned(
                            left: 0, right: 0, bottom: 0,
                            child: Container(
                              height: 78,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.bottomCenter, end: Alignment.topCenter,
                                  colors: [
                                    const Color(0xFF120C07).withValues(alpha: 0.86),
                                    const Color(0xFF120C07).withValues(alpha: 0.0),
                                  ],
                                ),
                              ),
                            ),
                          ),

                          Positioned(
                            left: 8, right: 8, bottom: 10,
                            child: Text(
                              cuisine.name ?? '',
                              style: robotoBold.copyWith(fontSize: Dimensions.fontSizeSmall, color: Colors.white),
                              maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
                            ),
                          ),
                        ]),
                      ),
                    ),
                  ),
                );
              },
            ) : CuisineShimmer(cuisineController: cuisineController),
          )
        ]);
      }
    );
  }
}

class CuisineShimmer extends StatelessWidget {
  final CuisineController cuisineController;
  const CuisineShimmer({super.key, required this.cuisineController});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 128,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
        itemCount: 6,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.only(right: Dimensions.paddingSizeSmall),
            child: Shimmer(
              duration: const Duration(seconds: 2),
              enabled: cuisineController.cuisineModel == null,
              child: Container(
                width: 104,
                decoration: BoxDecoration(
                  color: const Color(0xFFEFE3D2),
                  borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
