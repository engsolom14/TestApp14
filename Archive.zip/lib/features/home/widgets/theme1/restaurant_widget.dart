import 'package:countasty/common/widgets/rating_bar_widget.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/favourite/controllers/favourite_controller.dart';
import 'package:shimmer_animation/shimmer_animation.dart';
import 'package:countasty/features/restaurant/controllers/restaurant_controller.dart';
import 'package:countasty/common/models/restaurant_model.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_image_widget.dart';
import 'package:countasty/common/widgets/logo_like_button.dart';
import 'package:countasty/common/widgets/custom_snackbar_widget.dart';
import 'package:countasty/common/widgets/discount_tag_widget.dart';
import 'package:countasty/common/widgets/not_available_widget.dart';
import 'package:countasty/features/restaurant/screens/restaurant_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

class RestaurantWidget extends StatelessWidget {
  final Restaurant? restaurant;
  final int index;
  final bool inStore;
  const RestaurantWidget({super.key, required this.restaurant, required this.index, this.inStore = false});

  @override
  Widget build(BuildContext context) {
    bool desktop = ResponsiveHelper.isDesktop(context);
    return InkWell(
      onTap: () {

        if(restaurant != null && restaurant!.restaurantStatus == 1){
          Get.toNamed(
            RouteHelper.getRestaurantRoute(restaurant!.id),
            arguments: RestaurantScreen(restaurant: restaurant),
          );
        }else if(restaurant!.restaurantStatus == 0){
          showCustomSnackBar('restaurant_is_not_available'.tr);
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
        height: desktop ? 260 : 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          color: Theme.of(context).cardColor,
          border: Border.all(color: AppSurface.hairline(context), width: 1),
          boxShadow: AppShadows.card,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          child: Stack(fit: StackFit.expand, children: [

            /// The photo fills the whole card.
            CustomImageWidget(
              image: '${restaurant!.coverPhotoFullUrl}',
              fit: BoxFit.cover, isRestaurant: true,
            ),

            /// Scrim so white type stays legible over any photo.
            Positioned(
              left: 0, right: 0, bottom: 0,
              child: Container(
                height: 130,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter, end: Alignment.topCenter,
                    colors: [
                      const Color(0xFF120C07).withValues(alpha: 0.88),
                      const Color(0xFF120C07).withValues(alpha: 0.55),
                      const Color(0xFF120C07).withValues(alpha: 0.0),
                    ],
                    stops: const [0.0, 0.45, 1.0],
                  ),
                ),
              ),
            ),

            /// Name, cuisine pills and delivery time, sitting on the photo.
            Positioned(
              left: Dimensions.paddingSizeDefault, right: Dimensions.paddingSizeDefault,
              bottom: Dimensions.paddingSizeDefault,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [

                Text(
                  restaurant!.name ?? '',
                  style: robotoBold.copyWith(fontSize: Dimensions.fontSizeExtraLarge, color: Colors.white),
                  maxLines: 2, overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                Row(children: [
                  Expanded(child: _CuisineChips(restaurant: restaurant!)),

                  (restaurant!.deliveryTime != null && restaurant!.deliveryTime!.isNotEmpty) ? Padding(
                    padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Symbols.schedule, size: 15, color: Colors.white),
                      const SizedBox(width: 4),
                      Text(
                        // The API returns e.g. "20-40-min"; render it readably.
                        restaurant!.deliveryTime!.replaceAll('-min', ' min').replaceAll('_', ' '),
                        style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Colors.white),
                      ),
                    ]),
                  ) : const SizedBox(),
                ]),
              ]),
            ),

            DiscountTagWidget(
              discount: Get.find<RestaurantController>().getDiscount(restaurant!),
              discountType: Get.find<RestaurantController>().getDiscountType(restaurant!),
              freeDelivery: restaurant!.freeDelivery,
            ),
            Get.find<RestaurantController>().isOpenNow(restaurant!) ? const SizedBox() : const NotAvailableWidget(isRestaurant: true),

            /// Favourite, floated on the image.
            Positioned(
              top: Dimensions.paddingSizeSmall, right: Dimensions.paddingSizeSmall,
              child: GetBuilder<FavouriteController>(builder: (favouriteController) {
                bool isWished = favouriteController.wishRestIdList.contains(restaurant!.id);
                return Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF120C07).withValues(alpha: 0.35),
                  ),
                  child: LogoLikeButton(
                    isWished: isWished,
                    outlineColor: Colors.white,
                    onTap: () {
                      if(Get.find<AuthController>().isLoggedIn()) {
                        isWished ? favouriteController.removeFromFavouriteList(restaurant!.id, true)
                            : favouriteController.addToFavouriteList(null, restaurant?.id, true);
                      }else {
                        showCustomSnackBar('you_are_not_logged_in'.tr);
                      }
                    },
                  ),
                );
              }),
            ),
          ]),
        ),
      ),
    );
  }
}

/// Cuisine tags with a "+N" overflow chip, as in the reference card.
class _CuisineChips extends StatelessWidget {
  final Restaurant restaurant;
  const _CuisineChips({required this.restaurant});

  @override
  Widget build(BuildContext context) {
    final List<String> names = (restaurant.cuisineNames ?? [])
        .map((c) => c.name ?? '').where((n) => n.isNotEmpty).toList();
    if (names.isEmpty) return const SizedBox();

    const int visible = 2;
    final List<String> shown = names.take(visible).toList();
    final int extra = names.length - shown.length;

    return Row(mainAxisSize: MainAxisSize.min, children: [
      ...shown.map((n) => Padding(
        padding: const EdgeInsets.only(right: 6),
        child: _Chip(label: n),
      )),
      extra > 0 ? _Chip(label: '+$extra') : const SizedBox(),
    ]);
  }
}

class _Chip extends StatelessWidget {
  final String label;
  const _Chip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.22),
        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
        border: Border.all(color: Colors.white.withValues(alpha: 0.28)),
      ),
      child: Text(
        label, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Colors.white),
      ),
    );
  }
}


class RestaurantShimmer extends StatelessWidget {
  final bool isEnable;
  const RestaurantShimmer({super.key, required this.isEnable});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
        color: Theme.of(context).cardColor,
        border: Border.all(color: AppSurface.hairline(context), width: 1),
        boxShadow: AppShadows.card,
      ),
      child: Shimmer(
        duration: const Duration(seconds: 2),
        enabled: isEnable,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          Container(
            height: context.width * 0.3, width: Dimensions.webMaxWidth,
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(Dimensions.radiusLarge)),
              color: const Color(0xFFEFE3D2),
            ),
          ),

          Expanded(child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall),
            child: Row(children: [

              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [

                  Container(height: 15, width: 150, color: const Color(0xFFEFE3D2)),
                  const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                  Container(height: 10, width: 50, color: const Color(0xFFEFE3D2)),
                  const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                  const RatingBarWidget(rating: 0, size: 12, ratingCount: 0),

                ]),
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),

              Icon(Symbols.favorite_border,  size: 25, color: Theme.of(context).disabledColor),

            ]),
          )),

        ]),
      ),
    );
  }
}

