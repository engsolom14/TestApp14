import 'package:countasty/common/widgets/rating_bar_widget.dart';
import 'package:countasty/features/restaurant/controllers/restaurant_controller.dart';
import 'package:countasty/common/models/restaurant_model.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/favourite/controllers/favourite_controller.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_constants.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_image_widget.dart';
import 'package:countasty/common/widgets/custom_snackbar_widget.dart';
import 'package:countasty/common/widgets/discount_tag_widget.dart';
import 'package:countasty/common/widgets/not_available_widget.dart';
import 'package:countasty/common/widgets/title_widget.dart';
import 'package:countasty/features/restaurant/screens/restaurant_screen.dart';
import 'package:countasty/common/widgets/media_card_widget.dart';
import 'package:flutter/material.dart';
import 'package:shimmer_animation/shimmer_animation.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:countasty/common/widgets/logo_like_button.dart';

class PopularStoreWidget1 extends StatelessWidget {
  final bool isPopular;
  final bool isRecentlyViewed;
  final bool isOrderAgainViewed;
  const PopularStoreWidget1({super.key, required this.isPopular, this.isRecentlyViewed = false, this.isOrderAgainViewed = false});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RestaurantController>(builder: (restaurantController) {
      List<Restaurant>? restaurant = isPopular ? restaurantController.popularRestaurantList
          : isRecentlyViewed ? restaurantController.recentlyViewedRestaurantList
          : isOrderAgainViewed ? restaurantController.orderAgainRestaurantList
          : restaurantController.latestRestaurantList;

      return (restaurant != null && restaurant.isEmpty) ? const SizedBox() : Column(
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(10, isPopular ? 15 : 15, 10, 10),
            child: TitleWidget(
              title: isPopular ? 'popular_restaurants'.tr
                  : isRecentlyViewed ? 'recently_viewed_restaurants'.tr
                  : isOrderAgainViewed ? 'order_again'.tr : '${'new_on'.tr} ${AppConstants.appName}',
              onTap: () => Get.toNamed(RouteHelper.getAllRestaurantRoute(isPopular ? 'popular' : isRecentlyViewed ? 'recently_viewed' : isOrderAgainViewed ? 'order_again' : 'latest')),
            ),
          ),

          SizedBox(
            height: 150,
            child: restaurant != null ? ListView.builder(
              controller: ScrollController(),
              physics: const BouncingScrollPhysics(),
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
              itemCount: restaurant.length > 10 ? 10 : restaurant.length,
              itemBuilder: (context, index){
                return Padding(
                  padding: const EdgeInsets.only(right: Dimensions.paddingSizeSmall, bottom: 5),
                  child: InkWell(
                    onTap: () {
                      Get.toNamed(
                        RouteHelper.getRestaurantRoute(restaurant[index].id),
                        arguments: RestaurantScreen(restaurant: restaurant[index]),
                      );
                    },
                    child: MediaCard(
                      height: 150, width: 220,
                      image: '${restaurant[index].coverPhotoFullUrl}',
                      title: restaurant[index].name ?? '',
                      isRestaurant: true,
                      titleSize: Dimensions.fontSizeDefault,
                      chips: (restaurant[index].cuisineNames ?? [])
                          .map((c) => c.name ?? '').where((n) => n.isNotEmpty).toList(),
                      maxChips: 1,
                      trailing: (restaurant[index].deliveryTime != null && restaurant[index].deliveryTime!.isNotEmpty)
                          ? MediaCardMeta(
                              icon: Symbols.schedule,
                              label: restaurant[index].deliveryTime!.replaceAll('-min', ' min').replaceAll('_', ' '),
                            )
                          : null,
                      overlays: [
                        DiscountTagWidget(
                          discount: restaurantController.getDiscount(restaurant[index]),
                          discountType: restaurantController.getDiscountType(restaurant[index]),
                          freeDelivery: restaurant[index].freeDelivery,
                        ),
                        restaurantController.isOpenNow(restaurant[index]) ? const SizedBox() : const NotAvailableWidget(isRestaurant: true),
                      ],
                      topRight: GetBuilder<FavouriteController>(builder: (favouriteController) {
                        bool isWished = favouriteController.wishRestIdList.contains(restaurant[index].id);
                        return Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xFF120C07).withValues(alpha: 0.35),
                          ),
                          child: LogoLikeButton(
                            isWished: isWished,
                            size: 17,
                            outlineColor: Colors.white,
                            onTap: () {
                              if(Get.find<AuthController>().isLoggedIn()) {
                                isWished ? favouriteController.removeFromFavouriteList(restaurant[index].id, true)
                                    : favouriteController.addToFavouriteList(null, restaurant[index].id, true);
                              }else {
                                showCustomSnackBar('you_are_not_logged_in'.tr);
                              }
                            },
                          ),
                        );
                      }),
                    ),
                  ),
                );
              },
            ) : PopularStoreShimmer(restaurantController: restaurantController),
          ),
        ],
      );
    });
  }
}

class PopularStoreShimmer extends StatelessWidget {
  final RestaurantController restaurantController;
  const PopularStoreShimmer({super.key, required this.restaurantController});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
      itemCount: 10,
      itemBuilder: (context, index){
        return Container(
          height: 150,
          width: 200,
          margin: const EdgeInsets.only(right: Dimensions.paddingSizeSmall, bottom: 5),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
              boxShadow: AppShadows.card
          ),
          child: Shimmer(
            duration: const Duration(seconds: 2),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

              Container(
                height: 90, width: 200,
                decoration: BoxDecoration(
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(Dimensions.radiusDefault)),
                    color: const Color(0xFFEFE3D2)
                ),
              ),

              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeExtraSmall),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                    Container(height: 10, width: 100, color: const Color(0xFFEFE3D2)),
                    const SizedBox(height: 5),

                    Container(height: 10, width: 130, color: const Color(0xFFEFE3D2)),
                    const SizedBox(height: 5),

                    const RatingBarWidget(rating: 0.0, size: 12, ratingCount: 0),
                  ]),
                ),
              ),

            ]),
          ),
        );
      },
    );
  }
}

