import 'package:countasty/common/models/product_model.dart';
import 'package:countasty/features/review/controllers/review_controller.dart';
import 'package:countasty/helper/price_converter.dart';
import 'package:countasty/helper/product_helper.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/product_bottom_sheet_widget.dart';
import 'package:countasty/common/widgets/not_available_widget.dart';
import 'package:countasty/common/widgets/title_widget.dart';
import 'package:countasty/common/widgets/media_card_widget.dart';
import 'package:flutter/material.dart';
import 'package:shimmer_animation/shimmer_animation.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

class BestReviewedItemWidget1 extends StatelessWidget {
  const BestReviewedItemWidget1({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ReviewController>(builder: (reviewController) {
      List<Product>? productList = reviewController.reviewedProductList;

      return (productList != null && productList.isEmpty) ? const SizedBox() : Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 15, 10, 10),
            child: TitleWidget(
              title: 'best_reviewed_food'.tr,
              onTap: () => Get.toNamed(RouteHelper.getPopularFoodRoute(false)),
            ),
          ),

          SizedBox(
            height: 205,
            child: productList != null ? ListView.builder(
              controller: ScrollController(),
              physics: const BouncingScrollPhysics(),
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall, top: Dimensions.paddingSizeExtraSmall),
              itemCount: productList.length > 10 ? 10 : productList.length,
              itemBuilder: (context, index){
                return Padding(
                  padding: const EdgeInsets.only(right: Dimensions.paddingSizeSmall, bottom: 5),
                  child: InkWell(
                    onTap: () {
                      ResponsiveHelper.isMobile(context) ? Get.bottomSheet(
                        ProductBottomSheetWidget(product: productList[index], isCampaign: false),
                        backgroundColor: Colors.transparent, isScrollControlled: true,
                      ) : Get.dialog(
                        Dialog(child: ProductBottomSheetWidget(product: productList[index])),
                      );
                    },
                    // Card in the reference idiom: a circular plate image that
                    // breaks out of the card's top edge, then title, rating and
                    // price stacked beneath it.
                    child: MediaCard(
                      height: 190, width: 175,
                      image: '${productList[index].imageFullUrl}',
                      title: productList[index].name ?? '',
                      isFood: true,
                      titleSize: Dimensions.fontSizeDefault,
                      chips: [productList[index].restaurantName ?? ''],
                      maxChips: 1,
                      trailing: MediaCardMeta(
                        icon: Symbols.sell,
                        label: PriceConverter.convertPrice(
                          productList[index].price,
                          discount: ProductHelper.getDiscount(productList[index]),
                          discountType: ProductHelper.getDiscountType(productList[index]),
                        ),
                      ),
                      overlays: [
                        ProductHelper.isAvailable(productList[index]) ? const SizedBox() : const NotAvailableWidget(isRestaurant: true),
                      ],
                    ),
                  ),
                );
              },
            ) : BestReviewedItemShimmer(reviewController: reviewController),
          ),
        ],
      );
    });
  }
}

class BestReviewedItemShimmer extends StatelessWidget {
  final ReviewController reviewController;
  const BestReviewedItemShimmer({super.key, required this.reviewController});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
      itemCount: 10,
      itemBuilder: (context, index){
        return Padding(
          padding: const EdgeInsets.only(right: Dimensions.paddingSizeSmall, bottom: 5),
          child: Container(
            height: 220, width: 180,
            padding: const EdgeInsets.all(Dimensions.paddingSizeExtraSmall),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
              border: Border.all(color: AppSurface.hairline(context), width: 1),
              boxShadow: AppShadows.card,
            ),
            child: Shimmer(
              duration: const Duration(seconds: 2),
              enabled: reviewController.reviewedProductList == null,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [

                Stack(children: [
                  Container(
                    height: 125, width: 170,
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(Dimensions.radiusDefault)),
                      color: const Color(0xFFEFE3D2),
                    ),
                  ),

                  Positioned(
                    top: Dimensions.paddingSizeExtraSmall, left: Dimensions.paddingSizeExtraSmall,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 2, horizontal: Dimensions.paddingSizeExtraSmall),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor.withValues(alpha: 0.8),
                        borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                      ),
                      child: Row(children: [
                        Icon(Symbols.star, fill: 1, color: Theme.of(context).primaryColor, size: 15),
                        const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                        Text('0.0', style: robotoRegular),
                      ]),
                    ),
                  ),
                ]),

                Expanded(
                  child: Stack(children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeExtraSmall),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        Container(height: 15, width: 100, color: const Color(0xFFEFE3D2)),
                        const SizedBox(height: 2),

                        Container(height: 10, width: 70, color: const Color(0xFFEFE3D2)),
                        const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                        Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Container(height: 10, width: 40, color: const Color(0xFFEFE3D2)),
                          const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                        Container(height: 15, width: 40, color: const Color(0xFFEFE3D2)),
                        ]),
                      ]),
                    ),
                    Positioned(bottom: 0, right: 0, child: Container(
                      height: 25, width: 25,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Theme.of(context).primaryColor
                      ),
                      child: const Icon(Symbols.add, size: 20, color: Colors.white),
                    )),
                  ]),
                ),

              ]),
            ),
          ),
        );
      },
    );
  }
}