import 'package:countasty/features/product/controllers/campaign_controller.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/common/widgets/product_bottom_sheet_widget.dart';
import 'package:countasty/common/widgets/title_widget.dart';
import 'package:countasty/common/widgets/media_card_widget.dart';
import 'package:countasty/helper/price_converter.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:flutter/material.dart';
import 'package:shimmer_animation/shimmer_animation.dart';
import 'package:get/get.dart';

class ItemCampaignWidget1 extends StatelessWidget {
  const ItemCampaignWidget1({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CampaignController>(builder: (campaignController) {
      return (campaignController.itemCampaignList != null && campaignController.itemCampaignList!.isEmpty) ? const SizedBox() : Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 15, 10, 10),
            child: TitleWidget(title: 'trending_food_offers'.tr, onTap: () => Get.toNamed(RouteHelper.getItemCampaignRoute())),
          ),

          SizedBox(
            height: 150,
            child: campaignController.itemCampaignList != null ? ListView.builder(
              controller: ScrollController(),
              physics: const BouncingScrollPhysics(),
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
              itemCount: campaignController.itemCampaignList!.length > 10 ? 10 : campaignController.itemCampaignList!.length,
              itemBuilder: (context, index){
                return Padding(
                  padding: const EdgeInsets.only(right: Dimensions.paddingSizeSmall, bottom: 5),
                  child: InkWell(
                    onTap: () {
                      ResponsiveHelper.isMobile(context) ? Get.bottomSheet(
                        ProductBottomSheetWidget(product: campaignController.itemCampaignList![index], isCampaign: true),
                        backgroundColor: Colors.transparent, isScrollControlled: true,
                      ) : Get.dialog(
                        Dialog(child: ProductBottomSheetWidget(product: campaignController.itemCampaignList![index], isCampaign: true)),
                      );
                    },
                    child: MediaCard(
                      height: 150, width: 170,
                      image: '${campaignController.itemCampaignList![index].imageFullUrl}',
                      title: campaignController.itemCampaignList![index].name ?? '',
                      isFood: true,
                      titleSize: Dimensions.fontSizeDefault,
                      chips: [campaignController.itemCampaignList![index].restaurantName ?? ''],
                      maxChips: 1,
                      trailing: MediaCardMeta(
                        icon: Symbols.sell,
                        label: PriceConverter.convertPrice(
                          campaignController.itemCampaignList![index].price,
                          discount: campaignController.itemCampaignList![index].discount,
                          discountType: campaignController.itemCampaignList![index].discountType,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ) : ItemCampaignShimmer(campaignController: campaignController),
          ),
        ],
      );
    });
  }
}

class ItemCampaignShimmer extends StatelessWidget {
  final CampaignController campaignController;
  const ItemCampaignShimmer({super.key, required this.campaignController});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
      itemCount: 10,
      itemBuilder: (context, index){
        return Padding(
          padding: const EdgeInsets.only(right: Dimensions.paddingSizeSmall, bottom: 5),
          child: Shimmer(
            duration: const Duration(seconds: 2),
            enabled: campaignController.itemCampaignList == null,
            child: Container(
              height: 150, width: 150,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                color: const Color(0xFFEFE3D2),
              ),
            ),
          ),
        );
      },
    );
  }
}

