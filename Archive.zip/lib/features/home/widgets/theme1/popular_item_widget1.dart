import 'package:countasty/common/widgets/rating_bar_widget.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/common/models/product_model.dart';
import 'package:countasty/features/product/controllers/product_controller.dart';
import 'package:countasty/features/review/controllers/review_controller.dart';
import 'package:countasty/helper/price_converter.dart';
import 'package:countasty/helper/product_helper.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/images.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_image_widget.dart';
import 'package:countasty/common/widgets/not_available_widget.dart';
import 'package:countasty/common/widgets/product_bottom_sheet_widget.dart';
import 'package:countasty/common/widgets/title_widget.dart';
import 'package:flutter/material.dart';
import 'package:shimmer_animation/shimmer_animation.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

class PopularItemWidget1 extends StatelessWidget {
  final bool isPopular;
  const PopularItemWidget1({super.key, required this.isPopular});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ReviewController>(builder: (reviewController) {
        return GetBuilder<ProductController>(builder: (productController) {
          List<Product>? productList = isPopular ? productController.popularProductList : reviewController.reviewedProductList;

          return (productList != null && productList.isEmpty) ? const SizedBox() : Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 15, 10, 10),
                child: TitleWidget(
                  title: isPopular ? 'popular_foods_nearby'.tr : 'best_reviewed_food'.tr,
                  onTap: () => Get.toNamed(RouteHelper.getPopularFoodRoute(isPopular)),
                ),
              ),

              SizedBox(
                height: 108,
                child: productList != null ? ListView.builder(
                  controller: ScrollController(),
                  physics: const BouncingScrollPhysics(),
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
                  itemCount: productList.length > 10 ? 10 : productList.length,
                  itemBuilder: (context, index){
                    return Padding(
                      padding: const EdgeInsets.fromLTRB(2, 2, Dimensions.paddingSizeSmall, 2),
                      child: InkWell(
                        onTap: () {
                          ResponsiveHelper.isMobile(context) ? Get.bottomSheet(
                            ProductBottomSheetWidget(product: productList[index], isCampaign: false),
                            backgroundColor: Colors.transparent, isScrollControlled: true,
                          ) : Get.dialog(
                            Dialog(child: ProductBottomSheetWidget(product: productList[index])),
                          );
                        },
                        // Row card in the reference idiom: circular plate thumb,
                        // stacked text, and a discount badge on the card corner.
                        child: SizedBox(
                          height: 96, width: 268,
                          child: Stack(clipBehavior: Clip.none, children: [

                            Container(
                              height: 96, width: 268,
                              padding: const EdgeInsets.symmetric(
                                horizontal: Dimensions.paddingSizeSmall, vertical: Dimensions.paddingSizeSmall,
                              ),
                              decoration: AppSurface.card(context, radius: Dimensions.radiusDefault),
                              child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [

                                Container(
                                  decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: AppShadows.low),
                                  child: ClipOval(
                                    child: Stack(children: [
                                      CustomImageWidget(
                                        image: '${productList[index].imageFullUrl}',
                                        height: 72, width: 72, fit: BoxFit.cover,
                                        isFood: true,
                                      ),
                                    ProductHelper.isAvailable(productList[index]) ? const SizedBox() : const NotAvailableWidget(),
                                  ]),
                                ),
                                ),
                                const SizedBox(width: Dimensions.paddingSizeSmall),

                                Expanded(
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [

                                    Wrap(crossAxisAlignment: WrapCrossAlignment.center, children: [
                                      Text(
                                        productList[index].name!,
                                        style: robotoBold.copyWith(fontSize: Dimensions.fontSizeSmall),
                                        maxLines: 1, overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                                      (Get.find<SplashController>().configModel!.toggleVegNonVeg!)
                                          ? Image.asset(productList[index].veg == 0 ? Images.nonVegImage : Images.vegImage,
                                        height: 10, width: 10, fit: BoxFit.contain,
                                      ) : const SizedBox(),
                                    ]),
                                    const SizedBox(height: 2),

                                    Text(
                                      productList[index].restaurantName!,
                                      style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).hintColor),
                                      maxLines: 1, overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 2),

                                    Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                                      Flexible(
                                        child: Text(
                                          PriceConverter.convertPrice(
                                            productList[index].price, discount: productList[index].discount,
                                            discountType: productList[index].discountType,
                                          ),
                                          style: robotoBold.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).primaryColor),
                                          maxLines: 1, overflow: TextOverflow.ellipsis,
                                        ),
                                      ),

                                      productList[index].discount! > 0 ? Flexible(child: Padding(
                                        padding: const EdgeInsets.only(left: Dimensions.paddingSizeExtraSmall),
                                        child: Text(
                                          PriceConverter.convertPrice(productList[index].price),
                                          style: robotoRegular.copyWith(
                                            fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).hintColor,
                                            decoration: TextDecoration.lineThrough,
                                          ),
                                          maxLines: 1, overflow: TextOverflow.ellipsis,
                                        ),
                                      )) : const SizedBox(),

                                      const Spacer(),

                                      Container(
                                        height: 26, width: 26,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Theme.of(context).primaryColor,
                                          boxShadow: AppShadows.glow(Theme.of(context).primaryColor, opacity: 0.32),
                                        ),
                                        child: const Icon(Symbols.add, size: 18, color: Colors.white),
                                      ),
                                    ]),
                                  ]),
                                ),

                              ]),
                            ),

                            (ProductHelper.getDiscount(productList[index])! > 0) ? Positioned(
                              top: -4, right: -2,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall, vertical: 3),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.error,
                                  borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                                  boxShadow: AppShadows.glow(Theme.of(context).colorScheme.error, opacity: 0.30),
                                ),
                                child: Text(
                                  ProductHelper.getDiscountType(productList[index]) == 'percent'
                                      ? '${ProductHelper.getDiscount(productList[index])!.toStringAsFixed(0)}% ${'off'.tr}'
                                      : 'off'.tr,
                                  style: robotoBold.copyWith(fontSize: 9, color: Colors.white, letterSpacing: 0.2),
                                ),
                              ),
                            ) : const SizedBox(),

                          ]),
                        ),
                      ),
                    );
                  },
                ) : PopularItemShimmer(enabled: productList == null),
              ),
            ],
          );
        });
      }
    );
  }
}

class PopularItemShimmer extends StatelessWidget {
  final bool enabled;
  const PopularItemShimmer({super.key, required this.enabled});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
      itemCount: 10,
      itemBuilder: (context, index){
        return Padding(
          padding: const EdgeInsets.fromLTRB(2, 2, Dimensions.paddingSizeSmall, 2),
          child: Container(
            height: 90, width: 250,
            padding: const EdgeInsets.all(Dimensions.paddingSizeExtraSmall),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
              border: Border.all(color: AppSurface.hairline(context), width: 1),
              boxShadow: AppShadows.card,
            ),
            child: Shimmer(
              duration: const Duration(seconds: 1),
              interval: const Duration(seconds: 1),
              enabled: enabled,
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [

                Container(
                  height: 80, width: 80,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                    color: const Color(0xFFEFE3D2),
                  ),
                ),

                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeExtraSmall),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                      Container(height: 15, width: 100, color: const Color(0xFFEFE3D2)),
                      const SizedBox(height: 5),

                      Container(height: 10, width: 130, color: const Color(0xFFEFE3D2)),
                      const SizedBox(height: 5),

                      const RatingBarWidget(rating: 0, size: 12, ratingCount: 0),

                      Row(children: [
                        Expanded(
                          child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                            const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                            Container(height: 10, width: 40, color: const Color(0xFFEFE3D2)),
                            Container(height: 15, width: 40, color: const Color(0xFFEFE3D2)),
                          ]),
                        ),
                        Container(
                          height: 25, width: 25,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Theme.of(context).primaryColor
                          ),
                          child: const Icon(Symbols.add, size: 20, color: Colors.white),
                        ),
                      ]),
                    ]),
                  ),
                ),

              ]),
            ),
          ),
        );
      },
    );
  }
}

