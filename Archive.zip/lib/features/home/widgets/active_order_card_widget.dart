import 'package:countasty/features/order/controllers/order_controller.dart';
import 'package:countasty/features/order/domain/models/order_model.dart';
import 'package:countasty/features/order/screens/order_details_screen.dart';
import 'package:countasty/helper/auth_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_constants.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/images.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

/// Live order status surfaced in the home feed. Replaces the sheet that used
/// to sit pinned over the bottom nav bar.
class ActiveOrderCardWidget extends StatelessWidget {
  const ActiveOrderCardWidget({super.key});

  /// Maps the API's order_status onto the four track segments.
  int _statusStep(String status) {
    if (status == AppConstants.pending) return 1;
    if (status == AppConstants.accepted || status == AppConstants.processing || status == AppConstants.confirmed) return 2;
    if (status == AppConstants.handover || status == AppConstants.pickedUp) return 3;
    return 0;
  }

  String _statusImage(String status, int step) {
    if (step == 2) {
      return (status == AppConstants.confirmed || status == AppConstants.accepted) ? Images.processingGif : Images.cookingGif;
    }
    if (step == 3) {
      return status == AppConstants.handover ? Images.handoverGif : Images.onTheWayGif;
    }
    return Images.pendingGif;
  }

  @override
  Widget build(BuildContext context) {
    if (!AuthHelper.isLoggedIn()) return const SizedBox();

    return GetBuilder<OrderController>(builder: (orderController) {
      final List<OrderModel> running = orderController.runningOrderList ?? [];
      if (running.isEmpty) return const SizedBox();

      // Newest order leads; the rest are reachable via the "+N more" affordance.
      final List<OrderModel> orders = List.from(running.reversed);
      final OrderModel order = orders.first;
      final String status = order.orderStatus ?? '';
      final int step = _statusStep(status);

      return Padding(
        padding: const EdgeInsets.fromLTRB(
          Dimensions.paddingSizeDefault, Dimensions.paddingSizeSmall,
          Dimensions.paddingSizeDefault, Dimensions.paddingSizeSmall,
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          onTap: () => Get.toNamed(
            RouteHelper.getOrderDetailsRoute(order.id),
            arguments: OrderDetailsScreen(orderId: order.id, orderModel: order),
          ),
          child: Container(
            padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
            decoration: AppSurface.card(context, radius: Dimensions.radiusDefault),
            child: Column(children: [

              Row(crossAxisAlignment: CrossAxisAlignment.center, children: [

                SizedBox(
                  height: 48, width: 48,
                  child: Image.asset(_statusImage(status, step), fit: BoxFit.contain),
                ),
                const SizedBox(width: Dimensions.paddingSizeSmall),

                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [

                    Row(children: [
                      Flexible(
                        child: Text(
                          '${'your_order_is'.tr} ${status.tr}',
                          style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault),
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ]),
                    const SizedBox(height: 2),

                    Text(
                      '${'order'.tr} #${order.id}',
                      style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).hintColor),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                  ]),
                ),
                const SizedBox(width: Dimensions.paddingSizeSmall),

                // More-orders badge, or a plain chevron when this is the only one.
                orders.length > 1 ? InkWell(
                  borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                  onTap: () => Get.toNamed(RouteHelper.getOrderRoute()),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: Dimensions.paddingSizeSmall, vertical: Dimensions.paddingSizeExtraSmall,
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                    ),
                    child: Text(
                      '+${orders.length - 1} ${'more'.tr}',
                      style: robotoBold.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).primaryColor),
                    ),
                  ),
                ) : Icon(Symbols.chevron_right, size: 20, color: Theme.of(context).primaryColor),
              ]),
              const SizedBox(height: Dimensions.paddingSizeDefault),

              Row(children: List.generate(4, (i) {
                return Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(right: i == 3 ? 0 : Dimensions.paddingSizeExtraSmall),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      height: 5,
                      decoration: BoxDecoration(
                        color: step >= i + 1
                            ? Theme.of(context).primaryColor
                            : Theme.of(context).disabledColor.withValues(alpha: 0.4),
                        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                      ),
                    ),
                  ),
                );
              })),

            ]),
          ),
        ),
      );
    });
  }
}
