import 'package:countasty/features/category/controllers/category_controller.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_image_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shimmer_animation/shimmer_animation.dart';

class WhatOnYourMindViewWidget extends StatelessWidget {
  const WhatOnYourMindViewWidget({super.key});

  @override
  Widget build(BuildContext context) {
    const double pillHeight = 62;
    const int maxCategories = 10;

    return GetBuilder<CategoryController>(builder: (categoryController) {
      if (categoryController.categoryList == null) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeDefault),
          child: _CategoryPillShimmer(pillHeight: pillHeight),
        );
      }

      final categories = categoryController.categoryList!.length > maxCategories
          ? categoryController.categoryList!.sublist(0, maxCategories)
          : categoryController.categoryList!;

      return Padding(
        padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeDefault),
        child: SizedBox(
          height: pillHeight,
          child: ListView.builder(
            physics: const BouncingScrollPhysics(),
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
            // +1 for the "All" pill at start
            itemCount: categories.length + 1,
            itemBuilder: (context, index) {
              // "All" pill — dark filled
              if (index == 0) {
                return GestureDetector(
                  onTap: () => Get.toNamed(RouteHelper.getCategoryRoute()),
                  child: Container(
                    margin: const EdgeInsets.only(right: 10),
                    padding: const EdgeInsets.symmetric(horizontal: 26),
                    height: pillHeight,
                    decoration: BoxDecoration(
                      color: Theme.of(context).textTheme.bodyLarge!.color,
                      borderRadius: BorderRadius.circular(pillHeight / 2),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      'all'.tr,
                      style: robotoBold.copyWith(
                        fontSize: Dimensions.fontSizeDefault,
                        color: Theme.of(context).cardColor,
                      ),
                    ),
                  ),
                );
              }

              // Category pill — white/card with image + text
              final category = categories[index - 1];
              return GestureDetector(
                onTap: () => Get.toNamed(
                  RouteHelper.getCategoryProductRoute(category.id, category.name!),
                ),
                child: Container(
                  margin: const EdgeInsets.only(right: 10),
                  height: pillHeight,
                  padding: const EdgeInsets.only(left: 6, right: 16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(pillHeight / 2),
                    border: Border.all(color: AppSurface.hairline(context), width: 1),
                    boxShadow: AppShadows.card,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Category image inside pill
                      ClipRRect(
                        borderRadius: BorderRadius.circular(pillHeight / 2 - 6),
                        child: CustomImageWidget(
                          image: category.imageFullUrl ?? '',
                          height: pillHeight - 12,
                          width: pillHeight - 12,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Category name
                      Text(
                        category.name!,
                        style: robotoMedium.copyWith(
                          fontSize: Dimensions.fontSizeDefault,
                          color: Theme.of(context).textTheme.bodyLarge!.color,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      );
    });
  }
}

class _CategoryPillShimmer extends StatelessWidget {
  final double pillHeight;
  const _CategoryPillShimmer({required this.pillHeight});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: pillHeight,
      child: ListView.builder(
        physics: const NeverScrollableScrollPhysics(),
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
        itemCount: 5,
        itemBuilder: (context, index) {
          final double width = index == 0 ? 80 : 130;
          return Padding(
            padding: const EdgeInsets.only(right: 10),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(pillHeight / 2),
              child: Shimmer(
                child: Container(
                  width: width,
                  height: pillHeight,
                  color: Theme.of(context).shadowColor,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
