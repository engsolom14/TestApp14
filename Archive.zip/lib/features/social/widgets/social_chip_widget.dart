import 'package:flutter/material.dart';
import 'package:material_symbols_icons/symbols.dart';

import 'package:countasty/util/images.dart';

/// Platform artwork and brand colours for the social channels.
///
/// The bundled glyphs are white-on-transparent — they were drawn for the dark
/// footer, and vanish on a light card. Every use therefore sits the glyph on
/// its platform colour, which is both legible on any surface and the
/// convention people already recognise.
class SocialBrand {
  SocialBrand._();

  static const Map<String, String> icons = <String, String>{
    'facebook': Images.facebook,
    'twitter': Images.twitter,
    'instagram': Images.instagram,
    'linkedin': Images.linkedin,
    'youtube': Images.youtube,
  };

  static const Map<String, Color> colors = <String, Color>{
    'facebook': Color(0xFF1877F2),
    'twitter': Color(0xFF1DA1F2),
    'instagram': Color(0xFFE4405F),
    'linkedin': Color(0xFF0A66C2),
    'youtube': Color(0xFFFF0000),
  };

  static String key(String? name) => (name ?? '').trim().toLowerCase();

  static bool isKnown(String? name) => icons.containsKey(key(name));
}

/// A platform glyph on its brand colour.
class SocialChipWidget extends StatelessWidget {
  final String? name;
  final double size;

  /// Ring in the surrounding surface colour, so overlapping chips in a stack
  /// stay separable. Null for standalone chips.
  final Color? ringColor;

  const SocialChipWidget({super.key, required this.name, this.size = 26, this.ringColor});

  @override
  Widget build(BuildContext context) {
    final String k = SocialBrand.key(name);
    final String? asset = SocialBrand.icons[k];
    final Color color = SocialBrand.colors[k] ?? Theme.of(context).primaryColor;

    return Container(
      height: size,
      width: size,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: ringColor != null ? Border.all(color: ringColor!, width: 1.5) : null,
      ),
      padding: EdgeInsets.all(size * 0.22),
      child: asset != null
          // The glyph is already white; leave its own alpha to shape it.
          ? Image.asset(asset, fit: BoxFit.contain)
          : Icon(Symbols.link, size: size * 0.5, color: Colors.white),
    );
  }
}
