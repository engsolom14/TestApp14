import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:url_launcher/url_launcher_string.dart';

import 'package:countasty/common/widgets/custom_app_bar_widget.dart';
import 'package:countasty/common/widgets/custom_snackbar_widget.dart';
import 'package:countasty/common/widgets/menu_drawer_widget.dart';
import 'package:countasty/common/widgets/no_data_screen_widget.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/features/splash/domain/models/config_model.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/images.dart';
import 'package:countasty/features/social/widgets/social_chip_widget.dart';
import 'package:countasty/util/styles.dart';

/// The channels Countasty is on, driven entirely by the `social_media` block
/// in the config — the admin panel decides which platforms appear and where
/// they point, so this screen never needs editing to add one.
class FollowUsScreen extends StatelessWidget {
  const FollowUsScreen({super.key});

  /// Turns "facebook" into "Facebook" without needing a translation key per
  /// platform — these are proper nouns and stay untranslated anyway.
  String _label(String? name) {
    final String raw = (name ?? '').trim();
    if (raw.isEmpty) return '';
    return raw[0].toUpperCase() + raw.substring(1);
  }

  Future<void> _open(String? link) async {
    final String url = (link ?? '').trim();
    if (url.isEmpty) {
      showCustomSnackBar('no_link_found'.tr);
      return;
    }
    // The admin panel stores bare handles as often as full URLs.
    final String target = url.startsWith('http') ? url : 'https://$url';
    if (await canLaunchUrlString(target)) {
      await launchUrlString(target, mode: LaunchMode.externalApplication);
    } else {
      showCustomSnackBar('unable_to_launch_the_link'.tr);
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<SocialMedia> channels = (Get.find<SplashController>().configModel?.socialMedia ?? <SocialMedia>[])
        .where((SocialMedia s) => s.status == 1 && (s.name ?? '').trim().isNotEmpty)
        .toList();

    return Scaffold(
      appBar: CustomAppBarWidget(title: 'follow_us'.tr),
      endDrawer: const MenuDrawerWidget(), endDrawerEnableOpenDragGesture: false,
      body: channels.isEmpty
          ? NoDataScreen(title: 'no_social_media_found'.tr)
          : SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeDefault),
              child: Center(child: SizedBox(width: Dimensions.webMaxWidth, child: Column(children: [

                /// Brand banner, in the accent rather than a stock illustration.
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                  padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                      colors: [
                        Theme.of(context).primaryColor,
                        Theme.of(context).primaryColor.withValues(alpha: 0.75),
                      ],
                    ),
                    boxShadow: AppShadows.glow(Theme.of(context).primaryColor, opacity: 0.30),
                  ),
                  child: Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('follow_us'.tr, style: displayExtraBold.copyWith(fontSize: 24, color: Colors.white)),
                      const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                      Text(
                        'stay_tuned_with_our_latest_offers'.tr,
                        style: robotoRegular.copyWith(
                          fontSize: Dimensions.fontSizeSmall,
                          color: Colors.white.withValues(alpha: 0.9),
                        ),
                      ),
                    ])),
                    const SizedBox(width: Dimensions.paddingSizeDefault),
                    Image.asset(Images.logo, height: 56, width: 56),
                  ]),
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),

                /// One card holding the channel list, matching the menu screen.
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                  padding: const EdgeInsets.symmetric(
                    horizontal: Dimensions.paddingSizeLarge, vertical: Dimensions.paddingSizeExtraSmall,
                  ),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                    border: Border.all(color: AppSurface.hairline(context), width: 1),
                    boxShadow: AppShadows.card,
                  ),
                  child: Column(children: List<Widget>.generate(channels.length, (int i) {
                    final SocialMedia channel = channels[i];

                    return InkWell(
                      onTap: () => _open(channel.link),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall),
                        child: Column(children: [
                          Row(children: [
                            SocialChipWidget(name: channel.name, size: 30),
                            const SizedBox(width: Dimensions.paddingSizeDefault),

                            Expanded(child: Text(
                              _label(channel.name),
                              style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeDefault),
                            )),

                            Icon(Symbols.chevron_right, size: 20, color: Theme.of(context).hintColor),
                          ]),

                          // No rule under the last row — the card edge ends it.
                          if (i != channels.length - 1) const Divider(),
                        ]),
                      ),
                    );
                  })),
                ),

              ]))),
            ),
    );
  }
}
