import 'dart:convert';

import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:countasty/features/nutrition/domain/models/calorie_entry_model.dart';
import 'package:countasty/util/app_constants.dart';

/// Daily calorie goal and today's intake.
///
/// Phase 1 is device-local by design — no backend field exists for a goal, and
/// products carry no calorie value yet. Everything here is written to
/// SharedPreferences so the feature is usable now; swapping the two `_save`
/// calls for API writes is the only change needed to move it server-side.
class NutritionController extends GetxController implements GetxService {
  final SharedPreferences sharedPreferences;
  NutritionController({required this.sharedPreferences}) {
    _load();
  }

  int? _goal;
  int? get goal => _goal;
  bool get hasGoal => _goal != null && _goal! > 0;

  List<CalorieEntry> _entries = [];

  /// Orders already logged, so a delivered order is never offered twice.
  Set<int> _loggedOrders = {};

  /// Remembered calories per product. The catalogue has no calorie figure, so
  /// the first time a dish is logged the number is kept and pre-filled on every
  /// later order of the same dish — the feature gets sharper with use.
  Map<int, int> _productCalories = {};

  bool isOrderLogged(int orderId) => _loggedOrders.contains(orderId);
  int? rememberedCaloriesFor(int? productId) =>
      productId == null ? null : _productCalories[productId];

  /// Records a whole order in one go and remembers each dish's calories.
  void addOrderEntries(int orderId, List<({String title, int calories, int? productId})> items) {
    for (final item in items) {
      if (item.calories <= 0) continue;
      _entries.add(CalorieEntry(
        id: '${DateTime.now().microsecondsSinceEpoch}_${item.productId ?? item.title.hashCode}',
        title: item.title,
        calories: item.calories,
        time: DateTime.now(),
        productId: item.productId,
        orderId: orderId,
      ));
      if (item.productId != null) _productCalories[item.productId!] = item.calories;
    }
    _loggedOrders.add(orderId);
    _saveEntries();
    _saveOrderMeta();
    update();
  }

  /// Dismissing is permanent for that order — nagging is worse than a gap.
  void skipOrder(int orderId) {
    _loggedOrders.add(orderId);
    _saveOrderMeta();
    update();
  }

  void _saveOrderMeta() {
    sharedPreferences.setString(AppConstants.calorieLoggedOrders, jsonEncode(_loggedOrders.toList()));
    sharedPreferences.setString(AppConstants.calorieProductMemory,
        jsonEncode(_productCalories.map((k, v) => MapEntry(k.toString(), v))));
  }

  /// Only today's entries — yesterday's are kept on disk for history but never
  /// counted toward today's total.
  List<CalorieEntry> get todayEntries {
    final now = DateTime.now();
    final list = _entries.where((e) => _isSameDay(e.time, now)).toList();
    list.sort((a, b) => b.time.compareTo(a.time));
    return list;
  }

  int get consumed => todayEntries.fold(0, (sum, e) => sum + e.calories);

  int get remaining => hasGoal ? (_goal! - consumed) : 0;

  /// 0..1, clamped so an over-budget day fills the ring rather than overflowing.
  double get progress {
    if (!hasGoal) return 0;
    return (consumed / _goal!).clamp(0.0, 1.0);
  }

  bool get isOverGoal => hasGoal && consumed > _goal!;

  void setGoal(int value) {
    _goal = value;
    sharedPreferences.setInt(AppConstants.calorieGoal, value);
    update();
  }

  void addEntry({required String title, required int calories, int? productId, int? orderId}) {
    _entries.add(CalorieEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: title.trim().isEmpty ? 'meal'.tr : title.trim(),
      calories: calories,
      time: DateTime.now(),
      productId: productId,
      orderId: orderId,
    ));
    _saveEntries();
    update();
  }

  void updateEntry(String id, {String? title, int? calories}) {
    final i = _entries.indexWhere((e) => e.id == id);
    if (i == -1) return;
    _entries[i] = _entries[i].copyWith(title: title, calories: calories);
    _saveEntries();
    update();
  }

  void removeEntry(String id) {
    _entries.removeWhere((e) => e.id == id);
    _saveEntries();
    update();
  }

  void _load() {
    final storedGoal = sharedPreferences.getInt(AppConstants.calorieGoal);
    if (storedGoal != null && storedGoal > 0) _goal = storedGoal;

    final loggedRaw = sharedPreferences.getString(AppConstants.calorieLoggedOrders);
    if (loggedRaw != null && loggedRaw.isNotEmpty) {
      try {
        _loggedOrders = (jsonDecode(loggedRaw) as List).map((e) => e as int).toSet();
      } catch (_) {
        _loggedOrders = {};
      }
    }

    final memoryRaw = sharedPreferences.getString(AppConstants.calorieProductMemory);
    if (memoryRaw != null && memoryRaw.isNotEmpty) {
      try {
        _productCalories = (jsonDecode(memoryRaw) as Map)
            .map((k, v) => MapEntry(int.parse(k.toString()), v as int));
      } catch (_) {
        _productCalories = {};
      }
    }

    final raw = sharedPreferences.getString(AppConstants.calorieEntries);
    if (raw != null && raw.isNotEmpty) {
      try {
        final List<dynamic> decoded = jsonDecode(raw);
        _entries = decoded.map((e) => CalorieEntry.fromJson(e)).toList();
        _pruneOldEntries();
      } catch (_) {
        // Corrupt payload shouldn't wedge the app — start clean.
        _entries = [];
      }
    }
    update();
  }

  /// Keep a fortnight so a history view has something to show, without the
  /// stored blob growing without bound.
  void _pruneOldEntries() {
    final cutoff = DateTime.now().subtract(const Duration(days: 14));
    _entries.removeWhere((e) => e.time.isBefore(cutoff));
  }

  void _saveEntries() {
    _pruneOldEntries();
    sharedPreferences.setString(
      AppConstants.calorieEntries,
      jsonEncode(_entries.map((e) => e.toJson()).toList()),
    );
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}
