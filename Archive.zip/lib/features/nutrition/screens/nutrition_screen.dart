import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:countasty/common/widgets/custom_app_bar_widget.dart';
import 'package:countasty/common/widgets/custom_button_widget.dart';
import 'package:countasty/features/nutrition/controllers/nutrition_controller.dart';
import 'package:countasty/features/nutrition/widgets/calorie_entry_sheet.dart';
import 'package:countasty/features/nutrition/widgets/calorie_ring_widget.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';

class NutritionScreen extends StatelessWidget {
  const NutritionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      appBar: CustomAppBarWidget(title: 'my_goal'.tr),
      body: GetBuilder<NutritionController>(builder: (controller) {

        if (!controller.hasGoal) return const _GoalEmptyState();

        final entries = controller.todayEntries;

        return ListView(
          padding: const EdgeInsets.fromLTRB(
            Dimensions.paddingSizeDefault, Dimensions.paddingSizeDefault,
            Dimensions.paddingSizeDefault, 120,
          ),
          children: [

            /// Today's summary.
            Container(
              padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
              decoration: AppSurface.card(context),
              child: Row(children: [

                CalorieRingWidget(
                  progress: controller.progress,
                  remaining: controller.remaining,
                  isOver: controller.isOverGoal,
                ),
                const SizedBox(width: Dimensions.paddingSizeLarge),

                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                    _Stat(label: 'daily_goal'.tr, value: '${controller.goal} kcal'),
                    const SizedBox(height: Dimensions.paddingSizeSmall),
                    _Stat(label: 'eaten'.tr, value: '${controller.consumed} kcal', accent: true),
                    const SizedBox(height: Dimensions.paddingSizeSmall),

                    InkWell(
                      onTap: () => _editGoal(context, controller),
                      borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Symbols.edit, size: 15, color: Theme.of(context).primaryColor),
                          const SizedBox(width: 4),
                          Text('change_goal'.tr, style: robotoMedium.copyWith(
                            fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).primaryColor,
                          )),
                        ]),
                      ),
                    ),
                  ]),
                ),
              ]),
            ),
            const SizedBox(height: Dimensions.paddingSizeLarge),

            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('todays_intake'.tr, style: displaySemiBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
              Text('${entries.length} ${'items'.tr}', style: robotoRegular.copyWith(
                fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).hintColor,
              )),
            ]),
            const SizedBox(height: Dimensions.paddingSizeSmall),

            entries.isEmpty ? Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeOverLarge),
              decoration: AppSurface.card(context),
              child: Column(children: [
                Icon(Symbols.restaurant, size: 34, color: Theme.of(context).primaryColor.withValues(alpha: 0.7)),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                Text('nothing_logged_yet'.tr, style: robotoMedium.copyWith(color: Theme.of(context).hintColor)),
              ]),
            ) : Column(children: entries.map((e) => Padding(
              padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
              child: InkWell(
                onTap: () => Get.bottomSheet(
                  CalorieEntrySheet(entry: e), backgroundColor: Colors.transparent, isScrollControlled: true,
                ),
                borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                child: Container(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                  decoration: AppSurface.card(context),
                  child: Row(children: [

                    Container(
                      height: 40, width: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Theme.of(context).primaryColor.withValues(alpha: 0.10),
                      ),
                      child: Icon(
                        e.orderId != null ? Symbols.receipt_long : Symbols.restaurant,
                        size: 20, color: Theme.of(context).primaryColor,
                      ),
                    ),
                    const SizedBox(width: Dimensions.paddingSizeDefault),

                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                        Text(e.title, style: robotoBold.copyWith(fontSize: Dimensions.fontSizeSmall),
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 2),
                        Text(
                          TimeOfDay.fromDateTime(e.time).format(context),
                          style: robotoRegular.copyWith(
                            fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).hintColor,
                          ),
                        ),
                      ]),
                    ),

                    Text('${e.calories} kcal', style: robotoBold.copyWith(
                      fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).primaryColor,
                    )),
                  ]),
                ),
              ),
            )).toList()),
          ],
        );
      }),

      floatingActionButton: GetBuilder<NutritionController>(builder: (controller) {
        if (!controller.hasGoal) return const SizedBox();
        return FloatingActionButton.extended(
          onPressed: () => Get.bottomSheet(
            const CalorieEntrySheet(), backgroundColor: Colors.transparent, isScrollControlled: true,
          ),
          backgroundColor: Theme.of(context).primaryColor,
          icon: const Icon(Symbols.add, color: Colors.white),
          label: Text('add'.tr, style: robotoBold.copyWith(color: Colors.white)),
        );
      }),
    );
  }

  static void _editGoal(BuildContext context, NutritionController controller) {
    Get.bottomSheet(
      _GoalSheet(initial: controller.goal),
      backgroundColor: Colors.transparent, isScrollControlled: true,
    );
  }
}

class _Stat extends StatelessWidget {
  final String label;
  final String value;
  final bool accent;
  const _Stat({required this.label, required this.value, this.accent = false});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
      Text(label, style: robotoRegular.copyWith(
        fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).hintColor,
      )),
      Text(value, style: robotoBold.copyWith(
        fontSize: Dimensions.fontSizeDefault,
        color: accent ? Theme.of(context).primaryColor : Theme.of(context).textTheme.bodyLarge!.color,
      )),
    ]);
  }
}

/// Shown until a goal exists — the feature has nothing to display without one.
class _GoalEmptyState extends StatelessWidget {
  const _GoalEmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(Dimensions.paddingSizeExtraLarge),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [

          Container(
            height: 104, width: 104,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Theme.of(context).primaryColor.withValues(alpha: 0.08),
            ),
            child: Icon(Symbols.local_fire_department, size: 46,
                color: Theme.of(context).primaryColor.withValues(alpha: 0.85)),
          ),
          const SizedBox(height: Dimensions.paddingSizeLarge),

          Text('set_a_daily_goal'.tr, style: displaySemiBold.copyWith(fontSize: Dimensions.fontSizeExtraLarge),
              textAlign: TextAlign.center),
          const SizedBox(height: Dimensions.paddingSizeSmall),

          Text(
            'track_what_you_eat_against_a_target'.tr,
            style: robotoRegular.copyWith(color: Theme.of(context).hintColor),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: Dimensions.paddingSizeOverLarge),

          SizedBox(
            width: 220,
            child: CustomButtonWidget(
              buttonText: 'set_goal'.tr,
              onPressed: () => Get.bottomSheet(
                const _GoalSheet(), backgroundColor: Colors.transparent, isScrollControlled: true,
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

class _GoalSheet extends StatefulWidget {
  final int? initial;
  const _GoalSheet({this.initial});

  @override
  State<_GoalSheet> createState() => _GoalSheetState();
}

class _GoalSheetState extends State<_GoalSheet> {
  late final TextEditingController _field =
      TextEditingController(text: widget.initial?.toString() ?? '');
  String? _error;

  /// Common targets, so most people never type a number.
  static const List<int> _presets = [1500, 1800, 2000, 2200, 2500];

  @override
  void dispose() {
    _field.dispose();
    super.dispose();
  }

  void _submit() {
    final int? value = int.tryParse(_field.text.trim());
    if (value == null || value < 500 || value > 10000) {
      setState(() => _error = 'enter_a_goal_between_500_and_10000'.tr);
      return;
    }
    Get.find<NutritionController>().setGoal(value);
    Get.back();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(Dimensions.radiusExtraLarge)),
        ),
        padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
        child: SafeArea(
          top: false,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [

            Text('daily_calorie_goal'.tr, style: displaySemiBold.copyWith(fontSize: Dimensions.fontSizeExtraLarge)),
            const SizedBox(height: Dimensions.paddingSizeLarge),

            Wrap(spacing: Dimensions.paddingSizeSmall, runSpacing: Dimensions.paddingSizeSmall, children:
              _presets.map((p) {
                final bool selected = _field.text.trim() == p.toString();
                return InkWell(
                  onTap: () => setState(() { _field.text = p.toString(); _error = null; }),
                  borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault, vertical: 8),
                    decoration: BoxDecoration(
                      color: selected ? Theme.of(context).primaryColor
                          : Theme.of(context).primaryColor.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                    ),
                    child: Text('$p', style: robotoMedium.copyWith(
                      fontSize: Dimensions.fontSizeSmall,
                      color: selected ? Colors.white : Theme.of(context).primaryColor,
                    )),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            TextField(
              controller: _field,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              onChanged: (_) => setState(() => _error = null),
              onSubmitted: (_) => _submit(),
              decoration: InputDecoration(
                labelText: 'or_enter_your_own'.tr,
                suffixText: 'kcal',
                errorText: _error,
                filled: true,
                fillColor: Theme.of(context).colorScheme.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: Dimensions.paddingSizeLarge),

            CustomButtonWidget(buttonText: 'save'.tr, onPressed: _submit),
          ]),
        ),
      ),
    );
  }
}
