import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:countasty/util/styles.dart';

/// Progress ring for the daily calorie goal.
///
/// Drawn with a painter rather than a stacked CircularProgressIndicator so the
/// track and the arc share one geometry and the cap stays rounded at 0%.
class CalorieRingWidget extends StatelessWidget {
  final double progress;
  final int remaining;
  final bool isOver;
  final double size;
  final double stroke;
  final Widget? child;

  const CalorieRingWidget({
    super.key,
    required this.progress,
    required this.remaining,
    required this.isOver,
    this.size = 104,
    this.stroke = 10,
    this.child,
  });

  /// Replaces the number/label centre — used by the compact app-bar variant.
  // ignore: prefer_final_fields

  @override
  Widget build(BuildContext context) {
    final Color accent = isOver ? Theme.of(context).colorScheme.error : Theme.of(context).primaryColor;

    return SizedBox(
      height: size,
      width: size,
      child: TweenAnimationBuilder<double>(
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeOutCubic,
        tween: Tween<double>(begin: 0, end: progress),
        builder: (context, value, _) {
          return CustomPaint(
            painter: _RingPainter(
              progress: value,
              accent: accent,
              track: Theme.of(context).primaryColor.withValues(alpha: 0.12),
              stroke: stroke,
            ),
            child: Center(
              child: child ?? Column(mainAxisSize: MainAxisSize.min, children: [
                Text(
                  remaining.abs().toString(),
                  style: displaySemiBold.copyWith(fontSize: size * 0.24, height: 1, color: accent),
                ),
                const SizedBox(height: 2),
                Text(
                  isOver ? 'over'.tr : 'left'.tr,
                  style: robotoRegular.copyWith(
                    fontSize: size * 0.11, color: Theme.of(context).hintColor,
                  ),
                ),
              ]),
            ),
          );
        },
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double progress;
  final Color accent;
  final Color track;
  final double stroke;

  _RingPainter({required this.progress, required this.accent, required this.track, required this.stroke});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - stroke) / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);

    final trackPaint = Paint()
      ..color = track
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;

    final arcPaint = Paint()
      ..color = accent
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(center, radius, trackPaint);
    if (progress > 0) {
      // Start at 12 o'clock and sweep clockwise.
      canvas.drawArc(rect, -math.pi / 2, 2 * math.pi * progress, false, arcPaint);
    }
  }

  @override
  bool shouldRepaint(_RingPainter old) =>
      old.progress != progress || old.accent != accent || old.track != track;
}
