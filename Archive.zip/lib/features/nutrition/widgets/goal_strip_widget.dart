import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:countasty/features/nutrition/controllers/nutrition_controller.dart';
import 'package:countasty/features/nutrition/widgets/calorie_entry_sheet.dart';
import 'package:countasty/features/nutrition/widgets/calorie_ring_widget.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';

/// Today's calorie budget, shown on home.
///
/// Renders nothing until a goal exists, so home is unchanged for anyone who
/// hasn't opted into tracking.
class GoalStripWidget extends StatelessWidget {
  const GoalStripWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NutritionController>(builder: (nutrition) {
      if (!nutrition.hasGoal) return const SizedBox();

      final bool over = nutrition.isOverGoal;
      final Color accent = over ? Theme.of(context).colorScheme.error : Theme.of(context).primaryColor;

      return Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.paddingSizeSmall, vertical: Dimensions.paddingSizeSmall,
        ),
        child: InkWell(
          onTap: () => Get.toNamed(RouteHelper.getNutritionRoute()),
          borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
          child: Container(
            padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
            decoration: AppSurface.card(context),
            child: Row(children: [

              CalorieRingWidget(
                progress: nutrition.progress,
                remaining: nutrition.remaining,
                isOver: over,
                size: 54, stroke: 5,
                child: Icon(Symbols.local_fire_department, size: 22, color: accent),
              ),
              const SizedBox(width: Dimensions.paddingSizeDefault),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      over
                          ? '${nutrition.remaining.abs()} ${'kcal_over_today'.tr}'
                          : '${nutrition.remaining} ${'kcal_left_today'.tr}',
                      style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault, color: accent),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${nutrition.consumed} ${'of'.tr} ${nutrition.goal} ${'eaten'.tr.toLowerCase()}',
                      style: robotoRegular.copyWith(
                        fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).hintColor,
                      ),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),

              /// Log without leaving home.
              InkWell(
                onTap: () => Get.bottomSheet(
                  const CalorieEntrySheet(),
                  backgroundColor: Colors.transparent, isScrollControlled: true,
                ),
                borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: Dimensions.paddingSizeDefault, vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                    boxShadow: AppShadows.glow(Theme.of(context).primaryColor, opacity: 0.28),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Symbols.add, size: 17, color: Colors.white),
                    const SizedBox(width: 4),
                    Text('log'.tr, style: robotoBold.copyWith(
                      fontSize: Dimensions.fontSizeExtraSmall, color: Colors.white,
                    )),
                  ]),
                ),
              ),
            ]),
          ),
        ),
      );
    });
  }
}
