import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:countasty/common/widgets/custom_button_widget.dart';
import 'package:countasty/features/nutrition/controllers/nutrition_controller.dart';
import 'package:countasty/features/nutrition/domain/models/calorie_entry_model.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';

/// Add or edit one intake entry.
///
/// Doubles as the "confirm what you ate" prompt after an order, which is why
/// the title and calories can both be pre-filled.
class CalorieEntrySheet extends StatefulWidget {
  final CalorieEntry? entry;
  final String? presetTitle;
  final int? presetCalories;
  final int? productId;
  final int? orderId;

  const CalorieEntrySheet({
    super.key, this.entry, this.presetTitle, this.presetCalories, this.productId, this.orderId,
  });

  @override
  State<CalorieEntrySheet> createState() => _CalorieEntrySheetState();
}

class _CalorieEntrySheetState extends State<CalorieEntrySheet> {
  late final TextEditingController _title =
      TextEditingController(text: widget.entry?.title ?? widget.presetTitle ?? '');
  late final TextEditingController _calories = TextEditingController(
      text: (widget.entry?.calories ?? widget.presetCalories)?.toString() ?? '');

  String? _error;

  @override
  void dispose() {
    _title.dispose();
    _calories.dispose();
    super.dispose();
  }

  void _submit() {
    final int? kcal = int.tryParse(_calories.text.trim());
    if (kcal == null || kcal <= 0) {
      setState(() => _error = 'enter_calories_greater_than_zero'.tr);
      return;
    }

    final controller = Get.find<NutritionController>();
    if (widget.entry != null) {
      controller.updateEntry(widget.entry!.id, title: _title.text, calories: kcal);
    } else {
      controller.addEntry(
        title: _title.text, calories: kcal,
        productId: widget.productId, orderId: widget.orderId,
      );
    }
    Get.back();
  }

  @override
  Widget build(BuildContext context) {
    final bool isEdit = widget.entry != null;

    // No viewInsets padding here: the modal bottom sheet route already lifts
    // itself clear of the keyboard, and adding it again subtracted the inset
    // twice — pushing the sheet a full keyboard-height up so its top clipped
    // through the status bar and the Add button fell off the bottom.
    // End-aligned + Flexible so it hugs the keyboard and scrolls when the
    // remaining space is shorter than the fields.
    return Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.end, children: [
        Flexible(
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(Dimensions.radiusExtraLarge)),
            ),
            padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
            child: SafeArea(
              top: false,
              child: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [

            Text(
              isEdit ? 'edit_entry'.tr : 'add_to_today'.tr,
              style: displaySemiBold.copyWith(fontSize: Dimensions.fontSizeExtraLarge),
            ),
            const SizedBox(height: Dimensions.paddingSizeLarge),

            TextField(
              controller: _title,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                labelText: 'what_did_you_eat'.tr,
                filled: true,
                fillColor: Theme.of(context).colorScheme.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            TextField(
              controller: _calories,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              autofocus: !isEdit && widget.presetCalories == null,
              onSubmitted: (_) => _submit(),
              decoration: InputDecoration(
                labelText: 'calories'.tr,
                suffixText: 'kcal',
                errorText: _error,
                filled: true,
                fillColor: Theme.of(context).colorScheme.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: Dimensions.paddingSizeLarge),

            Row(children: [
              isEdit ? Expanded(
                child: CustomButtonWidget(
                  buttonText: 'delete'.tr,
                  transparent: true,
                  color: Theme.of(context).colorScheme.error,
                  textColor: Theme.of(context).colorScheme.error,
                  onPressed: () {
                    Get.find<NutritionController>().removeEntry(widget.entry!.id);
                    Get.back();
                  },
                ),
              ) : const SizedBox(),
              SizedBox(width: isEdit ? Dimensions.paddingSizeSmall : 0),

              Expanded(
                child: CustomButtonWidget(
                  buttonText: isEdit ? 'save'.tr : 'add'.tr,
                  onPressed: _submit,
                ),
              ),
            ]),
                ]),
              ),
            ),
          ),
        ),
    ]);
  }
}
