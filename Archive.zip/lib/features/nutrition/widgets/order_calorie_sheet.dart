import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:countasty/common/widgets/custom_button_widget.dart';
import 'package:countasty/features/nutrition/controllers/nutrition_controller.dart';
import 'package:countasty/features/order/domain/models/order_details_model.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';

/// Offered once a delivered order is opened: confirm what you actually ate.
///
/// Fires on delivery rather than at checkout — ordering isn't eating, and a
/// cancelled order should never land in the day's total. Every line is
/// editable, and remembered values pre-fill so a repeat order is one tap.
class OrderCalorieSheet extends StatefulWidget {
  final int orderId;
  final List<OrderDetailsModel> items;

  const OrderCalorieSheet({super.key, required this.orderId, required this.items});

  @override
  State<OrderCalorieSheet> createState() => _OrderCalorieSheetState();
}

class _OrderCalorieSheetState extends State<OrderCalorieSheet> {
  late final List<TextEditingController> _fields;

  @override
  void initState() {
    super.initState();
    final nutrition = Get.find<NutritionController>();
    _fields = widget.items.map((item) {
      final remembered = nutrition.rememberedCaloriesFor(item.foodId);
      return TextEditingController(text: remembered?.toString() ?? '');
    }).toList();
  }

  @override
  void dispose() {
    for (final c in _fields) {
      c.dispose();
    }
    super.dispose();
  }

  int get _total {
    int sum = 0;
    for (int i = 0; i < _fields.length; i++) {
      final value = int.tryParse(_fields[i].text.trim()) ?? 0;
      sum += value * (widget.items[i].quantity ?? 1);
    }
    return sum;
  }

  void _submit() {
    final entries = <({String title, int calories, int? productId})>[];
    for (int i = 0; i < widget.items.length; i++) {
      final per = int.tryParse(_fields[i].text.trim()) ?? 0;
      if (per <= 0) continue;
      final qty = widget.items[i].quantity ?? 1;
      entries.add((
        title: widget.items[i].foodDetails?.name ?? 'meal'.tr,
        calories: per * qty,
        productId: widget.items[i].foodId,
      ));
    }
    Get.find<NutritionController>().addOrderEntries(widget.orderId, entries);
    Get.back();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.85),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(Dimensions.radiusExtraLarge)),
        ),
        padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
        child: SafeArea(
          top: false,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [

            Row(children: [
              Container(
                height: 40, width: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Theme.of(context).primaryColor.withValues(alpha: 0.10),
                ),
                child: Icon(Symbols.local_fire_department, size: 20, color: Theme.of(context).primaryColor),
              ),
              const SizedBox(width: Dimensions.paddingSizeDefault),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text('add_this_order_to_today'.tr,
                      style: displaySemiBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
                  Text('adjust_anything_that_looks_off'.tr,
                      style: robotoRegular.copyWith(
                        fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).hintColor,
                      )),
                ]),
              ),
            ]),
            const SizedBox(height: Dimensions.paddingSizeLarge),

            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: widget.items.length,
                separatorBuilder: (_, __) => const SizedBox(height: Dimensions.paddingSizeSmall),
                itemBuilder: (context, i) {
                  final item = widget.items[i];
                  final qty = item.quantity ?? 1;

                  return Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                        Text(item.foodDetails?.name ?? '',
                            style: robotoBold.copyWith(fontSize: Dimensions.fontSizeSmall),
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        qty > 1 ? Text('x$qty', style: robotoRegular.copyWith(
                          fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).hintColor,
                        )) : const SizedBox(),
                      ]),
                    ),
                    const SizedBox(width: Dimensions.paddingSizeSmall),

                    SizedBox(
                      width: 110,
                      child: TextField(
                        controller: _fields[i],
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.end,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        onChanged: (_) => setState(() {}),
                        decoration: InputDecoration(
                          isDense: true,
                          hintText: '0',
                          suffixText: 'kcal',
                          filled: true,
                          fillColor: Theme.of(context).colorScheme.surface,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: Dimensions.paddingSizeSmall, vertical: 10,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                  ]);
                },
              ),
            ),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('total'.tr, style: robotoRegular.copyWith(color: Theme.of(context).hintColor)),
              Text('$_total kcal', style: robotoBold.copyWith(
                fontSize: Dimensions.fontSizeLarge, color: Theme.of(context).primaryColor,
              )),
            ]),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            Row(children: [
              Expanded(
                child: CustomButtonWidget(
                  buttonText: 'not_now'.tr,
                  transparent: true,
                  textColor: Theme.of(context).hintColor,
                  onPressed: () {
                    Get.find<NutritionController>().skipOrder(widget.orderId);
                    Get.back();
                  },
                ),
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),
              Expanded(
                child: CustomButtonWidget(
                  buttonText: 'add_to_today'.tr,
                  onPressed: _total > 0 ? _submit : null,
                ),
              ),
            ]),
          ]),
        ),
      ),
    );
  }
}
