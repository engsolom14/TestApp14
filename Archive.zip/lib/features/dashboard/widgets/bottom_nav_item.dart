import 'package:flutter/material.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/common/widgets/logo_mark.dart';

/// Countasty tab bar item, styled for the floating glass bar.
///
/// Selection is a solid accent capsule behind a white glyph. Selection is still
/// carried by more than colour alone — the capsule, the icon fill and the icon
/// weight all change together — so the active tab reads without relying on hue.
class BottomNavItem extends StatelessWidget {
  final IconData iconData;

  /// Outline variant shown when the tab is not selected. Falls back to
  /// [iconData] when a pair isn't supplied.
  final IconData? inactiveIconData;
  final Function? onTap;
  final bool isSelected;

  /// Draw the Countasty logo silhouette instead of [iconData]. Used for the
  /// favourites tab so it matches the favourite toggles elsewhere.
  final bool useLogoMark;

  const BottomNavItem({
    super.key,
    required this.iconData,
    this.inactiveIconData,
    this.onTap,
    this.isSelected = false,
    this.useLogoMark = false,
  });

  @override
  Widget build(BuildContext context) {
    final Color activeColor = Theme.of(context).primaryColor;
    final Color inactiveColor = Theme.of(context).hintColor;

    return Expanded(
      child: InkWell(
        onTap: onTap as void Function()?,
        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
        splashColor: activeColor.withValues(alpha: 0.08),
        highlightColor: Colors.transparent,
        child: Center(
          child: TweenAnimationBuilder<double>(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutCubic,
            tween: Tween<double>(begin: 0, end: isSelected ? 1 : 0),
            builder: (context, t, _) {
              return Container(
                height: 44,
                padding: EdgeInsets.symmetric(horizontal: 14 + (8 * t)),
                decoration: BoxDecoration(
                  color: Color.lerp(Colors.transparent, activeColor, t),
                  borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                  boxShadow: t > 0
                      ? [
                          BoxShadow(
                            color: activeColor.withValues(alpha: 0.34 * t),
                            blurRadius: 16,
                            spreadRadius: -6,
                            offset: const Offset(0, 6),
                          ),
                        ]
                      : null,
                ),

                /// Material Symbols is a variable font, so selection animates
                /// the icon from outline to filled rather than cross-fading two
                /// different glyphs. The logo mark takes the same 0→1 fill, so
                /// the branded tab animates identically to the rest.
                child: useLogoMark
                    ? SizedBox(
                        // Sized to 24 like its neighbours, but the mark inside
                        // is drawn smaller: the logo asset is trimmed flush to
                        // its bounds while Material Symbols glyphs carry
                        // optical padding, so an equal box makes the logo read
                        // noticeably heavier than the icons beside it.
                        width: 24,
                        height: 24,
                        child: Center(
                          child: LogoMark(
                            fill: t,
                            size: 19,
                            outlineColor: inactiveColor,
                            fillColor: Colors.white,
                          ),
                        ),
                      )
                    : Icon(
                        inactiveIconData != null && !isSelected ? inactiveIconData! : iconData,
                        fill: t,
                        weight: 400 + (200 * t),
                        color: Color.lerp(inactiveColor, Colors.white, t),
                        size: 24,
                      ),
              );
            },
          ),
        ),
      ),
    );
  }
}
