import 'dart:async';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/services.dart';
import 'package:countasty/features/cart/screens/cart_screen.dart';
import 'package:countasty/features/checkout/widgets/congratulation_dialogue.dart';
import 'package:countasty/features/dashboard/widgets/registration_success_bottom_sheet.dart';
import 'package:countasty/features/home/screens/home_screen.dart';
import 'package:countasty/features/menu/screens/menu_screen.dart';
import 'package:countasty/features/order/controllers/order_controller.dart';
import 'package:countasty/features/order/screens/order_screen.dart';
import 'package:countasty/features/splash/controllers/splash_controller.dart';
// Used by the commented-out running-order sheet in the body below.
// import 'package:countasty/features/order/domain/models/order_model.dart';
import 'package:countasty/features/auth/controllers/auth_controller.dart';
import 'package:countasty/features/dashboard/controllers/dashboard_controller.dart';
import 'package:countasty/features/dashboard/widgets/address_bottom_sheet.dart';
import 'package:countasty/features/dashboard/widgets/bottom_nav_item.dart';
// Used by the commented-out running-order sheet in the body below.
// import 'package:countasty/features/dashboard/widgets/running_order_view_widget.dart';
import 'package:countasty/features/favourite/screens/favourite_screen.dart';
import 'package:countasty/features/loyalty/controllers/loyalty_controller.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/common/widgets/cart_widget.dart';
import 'package:countasty/common/widgets/custom_dialog_widget.dart';
import 'package:expandable_bottom_sheet/expandable_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:get/get.dart';

class DashboardScreen extends StatefulWidget {
  final int pageIndex;
  final bool fromSplash;
  const DashboardScreen({super.key, required this.pageIndex, this.fromSplash = false});

  @override
  DashboardScreenState createState() => DashboardScreenState();
}

class DashboardScreenState extends State<DashboardScreen> {
  PageController? _pageController;
  int _pageIndex = 0;
  late List<Widget> _screens;
  final GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey();
  bool _canExit = GetPlatform.isWeb ? true : false;
  late bool _isLogin;
  bool active = false;

  @override
  void initState() {
    super.initState();

    _isLogin = Get.find<AuthController>().isLoggedIn();

    _showRegistrationSuccessBottomSheet();

    if(_isLogin){
      if(Get.find<SplashController>().configModel!.loyaltyPointStatus == 1 && Get.find<LoyaltyController>().getEarningPint().isNotEmpty && !ResponsiveHelper.isDesktop(Get.context)){
        Future.delayed(const Duration(seconds: 1), () => showAnimatedDialog(Get.context!, const CongratulationDialogue()));
      }
      _suggestAddressBottomSheet();
      Get.find<OrderController>().getRunningOrders(1, notify: false);
    }

    _pageIndex = widget.pageIndex;

    _pageController = PageController(initialPage: widget.pageIndex);

    _screens = [
      const HomeScreen(),
      const FavouriteScreen(),
      const CartScreen(fromNav: true),
      const OrderScreen(),
      const MenuScreen()
    ];

    Future.delayed(const Duration(seconds: 1), () {
      setState(() {});
    });

  }

  _showRegistrationSuccessBottomSheet() {
    bool canShowBottomSheet = Get.find<DashboardController>().getRegistrationSuccessfulSharedPref();
    if(canShowBottomSheet) {
      Future.delayed(const Duration(seconds: 1), () {
        ResponsiveHelper.isDesktop(Get.context) ? Get.dialog(const Dialog(child: RegistrationSuccessBottomSheet())).then((value) {
          Get.find<DashboardController>().saveRegistrationSuccessfulSharedPref(false);
          Get.find<DashboardController>().saveIsRestaurantRegistrationSharedPref(false);
          setState(() {});
        }) : showModalBottomSheet(
          context: Get.context!, isScrollControlled: true, backgroundColor: Colors.transparent,
          builder: (con) => const RegistrationSuccessBottomSheet(),
        ).then((value) {
          Get.find<DashboardController>().saveRegistrationSuccessfulSharedPref(false);
          Get.find<DashboardController>().saveIsRestaurantRegistrationSharedPref(false);
          setState(() {});
        });
      });
    }
  }

  Future<void> _suggestAddressBottomSheet() async {
    active = await Get.find<DashboardController>().checkLocationActive();
    if(widget.fromSplash && Get.find<DashboardController>().showLocationSuggestion && active){
      Future.delayed(const Duration(seconds: 1), () {
        showModalBottomSheet(
          context: Get.context!, isScrollControlled: true, backgroundColor: Colors.transparent,
          builder: (con) => const AddressBottomSheet(),
        ).then((value) {
          Get.find<DashboardController>().hideSuggestedLocation();
          setState(() {});
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: Navigator.canPop(context),
      onPopInvokedWithResult: (didPop, result) async{
        debugPrint('$_canExit');
        if (_pageIndex != 0) {
          _setPage(0);
        } else {
          if(_canExit) {
            if (GetPlatform.isAndroid) {
              SystemNavigator.pop();
            } else if (GetPlatform.isIOS) {
              exit(0);
            }
          }
          if(!ResponsiveHelper.isDesktop(context)) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('back_press_again_to_exit'.tr, style: const TextStyle(color: Colors.white)),
              behavior: SnackBarBehavior.floating,
              backgroundColor: Colors.green,
              duration: const Duration(seconds: 2),
              margin: const EdgeInsets.all(Dimensions.paddingSizeSmall),
            ));
          }
          _canExit = true;

          Timer(const Duration(seconds: 2), () {
            _canExit = false;
          });
        }
      },
      child: Scaffold(
        key: _scaffoldKey,
        // Content flows beneath the floating glass bar.
        extendBody: true,


        body: GetBuilder<OrderController>(
          builder: (orderController) {
            // Only needed by the commented-out running-order sheet below.
            // List<OrderModel> runningOrder = orderController.runningOrderList != null ? orderController.runningOrderList! : [];
            // List<OrderModel> reversOrder =  List.from(runningOrder.reversed);
            return ExpandableBottomSheet(
              // The glass bar lives inside the page stack, not in the Scaffold's
              // bottomNavigationBar slot. As a sibling of the body it composited
              // into its own layer with nothing behind it, so BackdropFilter had
              // nothing to sample and the bar rendered flat white.
              background: Stack(children: [
                PageView.builder(
                  controller: _pageController,
                  itemCount: _screens.length,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return _screens[index];
                  },
                ),

                Positioned(
                  left: 0, right: 0, bottom: 0,
                  // The running-order sheet no longer covers the bar — active
                  // orders surface as a card in the home feed instead.
                  child: ResponsiveHelper.isDesktop(context) ? const SizedBox() : _glassNavBar(context),
                ),
              ]),
              // Running-order sheet is retired in favour of the home-feed card,
              // so no room is reserved at the bottom any more.
              persistentContentHeight: 0,

              onIsContractedCallback: () {
                if(!orderController.showOneOrder) {
                  orderController.showOrders();
                }
              },
              onIsExtendedCallback: () {
                if(orderController.showOneOrder) {
                  orderController.showOrders();
                }
              },

              enableToggle: true,

              // Replaced by ActiveOrderCardWidget in the home feed. Kept here,
              // commented, in case the pinned sheet is ever wanted back.
              // expandableContent: (ResponsiveHelper.isDesktop(context) || !_isLogin || orderController.runningOrderList == null
              //     || orderController.runningOrderList!.isEmpty || !orderController.showBottomSheet) ? const SizedBox()
              //     : Dismissible(
              //       key: UniqueKey(),
              //       onDismissed: (direction) {
              //         if(orderController.showBottomSheet){
              //           orderController.showRunningOrders();
              //         }
              //       },
              //       child: RunningOrderViewWidget(reversOrder: reversOrder, onMoreClick: () {
              //         if(orderController.showBottomSheet){
              //           orderController.showRunningOrders();
              //         }
              //         _setPage(3);
              //       }),
              // ),
              expandableContent: const SizedBox(),

            );
          }
        ),
      ),
    );
  }

  void _setPage(int pageIndex) {
    setState(() {
      _pageController!.jumpToPage(pageIndex);
      _pageIndex = pageIndex;
    });
  }

  /// Floating Liquid-Glass tab bar. Rendered inside the page stack so the
  /// Floating Liquid-Glass tab bar with the cart beside it on one baseline:
  /// the pill carries the four tabs, the circle is its own control rather than
  /// a fifth item inside the bar.
  Widget _glassNavBar(BuildContext context) {
    if (MediaQuery.of(context).viewInsets.bottom != 0) return const SizedBox();

    const double barHeight = 62;

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          Dimensions.paddingSizeDefault, 0, Dimensions.paddingSizeDefault, Dimensions.paddingSizeSmall,
        ),
        child: Row(children: [

          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(Dimensions.radiusPill),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 28, sigmaY: 28),
                child: Container(
                  height: barHeight,
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor.withValues(alpha: 0.55),
                    borderRadius: BorderRadius.circular(Dimensions.radiusPill),
                    // Same hairline the search field and cards use, rather than
                    // a hardcoded 55% white — on the dark ground that read as a
                    // bright outline around the bar instead of an edge.
                    border: Border.all(color: AppSurface.hairline(context), width: 1),
                    boxShadow: AppShadows.raised,
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeExtraSmall),
                  child: Row(children: [
                    BottomNavItem(iconData: Symbols.home_rounded, isSelected: _pageIndex == 0, onTap: () => _setPage(0)),
                    BottomNavItem(iconData: Symbols.favorite_rounded, useLogoMark: true, isSelected: _pageIndex == 1, onTap: () => _setPage(1)),
                    BottomNavItem(iconData: Symbols.shopping_bag_rounded, isSelected: _pageIndex == 3, onTap: () => _setPage(3)),
                    BottomNavItem(iconData: Symbols.menu_rounded, isSelected: _pageIndex == 4, onTap: () => _setPage(4)),
                  ]),
                ),
              ),
            ),
          ),
          const SizedBox(width: Dimensions.paddingSizeSmall),

          /// Cart — matched to the bar's height so both read as one row.
          InkWell(
            onTap: () => Get.toNamed(RouteHelper.getCartRoute()),
            borderRadius: BorderRadius.circular(Dimensions.radiusPill),
            child: Container(
              height: barHeight, width: barHeight,
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
                shape: BoxShape.circle,
                boxShadow: AppShadows.glow(Theme.of(context).primaryColor, opacity: 0.35),
              ),
              // The button is already filled with the accent, so the badge
              // inverts — a white disc with orange digits — instead of the
              // default orange-on-orange.
              child: Center(child: CartWidget(
                color: Colors.white, size: 26,
                badgeColor: Colors.white,
                badgeTextColor: Theme.of(context).primaryColor,
              )),
            ),
          ),
        ]),
      ),
    );
  }
}
