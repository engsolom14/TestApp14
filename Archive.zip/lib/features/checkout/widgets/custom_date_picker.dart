import 'package:countasty/features/order/controllers/order_controller.dart';
import 'package:countasty/helper/date_converter.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_snackbar_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:material_symbols_icons/symbols.dart';

class CustomDatePicker extends StatelessWidget {
  final String hint;
  final DateTimeRange? range;
  final Function(DateTimeRange range) onDatePicked;
  final bool isPause;
  const CustomDatePicker({super.key, required this.hint, required this.range, required this.onDatePicked, this.isPause = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        DateTimeRange? range = await showDateRangePicker(
          context: context, firstDate: DateTime.now(), lastDate: isPause ? DateTime.parse(Get.find<OrderController>().trackModel!.subscription!.endAt!) : DateTime.now().add(const Duration(days: 365)),
          builder: (context, child) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: ResponsiveHelper.isDesktop(context) ? 400.0 : context.width * 0.8,
                    maxHeight: ResponsiveHelper.isDesktop(context) ? context.height * 0.8 : context.height * 0.6,
                  ),
                  child: SingleChildScrollView(child: child),
                )
              ],
            );
          }
        );
        if(range != null) {
          if(range.start == range.end){
            showCustomSnackBar('start_date_and_end_date_can_not_be_same_for_subscription_order'.tr);
          }else{
            onDatePicked(range);
          }
        }
      },
      child: Container(
        height: 50,
        padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 20),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
          border: Border.all(color: Theme.of(context).primaryColor, width: 0.3),
          // boxShadow: AppShadows.card,
        ),
        child: Row(children: [
          Expanded(
            child: Text(
              range != null ? DateConverter.dateRangeToDate(range!) : hint,
              style: robotoRegular,
            ),
          ),

          Icon(Symbols.date_range_rounded, size: 24, color: range != null ? Theme.of(context).primaryColor : Theme.of(context).disabledColor),
        ]),
      ),
    );
  }
}
