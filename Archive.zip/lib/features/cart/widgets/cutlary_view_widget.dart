import 'package:countasty/features/cart/controllers/cart_controller.dart';
import 'package:countasty/features/restaurant/controllers/restaurant_controller.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_utils/get_utils.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:material_symbols_icons/symbols.dart';
class CutleryViewWidget extends StatelessWidget {
  final RestaurantController restaurantController;
  final CartController cartController;
  const CutleryViewWidget({super.key, required this.restaurantController, required this.cartController});

  @override
  Widget build(BuildContext context) {
    bool isDesktop = ResponsiveHelper.isDesktop(context);
    return (restaurantController.restaurant != null && restaurantController.restaurant!.cutlery != null && restaurantController.restaurant!.cutlery!) ? Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        border: Border.all(color: AppSurface.hairline(context), width: 1),
        boxShadow: AppShadows.card,
      ),
      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault, vertical: Dimensions.paddingSizeSmall),
      margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault, vertical: Dimensions.paddingSizeExtraSmall),
      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [

        Icon(Symbols.flatware, size: isDesktop ? 30 : 25, color: Theme.of(context).primaryColor),
        const SizedBox(width: Dimensions.paddingSizeDefault),

        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('add_cutlery'.tr, style: robotoMedium.copyWith(color: Theme.of(context).primaryColor)),
            const SizedBox(height: Dimensions.paddingSizeExtraSmall),

            Text('do_not_have_cutlery'.tr, style: robotoRegular.copyWith(color: Theme.of(context).disabledColor, fontSize: Dimensions.fontSizeSmall)),
          ]),
        ),

        Transform.scale(
          scale: 0.7,
          child: CupertinoSwitch(
            value: cartController.addCutlery,
            activeTrackColor: Theme.of(context).primaryColor,
            onChanged: (bool? value) {
              cartController.updateCutlery();
            },
            inactiveTrackColor: Theme.of(context).primaryColor.withValues(alpha: 0.2),
          ),
        )

      ]),
    ) : const SizedBox();
  }
}
