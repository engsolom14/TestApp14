import 'package:countasty/features/splash/controllers/splash_controller.dart';
import 'package:countasty/features/support/widgets/web_support_widget.dart';
import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/images.dart';
import 'package:countasty/util/styles.dart';
import 'package:countasty/common/widgets/custom_app_bar_widget.dart';
import 'package:countasty/common/widgets/custom_snackbar_widget.dart';
import 'package:countasty/common/widgets/footer_view_widget.dart';
import 'package:countasty/common/widgets/menu_drawer_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:material_symbols_icons/symbols.dart';

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});

  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  final ScrollController scrollController = ScrollController();

  Future<void> _call(String? phone) async {
    final String number = (phone ?? '').trim();
    if (number.isEmpty) return;
    if (await canLaunchUrlString('tel:$number')) {
      await launchUrlString('tel:$number', mode: LaunchMode.externalApplication);
    } else {
      showCustomSnackBar('${'can_not_launch'.tr} $number');
    }
  }

  Future<void> _email(String? email) async {
    final String address = (email ?? '').trim();
    if (address.isEmpty) return;
    final Uri uri = Uri(scheme: 'mailto', path: address);
    if (await canLaunchUrlString(uri.toString())) {
      await launchUrlString(uri.toString(), mode: LaunchMode.externalApplication);
    } else {
      showCustomSnackBar('${'can_not_launch'.tr} $address');
    }
  }

  Future<void> _map(String? address) async {
    final String query = (address ?? '').trim();
    if (query.isEmpty) return;
    final String url = 'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(query)}';
    if (await canLaunchUrlString(url)) {
      await launchUrlString(url, mode: LaunchMode.externalApplication);
    } else {
      showCustomSnackBar('${'can_not_launch'.tr} $query');
    }
  }

  @override
  Widget build(BuildContext context) {
    final config = Get.find<SplashController>().configModel;

    // Only offer a channel the config actually provides — a row that opens
    // nothing is worse than no row.
    final List<_Channel> channels = <_Channel>[
      if ((config?.phone ?? '').trim().isNotEmpty)
        _Channel(Symbols.call, 'call'.tr, config!.phone!, () => _call(config.phone)),
      if ((config?.email ?? '').trim().isNotEmpty)
        _Channel(Symbols.mail, 'email_us'.tr, config!.email!, () => _email(config.email)),
      if ((config?.address ?? '').trim().isNotEmpty)
        _Channel(Symbols.location_on, 'address'.tr, config!.address!, () => _map(config.address)),
    ];

    return Scaffold(
      appBar: CustomAppBarWidget(title: 'help_support'.tr),
      endDrawer: const MenuDrawerWidget(), endDrawerEnableOpenDragGesture: false,
      body: ResponsiveHelper.isDesktop(context)
          ? SingleChildScrollView(
              controller: scrollController,
              child: const FooterViewWidget(
                child: SizedBox(width: double.infinity, height: 650, child: WebSupportScreen()),
              ),
            )
          : SingleChildScrollView(
              controller: scrollController,
              padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeDefault),
              child: Center(child: SizedBox(width: Dimensions.webMaxWidth, child: Column(children: [

                /// Banner, matching Follow Us — the accent carries the greeting
                /// instead of a half-screen orange panel behind the content.
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                  padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                      colors: [
                        Theme.of(context).primaryColor,
                        Theme.of(context).primaryColor.withValues(alpha: 0.75),
                      ],
                    ),
                    boxShadow: AppShadows.glow(Theme.of(context).primaryColor, opacity: 0.30),
                  ),
                  child: Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(
                        'how_we_can_help_you'.tr,
                        style: displayExtraBold.copyWith(fontSize: 22, color: Colors.white),
                      ),
                      const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                      Text(
                        'hey_let_us_know_your_problem'.tr,
                        style: robotoRegular.copyWith(
                          fontSize: Dimensions.fontSizeSmall,
                          color: Colors.white.withValues(alpha: 0.9),
                        ),
                      ),
                    ])),
                    const SizedBox(width: Dimensions.paddingSizeDefault),
                    Image.asset(Images.supportImage, height: 56, width: 56, fit: BoxFit.contain),
                  ]),
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),

                /// Contact channels in one card, same list treatment as the
                /// menu and Follow Us screens.
                channels.isEmpty ? const SizedBox() : Container(
                  margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                  padding: const EdgeInsets.symmetric(
                    horizontal: Dimensions.paddingSizeLarge, vertical: Dimensions.paddingSizeExtraSmall,
                  ),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
                    border: Border.all(color: AppSurface.hairline(context), width: 1),
                    boxShadow: AppShadows.card,
                  ),
                  child: Column(children: List<Widget>.generate(channels.length, (int i) {
                    final _Channel channel = channels[i];

                    return InkWell(
                      onTap: channel.onTap,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall),
                        child: Column(children: [
                          Row(children: [

                            Container(
                              height: 38, width: 38,
                              decoration: BoxDecoration(
                                color: Theme.of(context).primaryColor.withValues(alpha: 0.12),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(channel.icon, size: 20, color: Theme.of(context).primaryColor),
                            ),
                            const SizedBox(width: Dimensions.paddingSizeDefault),

                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(
                                channel.title,
                                style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeDefault),
                              ),
                              const SizedBox(height: 2),
                              // Wraps rather than clipping — addresses are long,
                              // and the old fixed-height card cut them off.
                              Text(
                                channel.value,
                                style: robotoRegular.copyWith(
                                  fontSize: Dimensions.fontSizeSmall,
                                  color: Theme.of(context).hintColor,
                                ),
                                maxLines: 3, overflow: TextOverflow.ellipsis,
                              ),
                            ])),
                            const SizedBox(width: Dimensions.paddingSizeSmall),

                            Icon(Symbols.chevron_right, size: 20, color: Theme.of(context).hintColor),
                          ]),

                          if (i != channels.length - 1) const Divider(),
                        ]),
                      ),
                    );
                  })),
                ),

              ]))),
            ),
    );
  }
}

/// One contact route offered on the screen.
class _Channel {
  final IconData icon;
  final String title;
  final String value;
  final VoidCallback onTap;
  const _Channel(this.icon, this.title, this.value, this.onTap);
}
