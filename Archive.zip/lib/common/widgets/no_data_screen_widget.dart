import 'package:countasty/helper/responsive_helper.dart';
import 'package:countasty/helper/route_helper.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

class NoDataScreen extends StatelessWidget {
  //final bool isCart;
  final String? title;
  final bool fromAddress;
  //final bool isRestaurant;
  final bool isEmptyAddress;
  final bool isEmptyCart;
  final bool isEmptyChat;
  final bool isEmptyOrder;
  final bool isEmptyCoupon;
  final bool isEmptyFood;
  final bool isEmptyNotification;
  final bool isEmptyRestaurant;
  final bool isEmptySearchFood;
  final bool isEmptyTransaction;
  final bool isEmptyWishlist;
  const NoDataScreen({super.key, required this.title, /*this.isCart = false, this.fromAddress = false, this.isRestaurant = false,*/ this.fromAddress = false,
    this.isEmptyAddress = false, this.isEmptyCart = false, this.isEmptyChat = false, this.isEmptyOrder = false, this.isEmptyCoupon = false,
    this.isEmptyFood = false, this.isEmptyNotification = false, this.isEmptyRestaurant = false, this.isEmptySearchFood = false, this.isEmptyTransaction = false,
    this.isEmptyWishlist = false});

  @override
  Widget build(BuildContext context) {

    double height = MediaQuery.of(context).size.height;
    bool isDesktop = ResponsiveHelper.isDesktop(context);

    return Padding(
      padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
      child: Column(mainAxisAlignment: fromAddress ? MainAxisAlignment.start : MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center, children: [

        fromAddress ? SizedBox(height : height * 0.25) : SizedBox(
          height: isEmptyTransaction || isEmptyCoupon ? height * 0.15  : isDesktop ? height * 0.2 : height * 0.3,
        ),

        /// Flat symbol on a soft disc, matching the app's icon language.
        Center(
          child: Container(
            height: isDesktop ? 130 : 104,
            width: isDesktop ? 130 : 104,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Theme.of(context).primaryColor.withValues(alpha: 0.07),
            ),
            child: Icon(
              isEmptyAddress ? Symbols.location_off
                  : isEmptyCart ? Symbols.shopping_cart
                  : isEmptyChat ? Symbols.forum
                  : isEmptyOrder ? Symbols.receipt_long
                  : isEmptyCoupon ? Symbols.confirmation_number
                  : isEmptyFood ? Symbols.restaurant
                  : isEmptyNotification ? Symbols.notifications
                  : isEmptyRestaurant ? Symbols.storefront
                  : isEmptySearchFood ? Symbols.search_off
                  : isEmptyTransaction ? Symbols.account_balance_wallet
                  : isEmptyWishlist ? Symbols.favorite
                  : Symbols.restaurant,
              size: isDesktop ? 60 : 46,
              weight: 300,
              color: Theme.of(context).primaryColor.withValues(alpha: 0.85),
            ),
          ),
        ),
        SizedBox(height: fromAddress ? 10 : 10),

        Text(
          title ?? '',
          style: robotoMedium.copyWith(color: fromAddress ? Theme.of(context).textTheme.bodyMedium!.color : Theme.of(context).disabledColor),
          textAlign: TextAlign.center,
        ),
        SizedBox(height: fromAddress ? 10 : MediaQuery.of(context).size.height * 0.03),

        fromAddress ? Text(
          'please_add_your_address_for_your_better_experience'.tr,
          style: robotoRegular.copyWith(color: Theme.of(context).disabledColor),
          textAlign: TextAlign.center,
        ) : const SizedBox(),
        SizedBox(height: isEmptyAddress ? 30 : MediaQuery.of(context).size.height * 0.05),


        fromAddress ? InkWell(
          onTap: () => Get.toNamed(RouteHelper.getAddAddressRoute(false, 0)),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
              color: Theme.of(context).primaryColor,
            ),
            padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeDefault, horizontal: Dimensions.paddingSizeExtraOverLarge),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center, mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Symbols.add_circle_outline_sharp, size: 18.0, color: Theme.of(context).cardColor),
                const SizedBox(width: Dimensions.paddingSizeSmall),

                Text('add_address'.tr, style: robotoBold.copyWith(color: Theme.of(context).cardColor)),
              ],
            ),
          ),
        ) : const SizedBox(),


      ]),
    );
  }
}
