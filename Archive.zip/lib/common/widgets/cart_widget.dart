import 'package:countasty/features/cart/controllers/cart_controller.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

class CartWidget extends StatelessWidget {
  final Color? color;
  final double size;
  final bool fromRestaurant;

  /// Badge fill. Defaults to the brand accent, which is wrong wherever the
  /// icon already sits on an accent-filled surface — the dashboard's cart
  /// button, for one, where orange-on-orange left the count barely legible.
  final Color? badgeColor;

  /// Badge text and border. Defaults to the card surface.
  final Color? badgeTextColor;

  const CartWidget({
    super.key,
    required this.color,
    required this.size,
    this.fromRestaurant = false,
    this.badgeColor,
    this.badgeTextColor,
  });

  @override
  Widget build(BuildContext context) {
    // Big enough for two digits at a readable weight; the old size/2 gave a
    // 13px disc with a 7px glyph, which clipped anything past 9.
    final double badgeSize = size < 20 ? 15 : 18;

    final Color fill = badgeColor ??
        (fromRestaurant ? Theme.of(context).cardColor : Theme.of(context).primaryColor);
    final Color ink = badgeTextColor ??
        (fromRestaurant ? Theme.of(context).primaryColor : Theme.of(context).cardColor);

    return Stack(clipBehavior: Clip.none, children: [
      Icon(Symbols.shopping_cart, size: size, color: color),

      GetBuilder<CartController>(builder: (cartController) {
        final int count = cartController.cartList.length;
        if (count == 0) return const SizedBox();

        // Past two digits the disc would have to grow enough to unbalance the
        // icon, so cap the label instead.
        final String label = count > 99 ? '99+' : '$count';

        return Positioned(
          top: -6,
          right: -8,
          child: Container(
            constraints: BoxConstraints(minWidth: badgeSize, minHeight: badgeSize),
            padding: EdgeInsets.symmetric(horizontal: label.length > 1 ? 4 : 0),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: fill,
              borderRadius: BorderRadius.circular(badgeSize),
              border: Border.all(width: 1.5, color: ink),
            ),
            child: Text(
              label,
              textAlign: TextAlign.center,
              style: robotoBold.copyWith(
                fontSize: badgeSize * 0.6,
                height: 1.1,
                color: ink,
              ),
            ),
          ),
        );
      }),
    ]);
  }
}
