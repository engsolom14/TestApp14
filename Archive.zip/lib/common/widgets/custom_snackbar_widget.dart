import 'package:countasty/common/widgets/custom_toast.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

Future<void> showCustomSnackBar(String? message, {bool isError = true}) async {
  if(message != null && message.isNotEmpty) {
    String displayMessage = message;

    if (kDebugMode) {
      final frames = StackTrace.current.toString().split('\n');
      // frame 0 = showCustomSnackBar itself, frame 1 = caller
      final callerFrame = frames.length > 1 ? frames[1].trim() : '';
      final match = RegExp(r'\(([^)]+)\)$').firstMatch(callerFrame);
      final location = match != null ? match.group(1) : callerFrame;
      displayMessage = '$message\n📍 $location';
    }

    Get.closeCurrentSnackbar();
    Get.showSnackbar(GetSnackBar(
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.transparent,
      duration: const Duration(seconds: 2),
      overlayBlur: 0.0,
      margin: const EdgeInsets.only(bottom: 40, left: 20, right: 20),
      messageText: CustomToast(text: displayMessage, isError: isError),
      borderRadius: 10,
      padding: const EdgeInsets.all(0),
      snackStyle: SnackStyle.FLOATING,
      isDismissible: true,
      forwardAnimationCurve: Curves.fastLinearToSlowEaseIn,
      reverseAnimationCurve: Curves.fastEaseInToSlowEaseOut,
      animationDuration: const Duration(milliseconds: 500),
    ));

  }
}