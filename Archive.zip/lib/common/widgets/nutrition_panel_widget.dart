import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:countasty/common/models/nutrition_facts.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';

/// Nutrition for a single product: an energy-split ring plus the macro
/// breakdown, or a row of tags when the data is too thin to draw a ring.
///
/// Renders nothing at all when there's no usable data — most of the catalogue
/// carries no nutrition, and an empty section is worse than no section.
class NutritionPanelWidget extends StatelessWidget {
  final NutritionFacts facts;

  /// Compact mode drops the ring and shows only tags. Used where a 104pt ring
  /// won't fit, e.g. product cards in a list.
  final bool compact;

  const NutritionPanelWidget({
    super.key,
    required this.facts,
    this.compact = false,
  });

  static Color proteinColor(BuildContext context) =>
      Theme.of(context).colorScheme.tertiary;
  static Color carbsColor(BuildContext context) => Theme.of(context).primaryColor;
  static Color fatColor(BuildContext context) =>
      Theme.of(context).hintColor.withValues(alpha: 0.85);

  static Color colorOf(BuildContext context, NutritionMacro macro) {
    switch (macro) {
      case NutritionMacro.protein:
        return proteinColor(context);
      case NutritionMacro.carbs:
        return carbsColor(context);
      case NutritionMacro.fat:
        return fatColor(context);
    }
  }

  static String labelOf(NutritionMacro macro) {
    switch (macro) {
      case NutritionMacro.protein:
        return 'protein'.tr;
      case NutritionMacro.carbs:
        return 'carbs'.tr;
      case NutritionMacro.fat:
        return 'fat'.tr;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!facts.isTrustworthy) return const SizedBox();

    final bool drawRing = facts.canDrawRing && !compact;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
          Text('nutrition_details'.tr, style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
          const SizedBox(width: Dimensions.paddingSizeExtraSmall),
          Text('per_serving'.tr,
              style: robotoRegular.copyWith(
                fontSize: Dimensions.fontSizeExtraSmall,
                color: Theme.of(context).hintColor,
              )),
        ]),
        const SizedBox(height: Dimensions.paddingSizeSmall),
        if (drawRing) _RingAndMacros(facts: facts) else _Tags(facts: facts),
        const SizedBox(height: Dimensions.paddingSizeLarge),
      ],
    );
  }
}

class _RingAndMacros extends StatelessWidget {
  final NutritionFacts facts;
  const _RingAndMacros({required this.facts});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      _EnergyRing(facts: facts),
      const SizedBox(width: Dimensions.paddingSizeDefault),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: NutritionMacro.values.map((NutritionMacro macro) {
            final double? grams = facts.gramsOf(macro);
            if (grams == null) return const SizedBox();
            final int percent = (facts.shareOf(macro) * 100).round();
            return Padding(
              padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeExtraSmall),
              child: Row(children: [
                Container(
                  width: 9,
                  height: 9,
                  decoration: BoxDecoration(
                    color: NutritionPanelWidget.colorOf(context, macro),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: Dimensions.paddingSizeSmall),
                Expanded(
                  child: Text(
                    NutritionPanelWidget.labelOf(macro),
                    style: robotoRegular.copyWith(
                      fontSize: Dimensions.fontSizeSmall,
                      color: Theme.of(context).textTheme.bodyLarge!.color?.withValues(alpha: 0.85),
                    ),
                  ),
                ),
                Text('${_trim(grams)} ${'g'.tr}',
                    style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall)),
                const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                Text('$percent%',
                    style: robotoRegular.copyWith(
                      fontSize: Dimensions.fontSizeExtraSmall,
                      color: Theme.of(context).hintColor,
                    )),
              ]),
            );
          }).toList(),
        ),
      ),
    ]);
  }

  static String _trim(double v) =>
      v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(1);
}

/// One donut split into three arcs by share of energy.
///
/// Animates once on first build. Deliberately not keyed to the product's
/// quantity or variant: this widget rebuilds on every "+" tap, and a ring that
/// re-runs its sweep each time reads as a toy.
class _EnergyRing extends StatefulWidget {
  final NutritionFacts facts;
  const _EnergyRing({required this.facts});

  @override
  State<_EnergyRing> createState() => _EnergyRingState();
}

class _EnergyRingState extends State<_EnergyRing> with SingleTickerProviderStateMixin {
  static const double _size = 104;
  static const double _stroke = 13;

  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 600),
  );
  late final Animation<double> _sweep =
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);

  @override
  void initState() {
    super.initState();
    _controller.value = 1;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final bool reduceMotion = MediaQuery.maybeDisableAnimationsOf(context) ?? false;
      if (reduceMotion) return;
      _controller
        ..value = 0
        ..forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final int? kcal = widget.facts.displayCalories;

    return SizedBox(
      width: _size,
      height: _size,
      child: AnimatedBuilder(
        animation: _sweep,
        builder: (BuildContext context, Widget? child) {
          return CustomPaint(
            painter: _SplitRingPainter(
              progress: _sweep.value,
              shares: <double>[
                widget.facts.shareOf(NutritionMacro.protein),
                widget.facts.shareOf(NutritionMacro.carbs),
                widget.facts.shareOf(NutritionMacro.fat),
              ],
              colors: <Color>[
                NutritionPanelWidget.proteinColor(context),
                NutritionPanelWidget.carbsColor(context),
                NutritionPanelWidget.fatColor(context),
              ],
              track: Theme.of(context).primaryColor.withValues(alpha: 0.12),
              stroke: _stroke,
            ),
            child: child,
          );
        },
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(
              kcal?.toString() ?? '--',
              style: displaySemiBold.copyWith(fontSize: 25, height: 1),
            ),
            const SizedBox(height: 2),
            Text(
              'kcal'.tr,
              style: robotoMedium.copyWith(
                fontSize: Dimensions.fontSizeExtraSmall,
                color: Theme.of(context).hintColor,
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class _SplitRingPainter extends CustomPainter {
  final double progress;
  final List<double> shares;
  final List<Color> colors;
  final Color track;
  final double stroke;

  /// Gap between segments, in radians, so adjacent arcs read as separate.
  static const double _gap = 0.045;

  _SplitRingPainter({
    required this.progress,
    required this.shares,
    required this.colors,
    required this.track,
    required this.stroke,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, size.height / 2);
    final double radius = (size.width - stroke) / 2;
    final Rect rect = Rect.fromCircle(center: center, radius: radius);

    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = track
        ..style = PaintingStyle.stroke
        ..strokeWidth = stroke,
    );

    // Start at 12 o'clock, sweep clockwise — same convention as CalorieRingWidget.
    double start = -math.pi / 2;
    for (int i = 0; i < shares.length; i++) {
      final double full = 2 * math.pi * shares[i];
      if (full <= 0) continue;
      final double swept = full * progress;
      // Only inset a gap once the arc is long enough to survive it.
      final double inset = full > _gap * 2 ? _gap : 0;
      final double drawn = math.max(0, swept - inset);
      if (drawn > 0) {
        canvas.drawArc(
          rect,
          start,
          drawn,
          false,
          Paint()
            ..color = colors[i]
            ..style = PaintingStyle.stroke
            ..strokeWidth = stroke
            ..strokeCap = StrokeCap.butt,
        );
      }
      start += full;
    }
  }

  @override
  bool shouldRepaint(_SplitRingPainter old) =>
      old.progress != progress ||
      old.track != track ||
      !listEquals(old.shares, shares) ||
      !listEquals(old.colors, colors);

  static bool listEquals<T>(List<T> a, List<T> b) {
    if (a.length != b.length) return false;
    for (int i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }
}

/// Fallback for partial or compact data: chips, no ring.
class _Tags extends StatelessWidget {
  final NutritionFacts facts;
  const _Tags({required this.facts});

  @override
  Widget build(BuildContext context) {
    final List<Widget> chips = <Widget>[];
    final int? kcal = facts.displayCalories;

    if (kcal != null) {
      chips.add(_chip(
        context,
        text: '$kcal ${'kcal'.tr}',
        dot: null,
        background: Theme.of(context).primaryColor.withValues(alpha: 0.12),
      ));
    }
    for (final NutritionMacro macro in NutritionMacro.values) {
      final double? grams = facts.gramsOf(macro);
      if (grams == null) continue;
      chips.add(_chip(
        context,
        text: '${NutritionPanelWidget.labelOf(macro)} ${_RingAndMacros._trim(grams)} ${'g'.tr}',
        dot: NutritionPanelWidget.colorOf(context, macro),
        background: Theme.of(context).cardColor,
      ));
    }
    if (chips.isEmpty) return const SizedBox();

    return Wrap(
      spacing: Dimensions.paddingSizeSmall,
      runSpacing: Dimensions.paddingSizeSmall,
      children: chips,
    );
  }

  Widget _chip(BuildContext context,
      {required String text, required Color? dot, required Color background}) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: Dimensions.paddingSizeSmall,
        vertical: Dimensions.paddingSizeExtraSmall + 1,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
        border: Border.all(color: Theme.of(context).disabledColor.withValues(alpha: 0.25)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (dot != null) ...[
          Container(width: 8, height: 8, decoration: BoxDecoration(color: dot, shape: BoxShape.circle)),
          const SizedBox(width: Dimensions.paddingSizeExtraSmall + 1),
        ],
        Text(text, style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall)),
      ]),
    );
  }
}

/// One-line nutrition strip for product cards in lists.
///
/// The detail sheet gets the ring; a 104pt ring will not fit in a list row, and
/// a row of full-size chips pushes the price out of the card. This is the same
/// information at card scale: a filled energy pill, then one tinted pill per
/// macro. Each pill is tinted with its own macro colour so the three read as a
/// set at a glance rather than as three identical grey chips.
///
/// Renders nothing unless the data passes the same trust guards as the ring.
class NutritionStripWidget extends StatelessWidget {
  final NutritionFacts facts;

  /// Cards are narrow, so the strip stays on one line and clips rather than
  /// wrapping into a second row that would change every card's height.
  final bool singleLine;

  const NutritionStripWidget({
    super.key,
    required this.facts,
    this.singleLine = true,
  });

  @override
  Widget build(BuildContext context) {
    if (!facts.isTrustworthy) return const SizedBox.shrink();

    final List<Widget> pills = <Widget>[];
    final int? kcal = facts.displayCalories;

    if (kcal != null) {
      pills.add(_pill(
        context,
        text: '$kcal ${'kcal'.tr}',
        color: Theme.of(context).primaryColor,
        emphasised: true,
      ));
    }

    for (final NutritionMacro macro in NutritionMacro.values) {
      final double? grams = facts.gramsOf(macro);
      if (grams == null) continue;
      pills.add(_pill(
        context,
        text: '${_initial(macro)} ${_trim(grams)}${'g'.tr}',
        color: NutritionPanelWidget.colorOf(context, macro),
        emphasised: false,
      ));
    }

    if (pills.isEmpty) return const SizedBox.shrink();

    final List<Widget> spaced = <Widget>[];
    for (int i = 0; i < pills.length; i++) {
      if (i > 0) spaced.add(const SizedBox(width: 4));
      spaced.add(pills[i]);
    }

    final Widget row = Row(mainAxisSize: MainAxisSize.min, children: spaced);
    if (!singleLine) {
      return Wrap(spacing: 4, runSpacing: 4, children: pills);
    }
    // Clip instead of overflowing on very narrow cards.
    return ClipRect(
      child: Align(
        alignment: AlignmentDirectional.centerStart,
        widthFactor: 1,
        child: row,
      ),
    );
  }

  static String _initial(NutritionMacro macro) {
    switch (macro) {
      case NutritionMacro.protein:
        return 'P';
      case NutritionMacro.carbs:
        return 'C';
      case NutritionMacro.fat:
        return 'F';
    }
  }

  static String _trim(double v) =>
      v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(1);

  Widget _pill(BuildContext context,
      {required String text, required Color color, required bool emphasised}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: emphasised ? 0.14 : 0.10),
        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
      ),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.clip,
        style: robotoMedium.copyWith(
          fontSize: Dimensions.fontSizeExtraSmall,
          height: 1.25,
          color: color,
          fontWeight: emphasised ? FontWeight.w700 : FontWeight.w500,
        ),
      ),
    );
  }
}
