import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:countasty/util/images.dart';

/// Clips its child to the Countasty logo silhouette instead of a circle.
///
/// The logo PNG's alpha channel *is* the silhouette, so it can be used
/// directly as a mask: `BlendMode.dstIn` keeps the child only where the mask
/// is opaque. The decoded mask is cached statically — every avatar in the app
/// shares one decode rather than paying for its own.
class LogoMaskWidget extends StatefulWidget {
  final double size;
  final Widget child;

  /// Shown while the mask decodes, and if decoding ever fails. Falls back to
  /// a circle so an avatar is never simply missing.
  final bool circleFallback;

  const LogoMaskWidget({
    super.key,
    required this.size,
    required this.child,
    this.circleFallback = true,
  });

  @override
  State<LogoMaskWidget> createState() => _LogoMaskWidgetState();
}

class _LogoMaskWidgetState extends State<LogoMaskWidget> {
  static ui.Image? _mask;
  static Future<ui.Image?>? _pending;

  @override
  void initState() {
    super.initState();
    if (_mask == null) {
      _pending ??= _decodeMask();
      _pending!.then((img) {
        if (img != null && mounted) setState(() {});
      });
    }
  }

  static Future<ui.Image?> _decodeMask() async {
    try {
      final data = await rootBundle.load(Images.logoMask);
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final frame = await codec.getNextFrame();
      _mask = frame.image;
      return frame.image;
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final ui.Image? mask = _mask;

    if (mask == null) {
      return SizedBox(
        width: widget.size,
        height: widget.size,
        child: widget.circleFallback ? ClipOval(child: widget.child) : widget.child,
      );
    }

    // Scale the mask bitmap to the requested box.
    final double scale = widget.size / mask.width;

    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: ShaderMask(
        blendMode: BlendMode.dstIn,
        shaderCallback: (Rect bounds) => ImageShader(
          mask,
          TileMode.clamp,
          TileMode.clamp,
          Matrix4.diagonal3Values(scale, scale, 1).storage,
          filterQuality: FilterQuality.high,
        ),
        child: SizedBox(
          width: widget.size,
          height: widget.size,
          child: FittedBox(fit: BoxFit.cover, child: widget.child),
        ),
      ),
    );
  }
}
