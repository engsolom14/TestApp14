import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

// Countasty primary button — pill shape, soft brand-colored glow,
// rust overlay on press (mirrors .btn / .btn:hover on countasty.com).
class CustomButtonWidget extends StatelessWidget {
  final Function? onPressed;
  final String buttonText;
  final bool transparent;
  final EdgeInsets? margin;
  final double? height;
  final double? width;
  final double? fontSize;
  final double radius;
  final IconData? icon;
  final Color? color;
  final Color? textColor;
  final bool isLoading;
  final bool isBold;
  const CustomButtonWidget({super.key, this.onPressed, required this.buttonText, this.transparent = false, this.margin, this.width, this.height,
    this.fontSize, this.radius = Dimensions.radiusPill, this.icon, this.color, this.textColor, this.isLoading = false, this.isBold = true});

  static const Color _rust = Color(0xFFB5481A);

  @override
  Widget build(BuildContext context) {
    final Color background = onPressed == null ? Theme.of(context).disabledColor.withValues(alpha: 0.6) : transparent
        ? Colors.transparent : color ?? Theme.of(context).primaryColor;

    final ButtonStyle flatButtonStyle = TextButton.styleFrom(
      backgroundColor: background,
      minimumSize: Size(width != null ? width! : Dimensions.webMaxWidth, height != null ? height! : 52),
      padding: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius)),
    ).copyWith(
      overlayColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.pressed)) {
          return transparent ? _rust.withValues(alpha: 0.08) : _rust.withValues(alpha: 0.35);
        }
        return null;
      }),
    );

    return Center(child: SizedBox(width: width ?? Dimensions.webMaxWidth, child: Padding(
      padding: margin == null ? const EdgeInsets.all(0) : margin!,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          boxShadow: (transparent || onPressed == null) ? null : [
            BoxShadow(
              color: (color ?? Theme.of(context).primaryColor).withValues(alpha: 0.45),
              blurRadius: 24,
              spreadRadius: -12,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: TextButton(
          onPressed: isLoading ? null : onPressed as void Function()?,
          style: flatButtonStyle,
          child: isLoading ? Center(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const SizedBox(
              height: 15, width: 15,
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                strokeWidth: 2,
              ),
            ),
            const SizedBox(width: Dimensions.paddingSizeSmall),

            Text('loading'.tr, style: robotoMedium.copyWith(color: Colors.white)),
          ]),
          ) : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            icon != null ? Padding(
              padding: const EdgeInsets.only(right: Dimensions.paddingSizeExtraSmall),
              child: Icon(icon, color: transparent ? Theme.of(context).primaryColor : Colors.white),
            ) : const SizedBox(),
            Text(buttonText, textAlign: TextAlign.center,  style: isBold ? robotoBold.copyWith(
                color: textColor ?? (transparent ? Theme.of(context).primaryColor : Colors.white),
                fontSize: fontSize ?? Dimensions.fontSizeLarge,
              ) : robotoRegular.copyWith(
                color: textColor ?? (transparent ? Theme.of(context).primaryColor : Colors.white),
                fontSize: fontSize ?? Dimensions.fontSizeLarge,
              )
            ),
          ]),
        ),
      ),
    )));
  }
}
