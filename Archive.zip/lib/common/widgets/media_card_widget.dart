import 'package:flutter/material.dart';
import 'package:countasty/common/widgets/custom_image_widget.dart';
import 'package:countasty/util/app_shadows.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:countasty/util/styles.dart';

/// The app's card treatment: the photo fills the card and the text sits on it
/// over a gradient scrim, rather than in a caption block underneath.
///
/// One implementation so restaurant cards, food cards and campaign cards stay
/// identical — the scrim ramp in particular has to match everywhere or the
/// cards read as different components.
class MediaCard extends StatelessWidget {
  final String image;
  final String title;

  /// Translucent tags under the title. Only [maxChips] render; the rest
  /// collapse into a "+N" chip.
  final List<String> chips;
  final int maxChips;

  /// Sits at the end of the chip row — delivery time, price, etc.
  final Widget? trailing;

  /// Floated in the top-right corner: favourite, usually.
  final Widget? topRight;

  /// Anything else stacked over the image (discount tag, unavailable veil).
  final List<Widget> overlays;

  final double? height;
  final double? width;
  final double titleSize;
  final bool isRestaurant;
  final bool isFood;

  const MediaCard({
    super.key,
    required this.image,
    required this.title,
    this.chips = const [],
    this.maxChips = 2,
    this.trailing,
    this.topRight,
    this.overlays = const [],
    this.height,
    this.width,
    this.titleSize = 0,
    this.isRestaurant = false,
    this.isFood = false,
  });

  @override
  Widget build(BuildContext context) {
    final double fontSize = titleSize == 0 ? Dimensions.fontSizeLarge : titleSize;

    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        color: Theme.of(context).cardColor,
        border: Border.all(color: AppSurface.hairline(context), width: 1),
        boxShadow: AppShadows.card,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        child: Stack(fit: StackFit.expand, children: [

          CustomImageWidget(image: image, fit: BoxFit.cover, isRestaurant: isRestaurant, isFood: isFood),

          /// Keeps white type legible over any photo.
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: Container(
              height: (height ?? 200) * 0.7,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter, end: Alignment.topCenter,
                  colors: [
                    const Color(0xFF120C07).withValues(alpha: 0.88),
                    const Color(0xFF120C07).withValues(alpha: 0.55),
                    const Color(0xFF120C07).withValues(alpha: 0.0),
                  ],
                  stops: const [0.0, 0.45, 1.0],
                ),
              ),
            ),
          ),

          ...overlays,

          Positioned(
            left: Dimensions.paddingSizeDefault,
            right: Dimensions.paddingSizeDefault,
            bottom: Dimensions.paddingSizeDefault,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [

              Text(
                title,
                style: robotoBold.copyWith(fontSize: fontSize, color: Colors.white),
                maxLines: 2, overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: chips.isEmpty && trailing == null ? 0 : Dimensions.paddingSizeSmall),

              (chips.isEmpty && trailing == null) ? const SizedBox() : Row(children: [
                Expanded(child: _ChipRow(labels: chips, maxChips: maxChips)),
                trailing != null
                    ? Padding(
                        padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
                        child: trailing!,
                      )
                    : const SizedBox(),
              ]),
            ]),
          ),

          topRight != null ? Positioned(
            top: Dimensions.paddingSizeSmall, right: Dimensions.paddingSizeSmall,
            child: topRight!,
          ) : const SizedBox(),
        ]),
      ),
    );
  }
}

class _ChipRow extends StatelessWidget {
  final List<String> labels;
  final int maxChips;
  const _ChipRow({required this.labels, required this.maxChips});

  @override
  Widget build(BuildContext context) {
    final List<String> clean = labels.where((l) => l.trim().isNotEmpty).toList();
    if (clean.isEmpty) return const SizedBox();

    final List<String> shown = clean.take(maxChips).toList();
    final int extra = clean.length - shown.length;

    return Row(mainAxisSize: MainAxisSize.min, children: [
      ...shown.map((l) => Flexible(
        child: Padding(
          padding: const EdgeInsets.only(right: 6),
          child: MediaCardChip(label: l),
        ),
      )),
      extra > 0 ? MediaCardChip(label: '+$extra') : const SizedBox(),
    ]);
  }
}

/// Translucent tag used on top of card imagery.
class MediaCardChip extends StatelessWidget {
  final String label;
  const MediaCardChip({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.22),
        borderRadius: BorderRadius.circular(Dimensions.radiusPill),
        border: Border.all(color: Colors.white.withValues(alpha: 0.28)),
      ),
      child: Text(
        label, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Colors.white),
      ),
    );
  }
}

/// Icon + label pair for a card's trailing slot (delivery time, price…).
class MediaCardMeta extends StatelessWidget {
  final IconData icon;
  final String label;
  const MediaCardMeta({super.key, required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 15, color: Colors.white),
      const SizedBox(width: 4),
      Text(label, style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Colors.white)),
    ]);
  }
}
