import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:countasty/common/models/product_model.dart';
import 'package:countasty/common/models/restaurant_model.dart';
import 'package:countasty/common/widgets/custom_snackbar_widget.dart';
import 'package:countasty/features/favourite/controllers/favourite_controller.dart';
import 'package:countasty/helper/auth_helper.dart';
import 'package:countasty/common/widgets/logo_like_button.dart';

class CustomFavouriteWidget extends StatefulWidget {
  final Restaurant? restaurant;
  final Product? product;
  final bool isRestaurant;
  final bool isWished;
  final double? size;
  final int? restaurantId;

  /// Pass [Colors.white] when the button floats on a photo. Left null on card
  /// surfaces so the mark falls back to the muted ink and stays visible.
  final Color? outlineColor;

  const CustomFavouriteWidget({super.key, this.restaurant, this.product, this.isRestaurant = false, required this.isWished, this.size = 25, this.restaurantId, this.outlineColor});

  @override
  State<CustomFavouriteWidget> createState() => _CustomFavouriteWidgetState();
}

class _CustomFavouriteWidgetState extends State<CustomFavouriteWidget> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;


  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
      value: 1.0,
    );
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // The logo mark carries its own fill animation, so the old scale-pulse
    // wrapper would double up on it.
    return LogoLikeButton(
      isWished: widget.isWished,
      size: widget.size ?? 25,
      outlineColor: widget.outlineColor,
      onTap: () {
        if (Get.find<FavouriteController>().isDisable) return;
        if(AuthHelper.isLoggedIn()) {
          _decideWished(widget.isWished, Get.find<FavouriteController>());
        }else {
          showCustomSnackBar('you_are_not_logged_in'.tr);
        }
      },
    );
  }

  _decideWished(bool isWished, FavouriteController favouriteController) {
    if(widget.isRestaurant) {
      isWished ? favouriteController.removeFromFavouriteList(widget.restaurantId ?? widget.restaurant?.id, true)
          : favouriteController.addToFavouriteList(null, widget.restaurantId ?? widget.restaurant?.id, true);
    }else {
      isWished ? favouriteController.removeFromFavouriteList(widget.product?.id, false)
          : favouriteController.addToFavouriteList(widget.product, null, false);
    }
  }
}
