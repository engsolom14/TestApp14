import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:countasty/common/widgets/custom_asset_image_widget.dart';
import 'package:countasty/util/app_constants.dart';
import 'package:countasty/util/images.dart';
import 'package:flutter/material.dart';

class CustomImageWidget extends StatefulWidget {
  final String image;
  final double? height;
  final double? width;
  final BoxFit? fit;
  final String placeholder;
  final Color? imageColor;
  final bool isRestaurant;
  final bool isFood;
  final Color? color;
  const CustomImageWidget({super.key, required this.image, this.height, this.width, this.fit = BoxFit.cover, this.placeholder = '', this.imageColor,
    this.isRestaurant = false, this.isFood = false, this.color});

  @override
  State<CustomImageWidget> createState() => _CustomImageWidgetState();
}

class _CustomImageWidgetState extends State<CustomImageWidget> {
  bool _isHovered = false;

  // Hover zoom only exists on pointer devices; on touch it just costs a
  // transform layer per image, so mobile skips the wrapper entirely.
  static final bool _supportsHover = kIsWeb ||
      defaultTargetPlatform == TargetPlatform.macOS ||
      defaultTargetPlatform == TargetPlatform.windows ||
      defaultTargetPlatform == TargetPlatform.linux;

  @override
  Widget build(BuildContext context) {
    // Decode at display size instead of full network resolution.
    final double pixelRatio = MediaQuery.of(context).devicePixelRatio;
    final int? memCacheWidth = widget.width != null && widget.width!.isFinite ? (widget.width! * pixelRatio).round() : null;
    final int? memCacheHeight = (memCacheWidth == null && widget.height != null && widget.height!.isFinite) ? (widget.height! * pixelRatio).round() : null;

    final Widget image = CachedNetworkImage(
      color: widget.color,
      imageUrl: kIsWeb ? '${AppConstants.baseUrl}/image-proxy?url=${widget.image}' : widget.image, height: widget.height, width: widget.width, fit: widget.fit,
      memCacheWidth: memCacheWidth,
      memCacheHeight: memCacheHeight,
      placeholder: (context, url) => CustomAssetImageWidget(widget.placeholder.isNotEmpty ? widget.placeholder : widget.isRestaurant ? Images.restaurantPlaceholder : widget.isFood ? Images.foodPlaceholder : Images.placeholderPng,
          height: widget.height, width: widget.width, fit: widget.fit, color: widget.imageColor),
      errorWidget: (context, url, error) => CustomAssetImageWidget(widget.placeholder.isNotEmpty ? widget.placeholder : widget.isRestaurant ? Images.restaurantPlaceholder : widget.isFood ? Images.foodPlaceholder : Images.placeholderPng,
          height: widget.height, width: widget.width, fit: widget.fit, color: widget.imageColor),
    );

    if (!_supportsHover) {
      return image;
    }

    return MouseRegion(
      onEnter: (_) {
        setState(() {
          _isHovered = true;
        });
      },
      onExit: (_) {
        setState(() {
          _isHovered = false;
        });
      },
      child: AnimatedScale(
        scale: _isHovered ? 1.2 : 1.0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        child: image,
      ),
    );
  }
}
