import 'package:countasty/util/dimensions.dart';
import 'package:flutter/material.dart';
import 'package:countasty/util/app_shadows.dart';

class CustomLoaderWidget extends StatelessWidget {
  const CustomLoaderWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Container(
      height: 90, width: 90,
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
        border: Border.all(color: AppSurface.hairline(context), width: 1),
        boxShadow: AppShadows.card,
      ),
      alignment: Alignment.center,
      child: const SizedBox(
        height: 32, width: 32,
        child: CircularProgressIndicator(strokeWidth: 3, strokeCap: StrokeCap.round),
      ),
    ));
  }
}
