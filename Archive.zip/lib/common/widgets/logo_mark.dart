import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:countasty/util/images.dart';

/// The Countasty logo silhouette, drawn anywhere from outline to solid fill.
///
/// Cut from the same asset the profile avatar masks with, so the mark reads as
/// one shape language across the app. [fill] follows the same 0→1 contract as
/// the Material Symbols variable font, which lets it drop into places that
/// already animate an icon's fill — the bottom nav, the favourite toggle —
/// without either caller inventing its own transition.
class LogoMark extends StatefulWidget {
  /// 0 = outline only, 1 = solid. Values between are a partial fill.
  final double fill;

  final double size;

  /// Colour at [fill] 0. The mark lerps toward [fillColor] as it fills.
  final Color outlineColor;
  final Color fillColor;

  const LogoMark({
    super.key,
    required this.fill,
    required this.outlineColor,
    required this.fillColor,
    this.size = 24,
  });

  @override
  State<LogoMark> createState() => _LogoMarkState();
}

class _LogoMarkState extends State<LogoMark> {
  /// One decode shared by every mark in the app.
  static ui.Image? _mask;
  static Future<ui.Image?>? _pending;

  @override
  void initState() {
    super.initState();
    if (_mask == null) {
      _pending ??= _decode();
      _pending!.then((ui.Image? img) {
        if (img != null && mounted) setState(() {});
      });
    }
  }

  static Future<ui.Image?> _decode() async {
    try {
      final data = await rootBundle.load(Images.logoMask);
      final ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final ui.FrameInfo frame = await codec.getNextFrame();
      _mask = frame.image;
      return frame.image;
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_mask == null) {
      return SizedBox(width: widget.size, height: widget.size);
    }
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: CustomPaint(
        painter: LogoMarkPainter(
          mask: _mask!,
          fill: widget.fill,
          outlineColor: widget.outlineColor,
          fillColor: widget.fillColor,
        ),
      ),
    );
  }
}

/// Paints the silhouette as an outline, a solid fill, or any point between.
///
/// The asset's alpha channel *is* the silhouette. Stamping it and then punching
/// a slightly inset copy back out with [BlendMode.dstOut] leaves a rim; driving
/// that inset to zero turns the rim into a solid mark.
class LogoMarkPainter extends CustomPainter {
  final ui.Image mask;
  final double fill;
  final Color outlineColor;
  final Color fillColor;

  LogoMarkPainter({
    required this.mask,
    required this.fill,
    required this.outlineColor,
    required this.fillColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Rect dst = Offset.zero & size;
    final Rect src = Rect.fromLTWH(0, 0, mask.width.toDouble(), mask.height.toDouble());

    final double stroke = size.shortestSide * 0.13;
    final Color color = Color.lerp(outlineColor, fillColor, fill)!;

    canvas.saveLayer(dst, Paint());

    canvas.drawImageRect(
      mask,
      src,
      dst,
      Paint()
        ..colorFilter = ColorFilter.mode(color, BlendMode.srcIn)
        ..filterQuality = FilterQuality.high,
    );

    final double inset = stroke * (1 - fill);
    if (inset > 0.01) {
      canvas.drawImageRect(
        mask,
        src,
        dst.deflate(inset),
        Paint()
          ..blendMode = BlendMode.dstOut
          ..filterQuality = FilterQuality.high,
      );
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant LogoMarkPainter old) =>
      old.fill != fill ||
      old.outlineColor != outlineColor ||
      old.fillColor != fillColor ||
      old.mask != mask;
}
