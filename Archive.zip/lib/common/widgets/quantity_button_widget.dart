import 'package:flutter/cupertino.dart';
import 'package:countasty/util/dimensions.dart';
import 'package:flutter/material.dart';
import 'package:material_symbols_icons/symbols.dart';

class QuantityButton extends StatelessWidget {
  final bool isIncrement;
  final Function? onTap;
  final bool showRemoveIcon;
  final Color? color;
  const QuantityButton({super.key, required this.isIncrement, required this.onTap, this.showRemoveIcon = false, this.color});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap as void Function()?,
      customBorder: const CircleBorder(),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOutCubic,
        height: 26, width: 26,
        margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(width: 1, color: showRemoveIcon ? Colors.transparent : isIncrement ? Theme.of(context).primaryColor : Theme.of(context).disabledColor.withValues(alpha: 0.5)),
          color: showRemoveIcon ? Theme.of(context).cardColor : isIncrement ? color ?? Theme.of(context).primaryColor : Theme.of(context).secondaryHeaderColor,
          boxShadow: (isIncrement && !showRemoveIcon) ? [BoxShadow(
            color: (color ?? Theme.of(context).primaryColor).withValues(alpha: 0.35),
            blurRadius: 12, spreadRadius: -4, offset: const Offset(0, 4),
          )] : null,
        ),
        alignment: Alignment.center,
        child: Icon(
          showRemoveIcon ? CupertinoIcons.trash : isIncrement ? Symbols.add_rounded : Symbols.remove_rounded,
          size: 18,
          color: showRemoveIcon ? Theme.of(context).colorScheme.error : isIncrement ? Colors.white : Theme.of(context).primaryColor,
        ),
      ),
    );
  }
}
