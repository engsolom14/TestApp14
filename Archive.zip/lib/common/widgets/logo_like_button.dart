import 'package:flutter/material.dart';
import 'package:countasty/common/widgets/logo_mark.dart';

/// Favourite toggle drawn as the Countasty logo mark.
///
/// Outline when not favourited, solid brand orange when favourited. The fill
/// sweeps in from the edge rather than crossfading between two icons — see
/// [LogoMark], which the bottom nav shares.
///
/// Motion: the fill resolves in ~280ms and the glow behind it in ~420ms. Both
/// collapse to an instant swap when the platform asks for reduced motion.
class LogoLikeButton extends StatefulWidget {
  final bool isWished;
  final VoidCallback onTap;

  /// Outline colour in the unfavourited state. Pass [Colors.white] for buttons
  /// floated on a photo; leave null on card and list surfaces, where it falls
  /// back to the muted ink so the mark doesn't disappear into a light card.
  final Color? outlineColor;

  final double size;

  const LogoLikeButton({
    super.key,
    required this.isWished,
    required this.onTap,
    this.outlineColor,
    this.size = 22,
  });

  @override
  State<LogoLikeButton> createState() => _LogoLikeButtonState();
}

class _LogoLikeButtonState extends State<LogoLikeButton> with TickerProviderStateMixin {
  late final AnimationController _fill = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 280),
    value: widget.isWished ? 1 : 0,
  );

  /// One-shot bloom on favouriting only. Unfavouriting is not a moment worth
  /// celebrating, so it gets the fill running backwards and nothing else.
  late final AnimationController _burst = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 420),
  );

  bool get _reducedMotion => MediaQuery.maybeOf(context)?.disableAnimations ?? false;

  @override
  void didUpdateWidget(covariant LogoLikeButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.isWished == widget.isWished) return;

    if (_reducedMotion) {
      _fill.value = widget.isWished ? 1 : 0;
      return;
    }

    if (widget.isWished) {
      _fill.forward();
      _burst.forward(from: 0);
    } else {
      _fill.reverse();
    }
  }

  @override
  void dispose() {
    _fill.dispose();
    _burst.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double box = widget.size * 1.8;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      child: SizedBox(
        width: box,
        height: box,
        child: AnimatedBuilder(
          animation: Listenable.merge([_fill, _burst]),
          builder: (BuildContext context, _) {
            final double t = Curves.easeOutCubic.transform(_fill.value);
            final double burst = _burst.value;

            return Stack(alignment: Alignment.center, children: [

              // Light spilling off the mark as it fills. Never persistent.
              if (burst > 0 && burst < 1)
                Opacity(
                  opacity: (1 - burst) * 0.5,
                  child: Container(
                    width: widget.size * (0.8 + burst),
                    height: widget.size * (0.8 + burst),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Theme.of(context).primaryColor.withValues(alpha: 0.4),
                    ),
                  ),
                ),

              // A little scale as it lands, settling back as the glow clears.
              Transform.scale(
                scale: 1 + (0.12 * t * (1 - burst)),
                child: LogoMark(
                  fill: t,
                  size: widget.size,
                  outlineColor: widget.outlineColor ?? Theme.of(context).disabledColor,
                  fillColor: Theme.of(context).primaryColor,
                ),
              ),
            ]);
          },
        ),
      ),
    );
  }
}
