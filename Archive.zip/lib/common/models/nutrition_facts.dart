/// Structured nutrition for one product.
///
/// The catalogue stores nutrition as free-text labels on a shared many-to-many
/// table, in whatever shape the admin typed: `Calories(318)`, `Calories (853)`,
/// `595 Calories:`, `29g Prot`, `prot(39g)`, `Fat: 20`. This parses that mess
/// into numbers and refuses anything it can't trust.
///
/// When the backend grows real numeric columns, only this file changes.
/// [NutritionFacts.fromValues] is the seam the API will use.
class NutritionFacts {
  /// Kilocalories per serving, as stated by the restaurant.
  final int? calories;
  final double? proteinG;
  final double? carbsG;
  final double? fatG;

  const NutritionFacts({this.calories, this.proteinG, this.carbsG, this.fatG});

  /// Energy contributed by each macro, in kcal (Atwater factors).
  double get _proteinKcal => (proteinG ?? 0) * 4;
  double get _carbsKcal => (carbsG ?? 0) * 4;
  double get _fatKcal => (fatG ?? 0) * 9;

  /// Energy implied by the macros. Used both for the ring and as a sanity
  /// check against [calories].
  double get derivedKcal => _proteinKcal + _carbsKcal + _fatKcal;

  bool get hasAllMacros => proteinG != null && carbsG != null && fatG != null;

  /// Every present value sits inside a plausible range for one serving.
  ///
  /// Catches `Fat: 20` / `Carb: 100` / `protine: 200` — which parses cleanly
  /// but describes a 1380 kcal "snack" with more protein than a whole chicken.
  bool get _macrosPlausible {
    if (proteinG != null && (proteinG! < 0 || proteinG! > 150)) return false;
    if (carbsG != null && (carbsG! < 0 || carbsG! > 400)) return false;
    if (fatG != null && (fatG! < 0 || fatG! > 200)) return false;
    if (calories != null && (calories! < 0 || calories! > 5000)) return false;
    return true;
  }

  /// Stated calories and macro-derived energy roughly agree. Only meaningful
  /// when both are present.
  bool get _energyAgrees {
    if (calories == null || calories! <= 0 || !hasAllMacros) return true;
    final double ratio = derivedKcal / calories!;
    return ratio >= 0.6 && ratio <= 1.5;
  }

  /// Whether this should be shown to a customer at all. Wrong nutrition on
  /// food is a liability, so anything doubtful renders nothing.
  bool get isTrustworthy => isNotEmpty && _macrosPlausible && _energyAgrees;

  /// True when there's enough trustworthy data to draw the split ring.
  ///
  /// Requires a *stated* calorie figure: the number in the middle of the ring
  /// is the headline, and inferring it from macros we already half-doubt is
  /// exactly the failure this guard exists to prevent.
  bool get canDrawRing =>
      isTrustworthy &&
      hasAllMacros &&
      derivedKcal > 0 &&
      calories != null &&
      calories! > 0;

  /// Anything worth rendering at all.
  bool get isEmpty =>
      calories == null && proteinG == null && carbsG == null && fatG == null;
  bool get isNotEmpty => !isEmpty;

  /// Calories to display. Only ever the restaurant's own figure — never
  /// derived, so the app never invents a calorie count.
  int? get displayCalories =>
      (calories != null && calories! > 0) ? calories : null;

  /// Each macro's share of the meal's energy, 0..1. Shares sum to 1.
  double shareOf(NutritionMacro macro) {
    final double total = derivedKcal;
    if (total <= 0) return 0;
    switch (macro) {
      case NutritionMacro.protein:
        return _proteinKcal / total;
      case NutritionMacro.carbs:
        return _carbsKcal / total;
      case NutritionMacro.fat:
        return _fatKcal / total;
    }
  }

  double? gramsOf(NutritionMacro macro) {
    switch (macro) {
      case NutritionMacro.protein:
        return proteinG;
      case NutritionMacro.carbs:
        return carbsG;
      case NutritionMacro.fat:
        return fatG;
    }
  }

  /// Preferred entry point. Merges the backend's structured `nutrition_facts`
  /// with the legacy free-text labels, **field by field**: a value typed in the
  /// portal wins, and any field still blank falls back to the parsed label.
  ///
  /// Merging per field rather than all-or-nothing matters. Restaurants fill
  /// these in one box at a time, and an earlier version treated any structured
  /// value as authoritative for the whole record — so typing just the calories
  /// blanked the macros and hid a ring that had been rendering fine from the
  /// labels. Partial entry must never remove information the app already had.
  factory NutritionFacts.resolve({
    Map<String, dynamic>? facts,
    List<String>? labels,
  }) {
    final NutritionFacts structured =
        facts != null ? NutritionFacts.fromJson(facts) : const NutritionFacts();
    final NutritionFacts parsed = NutritionFacts.parse(labels);

    return NutritionFacts(
      calories: structured.calories ?? parsed.calories,
      proteinG: structured.proteinG ?? parsed.proteinG,
      carbsG: structured.carbsG ?? parsed.carbsG,
      fatG: structured.fatG ?? parsed.fatG,
    );
  }

  factory NutritionFacts.fromJson(Map<String, dynamic> json) => NutritionFacts(
        calories: _toInt(json['calories']),
        proteinG: _toDouble(json['protein_g']),
        carbsG: _toDouble(json['carbs_g']),
        fatG: _toDouble(json['fat_g']),
      );

  static int? _toInt(dynamic v) =>
      v == null ? null : (v is num ? v.round() : int.tryParse(v.toString()));

  static double? _toDouble(dynamic v) =>
      v == null ? null : (v is num ? v.toDouble() : double.tryParse(v.toString()));

  /// The seam for a future numeric API.
  factory NutritionFacts.fromValues({
    int? calories,
    double? protein,
    double? carbs,
    double? fat,
  }) =>
      NutritionFacts(
        calories: calories,
        proteinG: protein,
        carbsG: carbs,
        fatG: fat,
      );

  /// Parses the product's `nutritions_name` list.
  ///
  /// Kind comes from a keyword, value from the first number in the string, so
  /// word order doesn't matter: `29g Prot` and `Prot(15g)` read identically.
  /// Later duplicates of the same kind are ignored rather than summed — the
  /// labels are shared rows, and a repeat means bad data, not a second helping.
  factory NutritionFacts.parse(List<String>? labels) {
    if (labels == null || labels.isEmpty) return const NutritionFacts();

    int? calories;
    double? protein;
    double? carbs;
    double? fat;

    for (final String raw in labels) {
      final String label = raw.toLowerCase();
      final double? value = _firstNumber(raw);
      if (value == null) continue;

      // Order matters: "carb" must be tested before "cal" would ever match it,
      // and protein's "pro" must not swallow anything else.
      if (label.contains('cal')) {
        calories ??= value.round();
      } else if (label.contains('prot')) {
        protein ??= value;
      } else if (label.contains('carb')) {
        carbs ??= value;
      } else if (label.contains('fat')) {
        fat ??= value;
      }
    }

    return NutritionFacts(
      calories: calories,
      proteinG: protein,
      carbsG: carbs,
      fatG: fat,
    );
  }

  /// Removes the macro line restaurants typed into the description before this
  /// feature existed, so the numbers aren't shown twice on the detail sheet.
  ///
  /// The catalogue carries at least three shapes of it:
  ///   `Calories(318) Prot(21g) Carb(42g) Fat(8g)`
  ///   `595 Calories (29g Prot,81g Carbs,16g Fats)`
  ///   `810 Calories (37 Prot., 89 Carbs, 33 Fats )`
  ///
  /// A line is dropped only when it names two or more different macros, carries
  /// digits, and has almost no other words left once those are removed — so a
  /// real sentence that happens to mention fat survives untouched.
  static String stripNutritionLines(String? description) {
    if (description == null || description.isEmpty) return '';

    final List<String> kept = description
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .split('\n')
        .where((String line) => !_isNutritionLine(line))
        .toList();

    return kept.join('\n').trim();
  }

  static bool _isNutritionLine(String line) {
    final String text = line.trim();
    if (text.isEmpty) return false;
    if (!_numberPattern.hasMatch(text)) return false;

    final Set<String> kinds = _macroWord
        .allMatches(text)
        .map((Match m) => _canonicalMacro(m.group(0)!.toLowerCase()))
        .toSet();
    if (kinds.length < 2) return false;

    // Whatever is left after removing the macro words, numbers, units and
    // punctuation. Real prose leaves words behind; a stats line leaves nothing.
    final String residue = text
        .replaceAll(_macroWord, ' ')
        .replaceAll(RegExp(r'[0-9()\[\],.:;&/+\-]'), ' ')
        .replaceAll(RegExp(r'\bg\b', caseSensitive: false), ' ')
        .split(RegExp(r'\s+'))
        .where((String w) => w.length > 2)
        .join(' ');

    return residue.length <= 8;
  }

  static String _canonicalMacro(String word) {
    if (word.startsWith('cal') || word == 'kcal') return 'calories';
    if (word.startsWith('prot')) return 'protein';
    if (word.startsWith('carb')) return 'carbs';
    return 'fat';
  }

  static final RegExp _macroWord = RegExp(
    r'\b(?:kcal|calories|calorie|protein|prot|carbohydrates|carbs|carb|fats|fat)\b',
    caseSensitive: false,
  );

  static final RegExp _numberPattern = RegExp(r'\d+(?:\.\d+)?');

  static double? _firstNumber(String input) {
    final Match? match = _numberPattern.firstMatch(input);
    if (match == null) return null;
    return double.tryParse(match.group(0)!);
  }
}

enum NutritionMacro { protein, carbs, fat }
